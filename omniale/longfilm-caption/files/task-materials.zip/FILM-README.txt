Input is the complete 6107.776-second film; the website excerpts are previews, not test inputs. Source: https://archive.org/details/the-cosmonaut
SHA256: 122f0b8a2e53dfbc6c2c27a43a9bb05f3c3403ea9753334ebd563e9260b3d01d
