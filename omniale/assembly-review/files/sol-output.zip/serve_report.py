"""Local report server with byte ranges, for reliable browser seeking. Python stdlib only."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import argparse, re, shutil, webbrowser

ROOT=Path(__file__).resolve().parent.parent
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
    def send_head(self):
        self.byte_range=None
        path=Path(self.translate_path(self.path))
        if not path.resolve().is_relative_to(ROOT):
            self.send_error(403); return None
        if not path.is_file(): return super().send_head()
        try: f=path.open('rb')
        except OSError: self.send_error(404); return None
        size=path.stat().st_size
        value=self.headers.get('Range')
        if value:
            m=re.fullmatch(r'bytes=(\d*)-(\d*)',value.strip())
            if not m or not any(m.groups()):
                f.close();self.send_error(416);return None
            lo,hi=m.groups()
            if lo: start=int(lo); end=min(int(hi) if hi else size-1,size-1)
            else: start=max(0,size-int(hi));end=size-1
            if start>=size or end<start:
                f.close();self.send_response(416);self.send_header('Content-Range',f'bytes */{size}');self.end_headers();return None
            self.byte_range=(start,end)
            self.send_response(206)
            self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
            length=end-start+1
            f.seek(start)
        else: self.send_response(200);length=size
        self.send_header('Content-Type',self.guess_type(str(path)))
        self.send_header('Content-Length',str(length))
        self.send_header('Accept-Ranges','bytes')
        self.send_header('Last-Modified',self.date_time_string(path.stat().st_mtime))
        self.end_headers()
        return f
    def copyfile(self,source,outputfile):
        try:
            if self.byte_range:
                remaining=self.byte_range[1]-self.byte_range[0]+1
                while remaining>0:
                    data=source.read(min(256*1024,remaining))
                    if not data: break
                    outputfile.write(data); remaining-=len(data)
            else: shutil.copyfileobj(source,outputfile)
        except (BrokenPipeError,ConnectionResetError,ConnectionAbortedError): pass
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8765);p.add_argument('--open',action='store_true');a=p.parse_args()
    server=ThreadingHTTPServer(('127.0.0.1',a.port),Handler)
    url=f'http://127.0.0.1:{a.port}/output/report.html'
    print(url,flush=True)
    if a.open: webbrowser.open(url)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
