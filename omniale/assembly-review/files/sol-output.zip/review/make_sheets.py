from pathlib import Path
import argparse, cv2
from PIL import Image, ImageDraw

p=argparse.ArgumentParser()
p.add_argument('--view',default='top',choices=['top','front'])
p.add_argument('--start',type=float,default=0)
p.add_argument('--end',type=float,default=174)
p.add_argument('--step',type=float,default=1)
p.add_argument('--cols',type=int,default=4)
p.add_argument('--count',type=int,default=12)
p.add_argument('--prefix',default='')
p.add_argument('--crop',nargs=4,type=int)
a=p.parse_args()
root=Path(__file__).resolve().parents[2]
cap=cv2.VideoCapture(str(root/'input'/f'{a.view}.mp4'))
crop=a.crop or ([260,150,1040,670] if a.view=='top' else [270,330,1010,720])
cw=480; ch=round((crop[3]-crop[1])*cw/(crop[2]-crop[0]))
times=[]; t=a.start
while t<min(a.end,173.8): times.append(t); t+=a.step
for k in range(0,len(times),a.count):
    batch=times[k:k+a.count]
    sheet=Image.new('RGB',(cw*a.cols,(ch+28)*((len(batch)+a.cols-1)//a.cols)), '#19232e')
    d=ImageDraw.Draw(sheet)
    for j,t in enumerate(batch):
        cap.set(cv2.CAP_PROP_POS_MSEC,t*1000); ok,f=cap.read()
        if not ok: continue
        f=f[crop[1]:crop[3],crop[0]:crop[2]]
        im=Image.fromarray(cv2.cvtColor(f,cv2.COLOR_BGR2RGB)).resize((cw,ch))
        x=(j%a.cols)*cw; y=(j//a.cols)*(ch+28)
        sheet.paste(im,(x,y+28)); d.text((x+8,y+6),f'{a.view} {t:06.2f}s | image left=RIGHT hand',fill='white')
    dest=root/'output'/'review'/f'{a.prefix}{a.view}_{batch[0]:06.2f}.jpg'
    sheet.save(dest,quality=92)
    print(dest.name)
