// Non-UI DOM simulation. Does not launch or control a browser.
const fs=require('fs'),path=require('path'),assert=require('node:assert/strict');
const {JSDOM,VirtualConsole}=require('./qa_tools/node_modules/jsdom');
const out=path.resolve(__dirname,'..');
const source=JSON.parse(fs.readFileSync(path.join(out,'actions.json'),'utf8')).events;
const errors=[],checks=[];
const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
const dom=new JSDOM(fs.readFileSync(path.join(out,'report.html'),'utf8'),{
  url:'http://127.0.0.1:8765/output/report.html',runScripts:'dangerously',virtualConsole:vc,
  beforeParse(w){
    w.requestAnimationFrame=f=>(w._qaFrame=f,1);
    const p=w.HTMLMediaElement.prototype;
    Object.defineProperty(p,'readyState',{get(){return 1;}});
    Object.defineProperty(p,'duration',{get(){return this.id==='audio'?198.688753:173.8;}});
    Object.defineProperty(p,'paused',{get(){return this._qaPaused!==false;}});
    p.play=function(){this._qaPaused=false;this.dispatchEvent(new w.Event('play'));return Promise.resolve();};
    p.pause=function(){if(!this.paused){this._qaPaused=true;this.dispatchEvent(new w.Event('pause'));}};
    p.load=function(){};
  }
});
const w=dom.window,d=w.document,$=id=>d.getElementById(id);
const settle=()=>new Promise(resolve=>setImmediate(resolve));
function check(name,fn){fn();checks.push({name,status:'PASS'});}
function change(id,value){$(id).value=value;$(id).dispatchEvent(new w.Event('change'));}
function rows(){return [...$('rows').rows];}
function reset(){$('reset').click();}
(async()=>{
  check('default: every archived observation is shown once',()=>assert.equal(rows().length,source.length));
  check('timeline keeps both anatomical hand tracks',()=>{
    assert.equal(d.querySelectorAll('#lane-left .event-bar').length,46);
    assert.equal(d.querySelectorAll('#lane-right .event-bar').length,69);
  });
  change('hand-filter','left');check('left hand filter',()=>assert.equal(rows().length,46));
  change('action-filter','transfer');check('combined hand/action filter',()=>assert.equal(rows().length,5));
  change('object-filter','shaft');check('combined hand/action/object filter',()=>assert.equal(rows().length,1));
  reset();$('search').value='黑色长柄';$('search').dispatchEvent(new w.Event('input'));
  check('Chinese text search and notes',()=>assert.ok(rows().length>0&&rows().length<source.length));
  reset();$('search').value='E001';$('search').dispatchEvent(new w.Event('input'));
  check('event ID search',()=>assert.equal(rows().length,1));
  reset();change('status-filter','unknown');check('null action filter',()=>assert.equal(rows().length,3));
  change('hand-filter','right');check('empty combination state',()=>{assert.equal(rows().length,0);assert.equal($('empty').hidden,false);});
  reset();change('status-filter','excluded');check('public exclusions remain inspectable',()=>assert.equal(rows().length,2));
  reset();check('reset restores all observations',()=>assert.equal(rows().length,115));
  d.querySelector('#rows [data-play="E001"][data-view="front"]').click();await settle();await settle();
  check('event playback seeks front and auxiliary evidence to padded start',()=>{
    assert.equal(w.ledgerQA.selected.id,'E001');assert.ok(Math.abs($('front').currentTime-.55)<.00001);
    assert.ok(Math.abs($('top').currentTime-.55)<.00001);assert.equal($('front').paused,false);
  });
  $('front').currentTime=3;w._qaFrame();
  check('event end automatically pauses both videos',()=>{assert.equal($('front').paused,true);assert.equal($('top').paused,true);});
  $('context').checked=false;$('play-selected').click();await settle();await settle();
  check('exact interval replay without context',()=>assert.ok(Math.abs($('front').currentTime-1.2)<.00001));
  $('pause').click();
  d.querySelector('[data-step="0.0333333333"]').click();await settle();
  check('single frame step',()=>assert.ok(Math.abs($('front').currentTime-1.2333333333)<.00001));
  $('front').currentTime=2.5;$('front').dispatchEvent(new w.Event('timeupdate'));
  check('simultaneous bilateral transfer is not deduplicated',()=>{
    const pair=source.filter(e=>e.action==='transfer'&&e.start_s===2.3);
    assert.equal(pair.length,2);for(const e of pair)assert.ok($('active').textContent.includes(e.id));
  });
  const last=source.at(-1);d.querySelector(`#rows [data-play="${last.id}"][data-view="both"]`).click();await settle();await settle();
  check('late video seek works in DOM state and selected note changes',()=>{
    assert.equal(w.ledgerQA.selected.id,last.id);assert.ok(Math.abs($('front').currentTime-last.start_s)<.00001);
    assert.ok($('selected-note').textContent.includes(last.note));
  });
  d.querySelector('[data-audio="178.14,198.68"]').click();await settle();
  check('final policy replay uses separate audio clock and pauses videos',()=>{
    assert.equal($('audio').currentTime,178.14);assert.equal($('audio').paused,false);assert.equal($('front').paused,true);
  });
  $('audio').currentTime=198.681;$('audio').dispatchEvent(new w.Event('timeupdate'));
  check('audio policy interval ends automatically',()=>assert.equal($('audio').paused,true));
  check('page script produced no uncaught DOM errors',()=>assert.deepEqual(errors,[]));
  const result={status:'PASS',mode:'jsdom simulation with stubbed media; no real browser or codec decoding',checks,errors};
  fs.writeFileSync(path.join(__dirname,'dom_qa.json'),JSON.stringify(result,null,2));
  console.log(JSON.stringify({status:result.status,checks:checks.length,errors}));w.close();
})().catch(e=>{const result={status:'FAIL',checks,error:e.stack,errors};fs.writeFileSync(path.join(__dirname,'dom_qa.json'),JSON.stringify(result,null,2));console.error(e);w.close();process.exitCode=1;});
