"""Validate deliverable integrity, schema, interval policy and media paths."""
from pathlib import Path
from collections import Counter
from html.parser import HTMLParser
import json, hashlib, subprocess, urllib.request, datetime

ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'output'
events=json.loads((OUT/'actions.json').read_text(encoding='utf-8'))['events']
policy=json.loads((OUT/'policy.json').read_text(encoding='utf-8'))
valid_actions={'pick_up','put_down','transfer','flip','adjust','fit','fasten'}
valid_objects={'body','shaft','gear','adapter_plate','bearing_plate','small_attachment','handle','screwdriver','wrench'}
assert len({e['id'] for e in events})==len(events)
assert policy['first']['start_s']==0 and policy['first']['end_s']==83
assert policy['second']['start_s']==83 and policy['second']['end_s']==173.8
assert set(policy['first']['actions'])==valid_actions-{'put_down'}
assert set(policy['second']['actions'])==valid_actions
assert not policy['record_holds'] and policy['bilateral_as_two_tracks'] and policy['clock']=='front.mp4'
assert all(set(policy[k]['hands'])=={'left','right'} for k in ['first','second'])
exclusions=json.loads((ROOT/'input/evaluation_exclusions.json').read_text(encoding='utf-8'))
for e in events:
    assert e['hand'] in {'left','right'}
    assert 0<=e['start_s']<e['end_s']<=173.8
    assert e['action'] is None or e['action'] in valid_actions
    assert e['object'] is None or e['object'] in valid_objects
    p='first' if e['start_s']<83 else 'second'
    assert e['policy_segment']==p
    assert e['action'] is None or e['action'] in policy[p]['actions']
    assert e['note'].strip()
    assert {s['file'] for s in e['evidence']}=={'front.mp4','top.mp4'}
    for s in e['evidence']:
        assert (ROOT/'input'/s['file']).is_file()
        assert 0<=s['start_s']<=e['start_s']<e['end_s']<=s['end_s']<=173.8
    mid=(e['start_s']+e['end_s'])/2
    excluded=any(e['hand']==x['hand'] and x['start_s']<=mid<x['end_s'] for x in exclusions)
    assert e['evaluation_excluded']==excluded

class Page(HTMLParser):
    def __init__(self): super().__init__();self.links=[];self.current=None;self.jsontext='';self.jstext='';self.ids=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if 'id' in a:self.ids.append(a['id'])
        for k in ['src','href']:
            if k in a:self.links.append(a[k])
        if tag=='script': self.current='json' if a.get('id')=='ledger-data' else 'js'
    def handle_endtag(self,tag):
        if tag=='script':self.current=None
    def handle_data(self,data):
        if self.current=='json':self.jsontext+=data
        if self.current=='js':self.jstext+=data
page=Page();page.feed((OUT/'report.html').read_text(encoding='utf-8'))
assert len(set(page.ids))==len(page.ids),'Duplicate DOM IDs'
embedded=json.loads(page.jsontext)
assert embedded['events']==events and embedded['policy']==policy,'Embedded data differs from JSON'
for href in page.links:
    if not href.startswith(('http://','https://','#','data:')):assert (OUT/href.split('#')[0]).is_file(),href
js=OUT/'review/report_script.js';js.write_text(page.jstext,encoding='utf-8')
r=subprocess.run(['node','--check',str(js)],capture_output=True,text=True)
assert r.returncode==0,r.stderr
overlaps=[]
for i,a in enumerate(events):
    for b in events[i+1:]:
        if a['hand']==b['hand'] and max(a['start_s'],b['start_s'])<min(a['end_s'],b['end_s']):
            overlaps.append([a['id'],b['id']])
http={}
for name in ['front.mp4','top.mp4','handover.wav']:
    try:
        req=urllib.request.Request('http://127.0.0.1:8765/input/'+name,headers={'Range':'bytes=1000-1999'})
        with urllib.request.urlopen(req,timeout=5) as r:
            b=r.read();assert r.status==206 and len(b)==1000
            http[name]={'status':r.status,'content_range':r.headers['Content-Range'],'returned_bytes':len(b)}
    except urllib.error.URLError as e:http[name]={'not_run':str(e)}
report={
    'checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'schema_and_policy':'PASS','embedded_data_matches_json':'PASS','local_links':'PASS','javascript_syntax':'PASS',
    'events':len(events),'by_hand':dict(Counter(e['hand'] for e in events)),
    'by_action':dict(Counter(str(e['action']) for e in events)),
    'by_object':dict(Counter(str(e['object']) for e in events)),
    'unknown_action_ids':[e['id'] for e in events if e['action'] is None],
    'public_exclusion_observation_ids':[e['id'] for e in events if e['evaluation_excluded']],
    'same_hand_overlaps_for_review':overlaps,'http_byte_ranges':http,
    'browser_ui_test':{'status':'blocked','reason':'Browser control disabled in Work settings. Windows UI controller stopped because it could not determine the current browser URL confidently. No bypass attempted.'},
    'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'input/front.mp4',ROOT/'input/top.mp4',ROOT/'input/handover.wav']},
    'deliverable_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [OUT/'actions.json',OUT/'policy.json',OUT/'report.html',OUT/'README.md']}
}
dom=OUT/'review/dom_qa.json'
if dom.is_file():report['dom_interaction_simulation']=json.loads(dom.read_text(encoding='utf-8'))
(OUT/'review/validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ['source_sha256','deliverable_sha256','by_object']},ensure_ascii=False,indent=2))
