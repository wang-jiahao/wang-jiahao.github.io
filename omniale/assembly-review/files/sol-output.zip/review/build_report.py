from pathlib import Path
import json
out=Path(__file__).resolve().parent.parent
data=json.loads((out/'actions.json').read_text(encoding='utf-8'))
data['policy']=json.loads((out/'policy.json').read_text(encoding='utf-8'))
template=(out/'review/report_template.html').read_text(encoding='utf-8')
embedded=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
(out/'report.html').write_text(template.replace('__DATA__',embedded),encoding='utf-8')
print(f"report.html: {len(data['events'])} events embedded")
