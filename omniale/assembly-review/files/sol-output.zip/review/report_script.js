
'use strict';
const DATA=JSON.parse(document.getElementById('ledger-data').textContent),events=DATA.events,policy=DATA.policy;
const actions={pick_up:'取起',put_down:'放下／归还',transfer:'转交',flip:'翻面／转向',adjust:'对位调整',fit:'插入／贴合',fasten:'旋拧',null:'未知动作'};
const objects={body:'机体',shaft:'长轴／转子',gear:'齿轮状圆件',adapter_plate:'环状适配件',bearing_plate:'较大圆盘总成',small_attachment:'小附件',handle:'黑色长柄',screwdriver:'螺丝刀',wrench:'扳手',null:'未知对象'};
const colors={pick_up:'#327fa4',put_down:'#63727b',transfer:'#8a59a3',flip:'#258e89',adjust:'#ba8a28',fit:'#45915f',fasten:'#bc5d4f',null:'#8c9298'};
const $=id=>document.getElementById(id),front=$('front'),top=$('top'),audio=$('audio');
const escapeHTML=s=>String(s??'null').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let filtered=events.slice(),selected=null,stopAt=null,audioStop=null,selectionVersion=0;
const handName=h=>h==='left'?'左手':'右手',time=t=>Number(t).toFixed(2);
$('stats').innerHTML=[['全部记录',events.length],['左手',events.filter(e=>e.hand==='left').length],['右手',events.filter(e=>e.hand==='right').length],['未知动作',events.filter(e=>e.action===null).length],['公开排除观察',events.filter(e=>e.evaluation_excluded).length]].map(([s,n])=>`<div><strong>${n}</strong> <span>${s}</span></div>`).join('');
$('unknown-summary').textContent='未知动作：'+events.filter(e=>e.action===null).map(e=>`${e.id} ${handName(e.hand)} ${time(e.start_s)}–${time(e.end_s)} 秒`).join('；')+'。这些记录保留可确认的手轨、对象和时间，未推断左手施力或内部结果。';
for(const [key,label] of Object.entries(actions))$('action-filter').add(new Option(label+' · '+key,key));
for(const [key,label] of Object.entries(objects))if(key!=='null'||events.some(e=>e.object===null))$('object-filter').add(new Option(label+' · '+key,key));
$('legend').innerHTML=Object.entries(actions).map(([key,label])=>`<span><i class="dot" style="background:${colors[key]}"></i>${label}</span>`).join('');
$('axis').style.cssText='height:18px;position:relative;margin-left:60px;display:block';
$('axis').innerHTML=[0,20,40,60,83,100,120,140,160,173.8].map(t=>`<span style="position:absolute;left:${t/173.8*100}%;transform:translateX(${t===0?'0':t===173.8?'-100%':'-50%'})">${t}${t===173.8?' s':''}</span>`).join('');
function filterEvents(){const h=$('hand-filter').value,a=$('action-filter').value,o=$('object-filter').value,s=$('status-filter').value,q=$('search').value.trim().toLocaleLowerCase();filtered=events.filter(e=>(!h||e.hand===h)&&(!a||String(e.action)===a)&&(!o||String(e.object)===o)&&(!s||(s==='unknown'&&(e.action===null||e.object===null))||(s==='excluded'&&e.evaluation_excluded)||(s==='included'&&!e.evaluation_excluded))&&(!q||[e.id,e.hand,handName(e.hand),e.action,actions[e.action],e.object,objects[e.object],e.note].join(' ').toLocaleLowerCase().includes(q)));render();}
function render(){
 $('count').textContent=`显示 ${filtered.length} / ${events.length} 条；默认包括两手全部归档记录`;
 $('empty').hidden=filtered.length>0;
 $('rows').innerHTML=filtered.map(e=>`<tr data-id="${e.id}" class="${selected?.id===e.id?'selected':''}"><td>${e.id}${e.evaluation_excluded?'<br><span class="badge excluded">公开排除</span>':''}</td><td><span class="badge ${e.hand}">${handName(e.hand)}</span><span class="code">${e.hand}</span></td><td class="time">${time(e.start_s)}<br>– ${time(e.end_s)}</td><td><span class="${e.action===null?'badge unknown':''}">${actions[e.action]||'未知动作'}</span><span class="code">${e.action??'null'}</span></td><td>${objects[e.object]||'未知对象'}<span class="code">${e.object??'null'}</span></td><td class="note">${escapeHTML(e.note)}</td><td class="ops"><button data-play="${e.id}" data-view="front">正面</button> <button data-play="${e.id}" data-view="both">双视角</button></td></tr>`).join('');
 for(const h of ['left','right'])$('lane-'+h).innerHTML='<span class="boundary" title="83秒"></span>'+filtered.filter(e=>e.hand===h).map(e=>`<button class="event-bar ${e.action===null?'unknown':''} ${selected?.id===e.id?'selected':''}" style="left:${100*e.start_s/173.8}%;width:${100*(e.end_s-e.start_s)/173.8}%;background:${colors[e.action]}" data-play="${e.id}" data-view="both" title="${e.id} ${handName(e.hand)} ${time(e.start_s)}–${time(e.end_s)}s ${actions[e.action]} ${objects[e.object]}" aria-label="${e.id} ${handName(e.hand)} ${actions[e.action]} ${time(e.start_s)}秒"></button>`).join('');
 updateActive();
}
function pauseVideos(){front.pause();top.pause();}
async function seek(video,t){if(video.readyState<1){await new Promise((resolve,reject)=>{video.addEventListener('loadedmetadata',resolve,{once:true});video.addEventListener('error',()=>reject(new Error('媒体无法加载：'+video.getAttribute('src'))),{once:true});video.load();});}video.currentTime=Math.min(t,video.duration||173.8);}
async function playEvent(id,view){const e=events.find(x=>x.id===id);if(!e)return;const version=++selectionVersion;selected=e;pauseVideos();audio.pause();stopAt=null;$('message').textContent='';if(view==='both')$('sync').checked=true;
 $('selected-title').textContent=`${e.id} · ${handName(e.hand)} · ${actions[e.action]} · ${objects[e.object]} · front ${time(e.start_s)}–${time(e.end_s)} s`;
 $('selected-note').textContent=e.note+(e.evaluation_excluded?' 【公开歧义排除观察】':'');render();
 const padding=$('context').checked ? 0.65 : 0,start=Math.max(0,e.start_s-padding),end=Math.min(173.8,e.end_s+padding);
 try{await Promise.all([seek(front,start),seek(top,start)]);if(version!==selectionVersion)return;stopAt=end;front.playbackRate=top.playbackRate=Number($('speed').value);await front.play();if($('sync').checked)await top.play();}catch(err){$('message').textContent=err.message+'。可按 README 使用本地 HTTP 打开，或通过原片链接回看。';}
}
function updateActive(){const t=front.currentTime||0;$('clock').textContent='front '+time(t)+' s';$('scrub').value=t;const active=events.filter(e=>e.start_s<=t&&t<e.end_s);$('active').textContent=active.length?'此刻记录：'+active.map(e=>`${e.id} ${handName(e.hand)} ${actions[e.action]} · ${objects[e.object]}`).join('  ｜  '):'此刻无归档工作动作；可能是扶持、等待、范围排除或动作间隙。';for(const row of $('rows').rows)row.classList.toggle('playing',active.some(e=>e.id===row.dataset.id));}
document.addEventListener('click',ev=>{const btn=ev.target.closest('[data-play]');if(btn)playEvent(btn.dataset.play,btn.dataset.view);const step=ev.target.closest('[data-step]');if(step){pauseVideos();stopAt=null;const t=Math.max(0,Math.min(173.79,front.currentTime+Number(step.dataset.step)));seek(front,t);seek(top,t);}const ab=ev.target.closest('[data-audio]');if(ab){pauseVideos();const [start,end]=ab.dataset.audio.split(',').map(Number);audio.currentTime=start;audioStop=end;audio.play().catch(err=>$('message').textContent=err.message);}});
for(const id of ['hand-filter','action-filter','object-filter','status-filter'])$(id).addEventListener('change',filterEvents);
$('search').addEventListener('input',filterEvents);$('reset').onclick=()=>{for(const id of ['hand-filter','action-filter','object-filter','status-filter','search'])$(id).value='';filterEvents();};
$('pause').onclick=()=>{pauseVideos();audio.pause();};$('play-selected').onclick=()=>playEvent(selected?.id||filtered[0]?.id,'front');
function moveSelection(delta){if(!filtered.length)return;let i=filtered.findIndex(e=>e.id===selected?.id);if(i<0)i=delta>0?-1:filtered.length;const next=filtered[Math.max(0,Math.min(filtered.length-1,i+delta))];playEvent(next.id,'front');} $('previous').onclick=()=>moveSelection(-1);$('next').onclick=()=>moveSelection(1);
$('speed').onchange=()=>{front.playbackRate=top.playbackRate=Number($('speed').value);};$('sync').onchange=()=>{if(!$('sync').checked){top.pause();}else{seek(top,front.currentTime);if(!front.paused)top.play().catch(()=>{});}};
$('scrub').addEventListener('input',()=>{pauseVideos();stopAt=null;seek(front,Number($('scrub').value));seek(top,Number($('scrub').value));});
front.addEventListener('seeking',()=>{if($('sync').checked&&Math.abs(top.currentTime-front.currentTime)>.12)seek(top,front.currentTime);});
front.addEventListener('play',()=>{audio.pause();if($('sync').checked){if(Math.abs(top.currentTime-front.currentTime)>.25)seek(top,front.currentTime);top.play().catch(()=>{});}});front.addEventListener('pause',()=>{if($('sync').checked)top.pause();});front.addEventListener('timeupdate',updateActive);
for(const v of [front,top])v.addEventListener('error',()=>{$('message').textContent='媒体加载失败：'+v.getAttribute('src')+'。请保留 output 与 input 的相邻目录关系，或按 README 启动本地服务。';});
audio.addEventListener('timeupdate',()=>{if(audioStop!==null&&audio.currentTime>=audioStop){audio.pause();audioStop=null;}});audio.addEventListener('play',pauseVideos);
function tick(){if(stopAt!==null&&!front.paused&&front.currentTime>=stopAt){pauseVideos();stopAt=null;}if(!front.paused&&$('sync').checked&&!top.seeking&&Math.abs(top.currentTime-front.currentTime)>.4)top.currentTime=front.currentTime;requestAnimationFrame(tick);}requestAnimationFrame(tick);render();
// Exposed read-only data supports reproducible local QA without a network dependency.
window.ledgerQA={events,policy,get filtered(){return filtered;},get selected(){return selected;}};
