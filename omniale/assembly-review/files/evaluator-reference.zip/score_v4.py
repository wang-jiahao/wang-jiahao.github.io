"""Independent field partial credit for the fine-action ledger, frozen before pilot."""
from pathlib import Path
import argparse,collections,json,math

ROOT=Path(__file__).resolve().parent
ACTIONS=['pick_up','put_down','transfer','flip','adjust','fit','fasten']
OBJECTS=['body','shaft','gear','adapter_plate','bearing_plate','small_attachment','handle','screwdriver','wrench']

def read(p,default):
 try:return json.loads(p.read_text(encoding='utf-8-sig'))
 except (ValueError,OSError):return default
def num(x):return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)
def interval(x):
 a,b=x.get('start_s'),x.get('end_s')
 return (a,b) if num(a) and num(b) and 0<=a<b<=174.8 else None
def timeok(p,t):
 a=interval(p);b=interval(t)
 if not a or not b:return False
 inter=max(0,min(a[1],b[1])-max(a[0],b[0]));union=max(a[1],b[1])-min(a[0],b[0])
 return inter/union>=.25 or (abs(a[0]-b[0])<=1.2 and abs(a[1]-b[1])<=2)
def excluded(p,regions):
 a=interval(p)
 if not a:return False
 for r in regions:
  if p.get('hand')==r['hand'] and r['start_s']<=(a[0]+a[1])/2<r['end_s']:return True
 return False
def maximum(a,b,fn):
 # Maximum bipartite matching; overlap order is not an extra hidden condition.
 edges=[[j for j,y in enumerate(b) if fn(x,y)] for x in a];owners={}
 def augment(i,seen):
  for j in edges[i]:
   if j in seen:continue
   seen.add(j)
   if j not in owners or augment(owners[j],seen):owners[j]=i;return True
  return False
 for i in range(len(a)):augment(i,set())
 return [(i,j) for j,i in owners.items()]
def f1(tp,np,nt):return 2*tp/(np+nt) if np+nt else 0
def field_metric(pred,truth,field,classes):
 out=[]
 for label in classes:
  tt=[x for x in truth if x[field]==label]
  pp=[x for x in pred if x.get(field)==label]
  pairs=maximum(pp,tt,lambda p,t:timeok(p,t))
  out.append(dict(label=label,true_positives=len(pairs),predicted=len(pp),expected=len(tt),f1=f1(len(pairs),len(pp),len(tt))))
 macro=sum(r['f1'] for r in out)/len(out)
 tp=sum(r['true_positives'] for r in out);np=sum(r['predicted'] for r in out);nt=sum(r['expected'] for r in out)
 invalid=sum(x.get(field) not in classes for x in pred)
 # Invalid labels still count as extras in micro diagnostics; macro is penalized
 # by uncovered expected units and cannot gain a match from invalid entries.
 return dict(macro_f1=macro,micro_f1=f1(tp,np+invalid,nt),classes=out,invalid_labels=invalid)
def policy_score(p,t):
 rows=[]
 for phase in ['first','second']:
  a=p.get(phase,{}) if isinstance(p,dict) else {};b=t[phase]
  if not isinstance(a,dict):a={}
  rows.append(dict(unit=phase+'_start',ok=num(a.get('start_s')) and abs(a['start_s']-b['start_s'])<=.2))
  rows.append(dict(unit=phase+'_end',ok=num(a.get('end_s')) and abs(a['end_s']-b['end_s'])<=.2))
  hh=a.get('hands');rows.append(dict(unit=phase+'_hands',ok=isinstance(hh,list) and sorted(str(x) for x in hh)==b['hands']))
  value=a.get('actions');aa=set(str(x) for x in value) if isinstance(value,list) else set();bb=set(b['actions']);rows.append(dict(unit=phase+'_actions',partial=2*len(aa&bb)/(len(aa)+len(bb)) if aa or bb else 1))
 for k in ['record_holds','clock','bilateral_as_two_tracks']:rows.append(dict(unit=k,ok=isinstance(p,dict) and p.get(k)==t[k]))
 return dict(points=10*sum(r.get('partial',float(r.get('ok',False))) for r in rows)/len(rows),units=rows)
def score(output,manual=None,truth_path=None):
 truth=read(truth_path or ROOT/'v4/authoring/truth.json',{})
 data=read(output/'actions.json',{});pred=data.get('events',[]) if isinstance(data,dict) else [];pred=[dict(x) for x in pred if isinstance(x,dict)] if isinstance(pred,list) else []
 for p in pred:
  if p.get('object') in ['fastener','spring','lever','screw','nut','washer']:p['object']='small_attachment'
 all_pred=pred;regions=truth.get('exclusions',[]);pred=[p for p in pred if not excluded(p,regions)];tt=[p for p in truth['events'] if not excluded(p,regions)]
 metrics={f:field_metric(pred,tt,f,c) for f,c in [('action',ACTIONS),('object',OBJECTS),('hand',['left','right'])]}
 pairs=maximum(pred,tt,lambda a,b:timeok(a,b));loc=f1(len(pairs),len(pred),len(tt));pol=policy_score(read(output/'policy.json',{}),truth['policy'])
 breakdown=dict(action=35*metrics['action']['macro_f1'],object=20*metrics['object']['macro_f1'],hand=15*metrics['hand']['macro_f1'],localization=5*loc,audio_policy=pol['points'])
 result=dict(material_version='v4',rubric_version='assembly-av-v4-fields-macro-1',automatic_points_out_of_85=sum(breakdown.values()),breakdown=breakdown,field_metrics=metrics,localization=dict(f1=loc,matched=len(pairs),predicted=len(pred),expected=len(tt)),excluded_predictions=len(all_pred)-len(pred),excluded_references=len(truth['events'])-len(tt),audio_policy=pol,total=None,manual_points_out_of_15=None,status='awaiting delivery and conservative visual audit')
 if manual:
  m=read(manual,{})
  assert num(m.get('report')) and 0<=m['report']<=10 and num(m.get('documentation')) and 0<=m['documentation']<=5 and m.get('evidence')
  result.update(total=result['automatic_points_out_of_85']+m['report']+m['documentation'],manual_points_out_of_15=m['report']+m['documentation'],manual_review=m,status='author reviewed; independent human certification pending')
 return result
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('output',type=Path);a.add_argument('--manual',type=Path);a.add_argument('--truth',type=Path);a.add_argument('--save',type=Path);n=a.parse_args();r=score(n.output,n.manual,n.truth)
 if n.save:n.save.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(r,ensure_ascii=False,indent=2))
