"""Fixed script scoring: original 85-point scorer + automatic delivery probes.

No post-run event adjudication, synonym correction or boundary adjustment.
Browser probes use generic HTML controls; an unrecognized implementation may
lose delivery credit. The probe implementation is frozen before model runs.
"""
from pathlib import Path
from datetime import datetime,timezone
from functools import partial
from http.server import ThreadingHTTPServer
import argparse,hashlib,json,re,threading
from playwright.sync_api import sync_playwright
from score_v4 import score
from site_qa import QuietHandler

ROOT=Path(__file__).resolve().parent;V=ROOT/'v4_1'
ACT={'pick_up':'取','put_down':'放','transfer':'转','flip':'翻','adjust':'对','fit':'合','fasten':'拧'}
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')

def delivery(run,log):
 output=run/'output';rows=read(output/'actions.json').get('events',[]) if (output/'actions.json').exists() else []
 ids=[str(x.get('id','')) for x in rows if x.get('id') is not None]
 checks=[];errors=[]
 def record(name,passed,evidence):checks.append(dict(unit=name,points=int(bool(passed)),evidence=evidence))
 report=output/'report.html'
 raw=report.read_text(encoding='utf-8',errors='replace') if report.exists() else ''
 record('report_document',bool(raw and re.search(r'<(?:html|body|!doctype)',raw,re.I)),dict(bytes=len(raw.encode())))
 server=ThreadingHTTPServer(('127.0.0.1',0),partial(QuietHandler,directory=str(run)))
 threading.Thread(target=server.serve_forever,daemon=True).start()
 try:
  with sync_playwright() as p:
   browser=p.chromium.launch(channel='chrome',headless=True,timeout=30000)
   page=browser.new_page(viewport={'width':1440,'height':1000});page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto(f'http://127.0.0.1:{server.server_port}/output/report.html',wait_until='domcontentloaded',timeout=30000);page.wait_for_timeout(1200)
   record('browser_execution',bool(raw) and not errors,dict(page_errors=errors.copy()))
   def visible_ids():
    body=page.locator('body').inner_text(timeout=3000)
    return {x for x in ids if re.search(r'(?<![A-Za-z0-9_])'+re.escape(x)+r'(?![A-Za-z0-9_])',body)}
   baseline=visible_ids();record('default_all_records',bool(ids) and len(baseline)==len(set(ids)),dict(visible=len(baseline),expected=len(set(ids))))
   def video_ready(name):
    try:
     tokens=['正面','front'] if name=='front' else ['俯视','top']
     controls=page.locator('button,a,[role=button]')
     for i in range(min(controls.count(),30)):
      c=controls.nth(i);text=c.inner_text(timeout=1000).lower()
      if any(t in text for t in tokens) and c.is_visible():
       try:c.click(timeout=1500);page.wait_for_timeout(250)
       except Exception:pass
       break
     for _ in range(20):
      media=page.locator('video').evaluate_all('(vs)=>vs.map(v=>({src:v.currentSrc||v.src,ready:v.readyState,duration:v.duration}))')
      if any(name+'.mp4' in m['src'] and m['ready']>=1 and (m['duration'] or 0)>170 for m in media):return True,media
      page.wait_for_timeout(200)
     return False,media
    except Exception as exc:return False,dict(error=type(exc).__name__)
   for name in ['front','top']:
    ok,evidence=video_ready(name);record(name+'_video',ok,evidence)
   audio=page.locator('audio').evaluate_all('(xs)=>xs.map(x=>({src:x.currentSrc||x.src,ready:x.readyState,duration:x.duration}))')
   record('handover_audio',any('handover.wav' in x['src'] and x['ready']>=1 and (x['duration'] or 0)>200 for x in audio),audio)
   video_ready('front')
   def filter_probe(kind):
    selectors=page.locator('select');evidence=[]
    for i in range(selectors.count()):
     element=selectors.nth(i)
     if not element.is_visible():continue
     options=element.locator('option').evaluate_all('(xs)=>xs.map(x=>({value:x.value,text:x.textContent}))');initial=element.input_value()
     for op in options:
      value=op['value'];text=op['text'] or ''
      matches=value in ['left','right'] or re.search('左手|右手',text) if kind=='hand' else value in ACT or any(s in text for s in ['取起','旋拧','翻面','对位','贴合'])
      if not value or value==initial or not matches:continue
      try:
       element.select_option(value);page.wait_for_timeout(150);count=len(visible_ids());evidence.append(dict(control=i,value=value,visible=count));element.select_option(initial);page.wait_for_timeout(100)
       if 0<count<len(baseline):return True,evidence
      except Exception as exc:evidence.append(dict(error=type(exc).__name__))
    return False,evidence
   for kind in ['hand','action']:
    ok,evidence=filter_probe(kind);record(kind+'_filter',ok,evidence)
   evidence=[];ok=False
   searches=page.locator('input[type=search],input[type=text],input:not([type])')
   for i in range(min(searches.count(),8)):
    element=searches.nth(i)
    if not element.is_visible():continue
    initial=element.input_value()
    try:
     element.fill('zzzz-benchmark-no-match-7e9d');page.wait_for_timeout(150);remaining=len(visible_ids());element.fill(initial);page.wait_for_timeout(100);restored=len(visible_ids());evidence.append(dict(control=i,remaining=remaining,restored=restored))
     if baseline and remaining==0 and restored==len(baseline):ok=True;break
    except Exception as exc:evidence.append(dict(error=type(exc).__name__))
   record('text_search',ok,evidence)
   seek=False;evidence=[]
   target=next((x for x in rows if isinstance(x.get('start_s'),(int,float)) and x['start_s']>3 and str(x.get('id','')) in baseline),None)
   if target:
    try:
     page.locator('video').evaluate_all('(xs)=>xs.forEach(v=>{if(v.readyState>=1)v.currentTime=0})')
     texts=page.get_by_text(str(target['id']),exact=False);control=None
     for i in range(min(texts.count(),3)):
      node=texts.nth(i)
      for _ in range(5):
       buttons=node.locator('button,a,[role=button]')
       if 0<buttons.count()<8:
        control=buttons.first;break
       node=node.locator('..')
      if control:break
     if control:
      control.click(timeout=2000);page.wait_for_timeout(600)
      times=page.locator('video').evaluate_all('(xs)=>xs.map(v=>({time:v.currentTime,src:v.currentSrc||v.src}))');seek=any(abs(x['time']-target['start_s'])<=1.2 for x in times)
      evidence=dict(id=target['id'],start_s=target['start_s'],videos=times)
    except Exception as exc:evidence=dict(error=type(exc).__name__)
   record('event_seek',seek,evidence)
   page.screenshot(path=str(log/'delivery-browser.png'),full_page=False);browser.close()
 except Exception as exc:
  if 'browser' not in locals():raise RuntimeError('Browser infrastructure unavailable; no delivery score') from exc
  existing={x['unit'] for x in checks}
  for name in ['browser_execution','default_all_records','front_video','top_video','handover_audio','hand_filter','action_filter','text_search','event_seek']:
   if name not in existing:record(name,False,dict(error=type(exc).__name__))
 finally:server.shutdown();server.server_close()
 assert len(checks)==10
 readme=output/'README.md';text=readme.read_text(encoding='utf-8',errors='replace') if readme.exists() else '';docs=[]
 def doc(name,ok):docs.append(dict(unit=name,points=int(bool(ok))))
 doc('substantive_readme',len(text.strip())>=200)
 doc('method',bool(re.search(r'方法|转写|抽帧|ffmpeg|whisper|method|transcrib|frame',text,re.I)))
 doc('uncertainty',bool(re.search(r'未知|不确定|遮挡|限制|uncertain|occlu|limitation|unknown',text,re.I)))
 attribution=text+'\n'+'\n'.join(p.read_text(encoding='utf-8',errors='replace') for p in output.glob('*') if p.is_file() and p.name in ['SOURCE_CREDIT.md','LICENSE-DATA.txt','CITATION.cff'])
 doc('attribution_licence',bool(re.search(r'IMPACT|Wen|CITATION',attribution,re.I)) and bool(re.search(r'CC.BY.NC.SA|Creative Commons|LICENSE',attribution,re.I)))
 doc('opening_instructions',bool(re.search(r'localhost|127\.0\.0\.1|http\.server|serve.*\.py|打开.*html|open.*html|浏览器',text,re.I)))
 return dict(report=sum(x['points'] for x in checks),documentation=sum(x['points'] for x in docs),
  evidence=['Fixed automated delivery probes; see checks and documentation_checks. No event-semantic adjudication.'],checks=checks,documentation_checks=docs,
  evaluator='delivery-auto1',implementation_limits='Generic HTML/ID/control probes may miss equivalent interfaces; no post-run correction applied')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--tag',required=True);n=ap.parse_args();log=V/'runs'/n.tag;meta=read(log/'manifest.json')
 assert meta['state']=='completed' and meta['exit_code']==0 and meta['turn_completed'],'Infrastructure errors are not zero scores'
 frozen=read(V/'evaluation-freeze.json');assert sha(Path(__file__))==frozen['delivery_scorer_sha256']
 run=Path(meta['run_dir']);manual=delivery(run,log);save(log/'delivery-auto.json',manual)
 result=score(run/'output',log/'delivery-auto.json',V/'authoring/truth.json')
 result.update(material_version='v4.1',rubric_version=frozen['rubric_version'],semantic_adjustments_applied=False,
  score_kind='original_field_scorer_plus_automatic_delivery',score_eligible=True,status='script result; no semantic adjudication or clock normalization',
  model=meta['model'],actual_turn_settings=meta['actual_turn_settings'],elapsed_seconds=meta['elapsed_seconds'],exit_code=meta['exit_code'])
 save(log/'score-script.json',result);print(json.dumps(dict(model=meta['model'],total=result['total'],automatic_points_out_of_85=result['automatic_points_out_of_85'],delivery=manual['report']+manual['documentation']),ensure_ascii=False))

if __name__=='__main__':main()
