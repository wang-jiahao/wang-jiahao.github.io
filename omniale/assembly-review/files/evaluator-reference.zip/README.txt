评审参考，非模型输入。原口径复算：python score_v4.py output --manual delivery-review.json。对象解释和分段等价仍待完整审计；不得把标签一致性分数解释为事实正确率。clock front.mp4/front等价后产物下界61.22879096955352。原始运行90分钟中断，不构成完整正式模型成绩。
