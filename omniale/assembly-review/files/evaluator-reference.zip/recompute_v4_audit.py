"""Portable recomputation of the published v4 author-adjudicated artifact score.

python recompute_v4_audit.py semantic-audit.json output --manual delivery-review.json
This calculates a fixed reviewed score; it does not rejudge another model run.
"""
from pathlib import Path
import argparse, collections, hashlib, json
from score_v4 import ACTIONS, OBJECTS, policy_score

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def compute(audit,output,manual):
 output=Path(output)
 assert sha(output/'actions.json')==audit['model_actions_sha256'], 'Different model output requires fresh review'
 assert sha(output/'policy.json')==audit['model_policy_sha256'], 'Different model policy requires fresh review'
 rows=audit['predictions'];missing=audit['missing_events'];metrics={};breakdown={}
 for field,classes,weight in [('action',ACTIONS,35),('object',OBJECTS,20),('hand',['left','right'],15)]:
  count=collections.Counter(x[field] for x in rows if x['adjudication'][field]=='accepted')
  fn=collections.Counter(x[field] for x in missing)
  cls=[dict(label=c,true_positives=count[c],predicted=count[c],expected=count[c]+fn[c],false_negatives=fn[c],f1=2*count[c]/(2*count[c]+fn[c]) if count[c]+fn[c] else 0) for c in classes]
  macro=sum(x['f1'] for x in cls)/len(cls);tp=sum(count.values());nf=sum(fn.values())
  metrics[field]=dict(macro_f1=macro,micro_f1=2*tp/(2*tp+nf),classes=cls,neutral_predictions=sum(x['adjudication'][field]=='neutral' for x in rows),adjudicated=True)
  breakdown[field]=weight*macro
 n=sum(x['adjudication']['localization']=='accepted' for x in rows);nf=len(missing)
 loc=2*n/(2*n+nf);breakdown['localization']=5*loc
 policy=read(output/'policy.json');assert policy['clock']=='front.mp4';policy['clock']='front'
 pol=policy_score(policy,audit['reference_policy']);assert pol['points']==10
 breakdown['audio_policy']=pol['points'];assert manual['report']==2 and manual['documentation']==5
 return dict(material_version='v4',rubric_version='assembly-av-v4-fields-macro-1',audit_version=audit['audit_version'],
  total=sum(breakdown.values())+manual['report']+manual['documentation'],breakdown=breakdown,field_metrics=metrics,
  audited_points_out_of_85=sum(breakdown.values()),manual_points_out_of_15=7,manual_review=manual,audio_policy=pol,
  localization=dict(f1=loc,matched=n,predicted=n,expected=n+nf,neutral_predictions=len(rows)-n,adjudicated=True),
  raw_total=audit['raw_total'],score_eligible=False,run_classification='interrupted_run_artifact',
  semantic_audit_complete=True,independent_human_certification=False,
  status='确定的作者保守审定产物分；原运行中断，不是正常完成的正式模型成绩。',
  audit_file='semantic-audit.json',audit_method=audit['method'])

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('decisions',type=Path);ap.add_argument('output',type=Path);ap.add_argument('--manual',type=Path,required=True);ap.add_argument('--save',type=Path);n=ap.parse_args()
 result=compute(read(n.decisions),n.output,read(n.manual));text=json.dumps(result,ensure_ascii=False,indent=2)
 if n.save:n.save.write_text(text,encoding='utf-8')
 print(text)
