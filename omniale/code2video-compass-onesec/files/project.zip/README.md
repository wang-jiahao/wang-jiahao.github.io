# 你身体里的一秒钟 / One Second Inside You

`video.mp4` 是一部 58 秒、1280×720、30 fps 的双语三维科普动画，配有 48 kHz 立体声程序音轨。`timeline.json` 是九幕、尺度、生物钟和声画触发点的共享时间轴。`project/` 包含可编辑源码。

## 复现

环境为 Windows、Python 3.12、Node.js/npm、PATH 上的 FFmpeg，以及支持中英文的系统字体（本次使用 Microsoft YaHei UI 和 Consolas）。在工作区根目录运行：

```powershell
npm --prefix submission/project ci
python -m pip install -r submission/project/requirements.txt
python -m playwright install chromium
python -B submission/project/render.py
```

`render.py` 启动本地临时 HTTP 服务和无头 Chromium，用 `seekTo(frame / fps)` 计算每帧，向 FFmpeg 流式传送新生成的画面，并在全部画面和音频编码完成后写入 `submission/video.mp4`。默认使用 SwiftShader。`--preview 3 10.5 15.5 20.5 26.8 32.4 41.9 42.8 43.16 47.4 52 56.7` 可单独抽帧；`--serve` 会输出本地动画预览地址。

## 画面与时间

- `geometry.js`、`anatomy.js` 和 `micro.js` 生成网格、分子实例和粒子。人体以透射边缘光显示神经、肺和心脏。血管中的红细胞由凹面旋转体构成。涡轮由六瓣催化冠、中央轴、侧定子和金色转子环构成。
- `film.js` 负责镜头推拉、焦点溶接、体积感、辉光与调色。`hud.js` 用 Canvas 绘制双语字幕、尺度栏、ECG 和八项计数。参考片段仅用于开发阶段观察构图和运动；渲染所需的画面、粒子及 HUD 都由本地代码计算。
- 片头秒表在 `2.300–3.300 s` 测量真实的一秒。主片的生物钟按时间轴锚点推进，跨尺度转场压缩部分区间。`30.200–36.700 s` 的涡轮段和通道触发附近按 `120×` 展开。膜通道开启 `120 ms`，对应生物时钟 `1 ms`。计数于 `50.600 s` 达到 `1.000 s` 并锁定。

## 音轨

`audio.py` 使用 NumPy 和 SciPy 合成滤波噪声、调频振荡器、谐波和振幅包络。开头六次秒表滴答接指数降频扫频。心室收缩共享低频 `lub-dub` 触发点。ATP 声场使用同一转子角相位调制立体声谐波，每转加入三次催化音色。`42.800 s` 的电声起点、门孔闪光和 ECG R 波使用同一个时间戳。反向拉镜有逐层升调，片尾由心跳和和弦收束。

## 成片检查

解码确认全部 1,740 帧按 30 fps 等距排列。音轨为 48 kHz 双声道 AAC，约 256 kbps，综合响度 −17.7 LUFS，真峰值 −1.1 dBTP。逐帧测得 ECG 和门孔的亮度峰值均在 42.800 秒，解码音轨 1.2–8 kHz 的 8 毫秒滑动能量峰值在 42.8054 秒。
