import {TAU,clamp,lerp,ease,mod,rng} from './geometry.js';

const canvas=document.querySelector('#hud'), c=canvas.getContext('2d');
const cyan='#9ce2e1', white='#edf7f8', muted='#a7bfc6', gold='#f7dd9c';
const sans='"Microsoft YaHei UI","Microsoft YaHei",Arial,sans-serif';
const mono='Consolas,"Microsoft YaHei UI",monospace';
function text(s,x,y,size=14,color=white,{align='left',font=sans,weight=400,shadow=0}={}){
  c.font=`${weight} ${size}px ${font}`;c.textAlign=align;c.textBaseline='alphabetic';
  c.shadowColor='rgba(0,8,14,.9)';c.shadowBlur=shadow;c.fillStyle=color;c.fillText(s,x,y);c.shadowBlur=0;
}
function line(x,y,X,Y,color,width=1){c.beginPath();c.moveTo(x,y);c.lineTo(X,Y);c.strokeStyle=color;c.lineWidth=width;c.stroke();}
function circle(x,y,r,color,width=1,start=0,end=TAU){c.beginPath();c.arc(x,y,r,start,end);c.strokeStyle=color;c.lineWidth=width;c.stroke();}
function dot(x,y,r,color){c.beginPath();c.arc(x,y,r,0,TAU);c.fillStyle=color;c.fill();}
function panel(x,y,w,h,strength=.76){
  const fill=c.createLinearGradient(x,y,x+w,y+h);
  fill.addColorStop(0,`rgba(10,25,35,${strength})`);fill.addColorStop(.69,`rgba(9,19,30,${strength+.05})`);fill.addColorStop(1,`rgba(11,24,33,${strength-.04})`);
  c.beginPath();c.roundRect(x,y,w,h,7);c.fillStyle=fill;c.fill();
  c.strokeStyle='rgba(161,220,221,.28)';c.lineWidth=1;c.stroke();
}
const random=rng(234), stars=Array.from({length:210},()=>[random()*1280,random()*720,random(),random()]);
function starscape(t,alpha=1){
  c.save();c.globalAlpha*=alpha;
  for(const [x,y,r,a] of stars)dot(mod(x+t*(3+7*a),1280),y,.38+.85*r,`rgba(141,211,235,${(.12+.56*a)*(.81+.19*Math.sin(t*.53+3*y))})`);
  c.restore();
}
function caption(zh,en,t,start,end,alpha=1){
  const attack=start===42.72?.075:.22;
  c.save();c.globalAlpha*=alpha*Math.min(ease(start,start+attack,t),1-ease(end-.22,end,t));
  const zhRows=zh.split('|'),enRows=en.split('|');
  const cy=650-(zhRows.length-1)*27-(enRows.length-1)*14;
  c.save();c.translate(640,cy+32);c.scale(1,.25);
  const gradient=c.createRadialGradient(0,0,55,0,0,445);
  gradient.addColorStop(0,'rgba(0,6,13,.36)');gradient.addColorStop(.44,'rgba(0,6,13,.25)');gradient.addColorStop(1,'rgba(0,6,13,0)');
  c.fillStyle=gradient;c.fillRect(-445,-445,890,890);c.restore();
  zhRows.forEach((s,i)=>text(s,640,cy+i*30,25,white,{align:'center',shadow:7,weight:500}));
  enRows.forEach((s,i)=>text(s,640,cy+(zhRows.length-1)*30+25+i*17,16,'#d8e7eb',{align:'center',shadow:6}));
  c.restore();
}

const narration=[
  [4.4,8.70,'把这一秒放慢 120 倍，从里到外看个清楚。','Let’s slow it down 120 times and look inside.'],
  [8.70,12.55,'神经信号沿着神经纤维奔跑，每秒可达 100 米。','Signals race through nerve fibers at up to 100 meters per second.'],
  [12.55,15.75,'心室收缩，把血液推入动脉。','The ventricles contract, driving blood into the arteries.'],
  [15.75,18.50,'一次搏动，泵出约 70 毫升血。','One beat pumps about 70 milliliters of blood.'],
  [18.50,21.30,'身体的细胞，平均每 10 个就有 8 个是红细胞。','Roughly eight out of every ten cells in the body are red blood cells.'],
  [21.30,24.10,'新造红细胞，每秒约 240 万个。','About 2.4 million new red blood cells are made each second.'],
  [24.10,26.05,'氧气离开红细胞，穿过毛细血管壁，进入肌细胞。','Oxygen leaves red cells, crosses the capillary wall and enters muscle.'],
  [26.05,28.85,'线粒体，细胞的发电站。','Mitochondria: the cell’s power plants.'],
  [28.85,30.64,'线粒体借助氧气，把能量充进一颗颗小电池：ATP。','Using oxygen, mitochondria pack energy into tiny batteries called ATP.'],
  [30.64,37.10,'充电的，是这台比病毒还小的分子涡轮。|每转一圈，充好 3 颗。','The charger is this molecular turbine, smaller|than a virus. Every turn charges three batteries.'],
  [37.10,39.50,'再靠近一点，看看肌细胞的质膜。','Now look closer at the muscle cell’s plasma membrane.'],
  [39.50,42.72,'细胞外的钠离子在等。通道的门关着。','Sodium ions are waiting outside. The channel is closed.'],
  [42.72,45.40,'门开了！只开千分之一秒，就放进上万个离子。','The gate opens! In a thousandth of a second, about 10,000 ions enter.'],
  [45.40,50.60,'从一扇分子小门，回到完整的人体。','From a molecular gate all the way back to the body.'],
  [50.66,55.18,'1.000 秒。身体交出了这一秒的清单。','1.000 seconds. Here is what your body did.']
];
const phases=[['人体','Body','1 m'],['器官','Organ','10 cm'],['组织','Tissue','1 mm'],['细胞','Cell','10 μm'],['细胞器','Organelle','1 μm'],['分子','Molecule','10 nm'],['原子','Atom','0.1 nm']];
const labels=[['心跳','Heartbeat'],['呼吸','Breath'],['神经信号走了','Nerve signal traveled'],['心脏泵出','Blood pumped'],['新造红细胞','New red blood cells'],['换新的细胞','Cells replaced'],['充好的 ATP 电池','ATP batteries charged'],['一瞬间门放进','Ions admitted in flash']];
const fmt=new Intl.NumberFormat('en-US');
const nums=(b,t,cues)=>[
  [`${b.toFixed(2)}`,'次'],[(.25*b).toFixed(3),'口'],[`${Math.round(b*100)}`,'米'],[`${Math.round(70*ease(12.77,17.4,t))}`,'毫升'],
  [fmt.format(Math.floor(2400000*b+.00001)),'个'],[fmt.format(Math.floor(3800000*b+.00001)),'个'],
  [b<.000001?fmt.format(Math.floor(9e16*b)):b<.01?`${(90000*b).toFixed(1)} 万亿`:`${(9*b).toFixed(2).replace(/0$/,'')} 万亿亿`,'个'],
  [fmt.format(Math.round(10000*ease(cues.t_ion_flash_s-.02,cues.t_ion_flash_s+.12,t))),'个']
];
function dashboard(b,t,cues,molecular,locked){
  const x=958,y=139,w=296,h=locked?375:300;
  panel(x,y,w,h,molecular?.69:.88);
  c.fillStyle=locked?'#e6cc8c':'#82cbd0';c.fillRect(x+1,y+12,2,20);
  text('这一秒',x+15,y+25,17,cyan,{weight:650});
  text('IN THIS SECOND',x+82,y+24,10,'#cfdee0',{font:mono});
  text(locked?'已锁定 / HOLD':'截至此刻 / LIVE',x+w-14,y+24,10,locked?gold:muted,{align:'right',font:mono});
  line(x+14,y+36,x+w-14,y+36,'#a1cbce45');
  const values=nums(b,t,cues), step=locked?40:31.5;
  labels.forEach(([zh,en],i)=>{
    const row=y+55+step*i, highlight=(i===6&&molecular)||(i===7&&t>cues.t_ion_flash_s);
    if(highlight){c.fillStyle=i===6?'rgba(245,206,139,.10)':'rgba(125,232,246,.12)';c.fillRect(x+8,row-15,w-16,locked?36:28);}
    text(zh,x+14,row,13,highlight?white:'#e4eef1',{weight:highlight?600:400});
    text(en,x+15,row+11,8.6,'#b2c4cc');
    const [n,u]=values[i];text(n,x+w-45,row+4,locked?18:15,highlight?(i===6?gold:'#aff8ff'):gold,{font:mono,align:'right',weight:highlight?700:500});
    text(u,x+w-14,row+3,11,'#d8dee0',{align:'right'});
    if(locked&&i<7)line(x+14,row+20,x+w-14,row+20,'#a1cbce22');
  });
}
function ecg(t,cues,heartbeat,locked){
  if(locked)t=Math.min(t,cues.final_heartbeat_s+.69);
  const x=974,y=44,w=267,h=73, ion=t-cues.t_ion_flash_s;
  const flash=Math.exp(-Math.pow(ion/.050,2));
  const closest=[...cues.cardiac_lub_dub_s.map(row=>row[0]),cues.final_heartbeat_s,cues.t_ion_flash_s].reduce((a,b)=>Math.abs(a-t)<Math.abs(b-t)?a:b);
  const near=Math.abs(closest-t)<.92, waveCenter=near?clamp(.56-(t-closest)*.44,.08,.94):.73;
  const read=near?.56:lerp(.16,.89,mod(t*.36));
  text('心电图  ECG',x,y+10,11,cyan,{weight:600,shadow:5});
  text(flash>.25?'R 波 / R-WAVE':locked?'锁定  HOLD':heartbeat>.32?'收缩期  SYSTOLE':'舒张期  DIASTOLE',x+w,y+10,10,flash>.25?white:'#c5d8d8',{align:'right',font:mono,shadow:4});
  for(let i=0;i<12;i++)line(x+i*w/11,y+18,x+i*w/11,y+h-7,'#afe6eb17');
  for(let i=0;i<4;i++)line(x,y+23+i*12,x+w,y+23+i*12,'#afe6eb1c');
  const wave=(u)=>{
    const q=u-waveCenter, g=(a,b)=>Math.exp(-((q-a)**2)/(b*b)), gain=near?1:.40;
    return y+46-g(-.17,.03)*4+gain*(g(-.034,.014)*5-g(0,.010)*(25+13*flash)+g(.027,.014)*10-g(.15,.05)*5)+1*Math.sin(u*23+t*.9);
  };
  c.beginPath();for(let i=0;i<=w;i++){const py=wave(i/w);if(i===0)c.moveTo(x,py);else c.lineTo(x+i,py);}
  c.strokeStyle='#8ececa75';c.lineWidth=1.15;c.stroke();
  c.beginPath();for(let i=0;i<=w*read;i++){const py=wave(i/w);if(i===0)c.moveTo(x,py);else c.lineTo(x+i,py);}
  c.strokeStyle=flash>.2?'#e2ffff':'#a0efdb';c.shadowColor='#59bdbd';c.shadowBlur=5+14*flash;c.lineWidth=1.6+1.8*flash;c.stroke();c.shadowBlur=0;
  line(x+w*read,y+20,x+w*read,y+h-7,'#b0f3e58a');dot(x+w*read,wave(read),2.6+1.9*flash,'#e6ffff');
  return {x:x+w*read,y:wave(read),flash};
}
function scaleDisplay(index,ruler,t,molecular){
  const x=50,y=543;
  line(x,y+2,x,y+126,'#7dc8d377');
  for(const [i,[zh,en,measure]] of phases.entries()){
    const dy=y+8+i*19,active=i===index;
    if(active){c.shadowColor='#8ff4f7';c.shadowBlur=8;dot(x,dy-4,3.2,cyan);c.shadowBlur=0;}
    else dot(x,dy-4,1.8,'#8eb1b584');
    text(`${zh}  ${en}`,x+13,dy,11.5,active?white:'#a1b7be',{weight:active?700:400,shadow:4});
    text(measure,x+149,dy,9,active?'#e1fcfa':'#9bb2b7',{font:mono,align:'right',shadow:3});
  }
  const rX=molecular?1096:46,rY=molecular?623:680,rW=molecular?139:156;
  line(rX,rY,rX+rW,rY,'#c9ecebdb',1.25);
  for(let i=0;i<=10;i++)line(rX+i*rW/10,rY,rX+i*rW/10,rY-(i%5===0?7:3),'#c9ecebdb');
  text(ruler,rX+rW,rY+22,17,white,{align:'right',weight:600,shadow:6});
  if(molecular)text('PROTON  H⁺   /   ATP SYNTHASE',rX+rW,rY+42,9,gold,{font:mono,align:'right',shadow:4});
}
function callout(x,y,X,Y,zh,en,style=cyan){
  const dir=X>x?1:-1, elbow=x+dir*19;
  line(x,y,elbow,y,style);line(elbow,y,X,Y,style);dot(X,Y,2.6,style);
  text(zh,x,y-9,14,white,{align:dir>0?'left':'right',weight:600,shadow:6});
  text(en,x,y+17,10,style,{align:dir>0?'left':'right',shadow:6});
}
function stopwatch(t,timing){
  starscape(t);
  const f=clamp((t-timing.stopwatch.start_s)/(timing.stopwatch.end_s-timing.stopwatch.start_s));
  const done=ease(3.30,3.65,t), inA=ease(0,.62,t);
  c.save();c.globalAlpha*=inA;
  text('人体时间实验',640,87,13,cyan,{align:'center',weight:600});
  line(439,81,561,81,'#5ba9b86a');line(719,81,841,81,'#5ba9b86a');
  text('你身体里的一秒钟',640,153,51,white,{align:'center',weight:700,shadow:11});
  text('ONE SECOND INSIDE YOU',640,189,19,'#b8dde3',{align:'center',font:mono,weight:600});
  const x=640,y=401,r=143;
  circle(x,y,r+32,'#437b8f4d');circle(x,y,r+19,'#38687f87');circle(x,y,r-22,'#2b627783');circle(x,y,r,'#508393a2');
  for(let i=0;i<120;i++){
    const a=i/120*TAU-Math.PI/2,l=i%30===0?15:i%10===0?9:4;
    line(x+Math.cos(a)*(r-l),y+Math.sin(a)*(r-l),x+Math.cos(a)*r,y+Math.sin(a)*r,i%10===0?'#b4e9edb5':'#6598a675',i%10===0?1.3:1);
  }
  const a=-Math.PI/2+f*TAU;
  c.shadowColor='#69e1ec';c.shadowBlur=10;circle(x,y,r+2,'#9efbfa',3.0,-Math.PI/2,a+.001);c.shadowBlur=0;
  for(const dist of [r+26,r+39])dot(x+Math.cos(a)*dist,y+Math.sin(a)*dist,2.9,cyan);
  text(f.toFixed(3),x,y+16,62,white,{align:'center',font:mono,weight:600,shadow:12});
  text('真实时间  /  REAL TIME',x,y+52,12,cyan,{align:'center',font:mono});
  const a2=t*TAU*.047;
  circle(x,y,r+32,'#a5efeb84',1.3,a2,a2+1.20);circle(x,y,r+32,'#a5efeb84',1.3,a2+Math.PI,a2+Math.PI+1.20);
  line(466,619,814,619,'#76b8c16e');
  for(let i=0;i<=5;i++){const X=466+i*348/5;line(X,612,X,626,'#8ec7cf8e');if(f>=i/5)dot(X,619,3.4,'#bdf7ee');}
  text('0.000 s',466,645,12,muted,{font:mono});text('1.000 s',814,645,12,done>0?white:muted,{align:'right',font:mono});
  c.restore();
}
function ending(t){
  starscape(t,.9);
  const a=ease(55.0,55.48,t)*(1-.27*ease(57.75,58,t));
  c.save();c.globalAlpha*=a;
  const x=640,y=236;
  circle(x,y,61,'#62aeb979');circle(x,y,70,'#386a7478');circle(x,y,58,'#a1e6e7',1.5,-Math.PI/2,-Math.PI/2+TAU*ease(55.1,56.3,t));
  for(let i=0;i<30;i++){const q=i/30*TAU;dot(x+70*Math.cos(q),y+70*Math.sin(q),i%5===0?1.8:1,'#a0dfe0');}
  text('1.000',640,244,25,white,{align:'center',font:mono,weight:700});text('秒 / SEC',640,264,10,cyan,{align:'center',font:mono});
  text('你什么都没做，可你的身体，把这些事全做完了。',640,365,31,white,{align:'center',weight:600,shadow:12});
  text('You did nothing. Your body did all of this.',640,406,19,'#cee2e6',{align:'center',shadow:6});
  line(475,456,805,456,'#85c5ce66');
  text('你身体里的一秒钟',640,513,29,white,{align:'center',weight:600});
  text('ONE SECOND INSIDE YOU',640,543,15,cyan,{align:'center',font:mono,weight:600});
  c.restore();
}
export function drawHUD(t,timing,{bio,act,stageId,pulse,scale,ruler,projection}){
  const cues=timing.audio_cues;
  c.clearRect(0,0,1280,720);
  if(t<4.64){c.save();c.globalAlpha=1-ease(4.12,4.64,t);stopwatch(t,timing);c.restore();}
  if(t>=54.83){c.save();c.globalAlpha=ease(54.94,55.36,t);ending(t);c.restore();}
  const alpha=ease(4.36,5.16,t)*(1-ease(54.90,55.37,t));
  if(alpha<.001)return;
  c.save();c.globalAlpha=alpha;
  const locked=act>=8,molecular=stageId==='turbine';
  const x=51,y=76,a=-Math.PI/2;
  circle(x+7,y,24,'#afdddf60',1);circle(x+7,y,24,cyan,2.15,a,a+TAU*Math.max(.02,bio));
  dot(x+7+24*Math.cos(a+bio*TAU),y+24*Math.sin(a+bio*TAU),2.6,'#d0fcf6');
  text(locked?'真实时间 · 已锁定 / HOLD':'真实时间 / REAL TIME',95,y-21,11,'#d5e8e8',{weight:650,shadow:5});
  text(bio.toFixed(3)+' s',94,y+13,35,white,{font:mono,weight:600,shadow:7});
  text('120× 慢放  /  SLOW MOTION',96,y+34,11,cyan,{font:mono,shadow:5});
  const trace=ecg(t,cues,pulse,locked);
  dashboard(bio,t,cues,molecular,locked);
  scaleDisplay(scale,ruler,t,molecular);
  const rows=narration.find(([start,end])=>t>=start&&t<end);
  if(rows)caption(rows[2],rows[3],t,rows[0],rows[1]);
  if(t>4.53&&t<7.08){
    c.save();c.globalAlpha*=ease(4.53,4.91,t)*(1-ease(6.60,7.08,t));
    text('120×',55,232,75,white,{font:mono,weight:700,shadow:11});
    text('时间慢放  /  TIME DILATION',58,259,13,cyan,{weight:600,shadow:6});
    line(57,279,232,279,'#a4e1e69d');c.restore();
  }
  if(t>8.93&&t<12.6&&projection)callout(218,241,projection.x,projection.y,'神经传导 · 100 米/秒','NERVE IMPULSE  /  100 m/s');
  if(t>13.1&&t<17.7&&projection)callout(184,339,projection.x,projection.y,'心室 · 收缩与舒张','VENTRICLES  /  SYSTOLE & DIASTOLE','#ffb6a1');
  if(t>19.2&&t<23.3&&projection)callout(147,315,projection.x,projection.y,'双凹红细胞','BICONCAVE RED BLOOD CELL','#ffb5a2');
  if(t>24.6&&t<27.8&&projection)callout(158,307,projection.x,projection.y,'氧气进入线粒体','OXYGEN DELIVERY  /  O₂');
  if(molecular&&t>33.88&&t<38.01){
    c.save();c.globalAlpha*=ease(33.88,34.23,t)*(1-ease(37.72,38.01,t));
    if(t>35.39){
      c.save();c.globalAlpha*=ease(35.39,35.72,t);panel(40,199,269,126,.67);
      text('真实速度 / TRUE SPEED',58,220,11,muted,{font:mono});text('每秒 100+ 圈',58,247,23,white,{weight:600});
      text('画面速度 / ON SCREEN',58,274,11,muted,{font:mono});text('每秒约 1 圈',58,303,20,white,{weight:600});c.restore();
    }
    if(projection)callout(872,467,projection.x,projection.y,'转子：被质子流推着转','Rotor: pushed by a flow of protons','#e4f9f6');
    c.restore();
  }
  if(t>=39.1&&t<45.4&&projection){
    const opened=t>=cues.gate_open.start_s&&t<cues.gate_open.end_s;
    const fired=t>=cues.t_ion_flash_s;
    callout(155,328,projection.x,projection.y,opened?'电压门控 · 开启':fired?'离子进入细胞':'电压门控 · 关闭',opened?'VOLTAGE GATE  /  OPEN':fired?'ION INFLUX  /  Na⁺':'VOLTAGE GATE  /  CLOSED',fired?cyan:gold);
    text('细胞外  /  EXTRACELLULAR',65,221,12,'#f3d3ad',{weight:600,shadow:5});
    text('细胞内  /  CYTOPLASM',66,477,12,cyan,{weight:600,shadow:5});
    if(trace.flash>.05){
      c.save();c.globalAlpha*=trace.flash;
      c.shadowColor='#97ecff';c.shadowBlur=17;
      const corners=[[trace.x,trace.y],[934,trace.y],[918,172],[831,172],[798,227],[738,227],[projection.x,projection.y]];
      c.beginPath();corners.forEach(([X,Y],i)=>i?c.lineTo(X,Y):c.moveTo(X,Y));c.strokeStyle='#bffaff';c.lineWidth=2.4;c.stroke();
      c.restore();
    }
  }
  if(locked){line(47,155,212,155,'#9fe5e273');text('一秒已结束',48,183,22,white,{weight:600,shadow:4});text('MEASUREMENT COMPLETE',49,205,11,cyan,{font:mono});}
  c.restore();
}
