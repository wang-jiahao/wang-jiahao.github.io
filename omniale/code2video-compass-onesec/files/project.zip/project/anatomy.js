import * as T from 'three';
import {TAU,clamp,lerp,ease,mod,rng,v,sphere,tiny,material,lit,flat,mesh,ball,curve,tube,ring,stage,aim,loft,organic,instances,pose,glow,spokes} from './geometry.js';

const ghost = new T.ShaderMaterial({
  transparent:true,side:T.FrontSide,depthWrite:false,blending:T.AdditiveBlending,
  uniforms:{time:{value:0}},
  vertexShader:`varying vec3 n; varying vec3 view; varying vec3 p;
  void main(){p=position; vec4 q=modelViewMatrix*vec4(position,1.);n=normalize(normalMatrix*normal);view=-q.xyz;gl_Position=projectionMatrix*q;}`,
  fragmentShader:`uniform float time; varying vec3 n; varying vec3 p; varying vec3 view;
  void main(){float f=pow(1.-abs(dot(normalize(n),normalize(view))),2.4);
  float a=.038+.57*f;float scan=exp(-26.*abs(p.y-2.8*sin(time*.61)));float line=pow(.5+.5*sin(p.y*105.),22.);
  vec3 c=mix(vec3(.10,.46,.73),vec3(.47,.87,1.),f);gl_FragColor=vec4(c,a+line*.04+scan*.13);}`
});

export function bodyStage() {
  const g=stage(0x061724,12,35,[0xb7eeff,0x244055,1.3,[[4,6,6],0xa9eaff,2.1],[[-6,1,-5],0x4aaaed,2]]);
  const body=new T.Group();g.scene.add(body);
  const profile=(rows,side=1)=>mesh(body,loft(rows.map(([x,y,z,rx,rz])=>[x*side,y,z,rx,rz])),ghost);
  profile([[0,-.94,0,.17,.13],[0,-.72,0,.59,.34],[0,-.48,0,.74,.42],[0,-.08,0,.69,.38],[0,.35,0,.58,.33],[0,.76,0,.69,.40],[0,1.2,0,.85,.46],[0,1.54,0,.95,.43],[0,1.77,0,.97,.32],[0,1.95,0,.67,.30],[0,2.06,0,.37,.28],[0,2.18,0,.25,.23],[0,2.45,0,.25,.23],[0,2.49,0,.18,.18]]);
  profile([[0,2.38,.08,.14,.18],[0,2.49,.13,.28,.29],[0,2.64,.10,.36,.34],[0,2.89,.03,.42,.39],[0,3.16,-.01,.44,.40],[0,3.39,-.04,.39,.37],[0,3.57,-.04,.26,.26],[0,3.65,-.04,.025,.025]]);
  ball(body,ghost,[0,2.89,.39],[.085,.135,.14]);
  const nerves=[];
  const nerveMat=lit(0x53d0eb,.42,{transparent:true,opacity:.72,depthWrite:false});
  const bone=lit(0x518bab,.20,{transparent:true,opacity:.32,depthWrite:false});
  const vessel=lit(0xe25254,.9,{transparent:true,opacity:.77,depthWrite:false});
  const brainMat=lit(0x7cb9ff,.40,{transparent:true,opacity:.36,depthWrite:false});
  const lungMat=lit(0x428bb2,.26,{transparent:true,opacity:.30,depthWrite:false});
  const lungs=new T.Group();body.add(lungs);
  for(const s of [-1,1]){
    profile([[1.66,-1.40,.03,.025,.05],[1.66,-1.2,.05,.10,.10],[1.6,-.94,.04,.14,.13],[1.53,-.65,.01,.12,.12],[1.48,-.35,0,.15,.15],[1.4,.03,0,.19,.19],[1.31,.34,0,.17,.16],[1.25,.60,0,.20,.19],[1.14,.96,0,.25,.24],[1.02,1.35,0,.30,.29],[.91,1.63,0,.30,.29],[.87,1.83,0,.15,.18]],s);
    for(let j=0;j<4;j++)ball(body,ghost,[s*(1.59+j*.047),-1.38+j*.026,.09],[.029,.143-j*.012,.034]);
    ball(body,ghost,[s*1.53,-1.12,.13],[.055,.13,.045]);
    profile([[.51,-3.59,-.01,.12,.15],[.51,-3.48,-.02,.15,.15],[.51,-3.16,-.03,.138,.14],[.51,-2.91,-.06,.17,.16],[.50,-2.62,-.07,.226,.21],[.46,-2.31,-.02,.23,.21],[.45,-2.02,.03,.202,.19],[.41,-1.75,.015,.23,.238],[.40,-1.42,0,.285,.28],[.38,-1.02,-.02,.33,.31],[.35,-.65,-.018,.34,.32],[.32,-.37,0,.29,.30]],s);
    ball(body,ghost,[s*.51,-3.58,.12],[.166,.14,.31]);
    ball(body,ghost,[s*.422,2.96,.015],[.073,.165,.093]);
    for(let k=0;k<2;k++){
      const arm=curve([[1.65,-1.34,.08],[1.56,-.7,.10],[1.31,.40,.15],[1.12,1.41,.14],[.60,1.70,.13],[.12,1.77,-.12],[.07,2.42,-.08],[.16,3.13,.04]].map(([x,y,z],i)=>[s*(x+.04*k*Math.sin(i)),y,z+.06*k]));
      const leg=curve([[.52,-3.52,.26],[.53,-2.60,.09],[.45,-1.92,.15],[.41,-1.02,.2],[.12,-.39,-.13],[.08,.50,-.25],[.06,1.7,-.18],[.06,2.57,-.12],[.17,3.16,.14]].map(([x,y,z],i)=>[s*(x+k*.044*Math.cos(i)),y,z+k*.07]));
      for(const path of [arm,leg]){nerves.push(path);tube(body,path,.012-k*.003,nerveMat,40,5);}
    }
    for(let j=0;j<8;j++){
      const y=1.76-j*.19, rx=.72-.10*Math.abs(j-3)/4;
      tube(lungs,[[s*.055,y,-.26],[s*rx*.59,y-.07,-.28],[s*rx,y-.16,.015],[s*rx*.67,y-.235,.30],[s*.096,y-.20,.35]],.024,bone,22,6);
    }
    mesh(lungs,organic(12+s,.18),lungMat,[s*.35,1.02,.01],[.32,.66,.29]).rotation.z=s*-.19;
    mesh(body,organic(9+s,.23),brainMat,[s*.172,3.18,.005],[.24,.29,.31]);
    for(let j=0;j<4;j++){
      const y=3.04+j*.10;
      tube(body,[[s*.08,y,.26],[s*.22,y+.04,.27],[s*.34,y+.005,.18],[s*.35,y-.05,.07]],.009,nerveMat,15,5);
    }
  }
  for(let j=0;j<23;j++){
    const y=-.67+j*.127;
    ball(body,bone,[0,y,-.252],[.096,.055,.071]);
  }
  tube(body,[[0,-.8,-.16],[0,.2,-.25],[0,1.49,-.17],[0,2.43,-.12],[0,3.2,.02]],.02,nerveMat);
  const core=mesh(body,organic(7,.20),vessel,[.21,1.04,.35],[.243,.32,.21]);core.rotation.z=.29;
  tube(body,[[.15,.83,.27],[.33,1.19,.29],[.20,1.47,.21],[-.03,1.4,.14],[-.05,.02,.09],[.15,-.60,.08]],.035,vessel);
  const scan=new T.Group();scan.position.y=-3.72;g.scene.add(scan);
  for(const r of [1.06,1.42,1.62,1.92,2.43,2.91])ring(scan,r,.008,flat(0x3c93ab,{transparent:true,opacity:.27}));
  spokes(scan,96,1.63,1.88,new T.LineBasicMaterial({color:0x62c9dd,transparent:true,opacity:.31}));
  const random=rng(807);
  const dust=Array.from({length:340},()=>[(random()-.5)*35,(random()-.5)*19,(random()-.66)*20,random()]);
  const stars=glow(g.scene,dust.length,{size:3.8,opacity:.48,color:0x68c8fd});
  const sparks=glow(body,nerves.length*8,{size:12,opacity:1.5,color:0xffe3ae,seed:321});
  return {...g,update(t,pulse,zoom=0,locked=false){
    const f=locked?50.9:t;
    ghost.uniforms.time.value=f;
    const breath=.5+.5*Math.sin(f*1.04);
    lungs.scale.set(1+.028*breath,1+.007*breath,1+.045*breath);
    const contraction=1+.28*pulse;core.scale.set(.243*contraction,.32/contraction,.21*contraction);
    scan.rotation.y=f*.067;
    stars.move(i=>[dust[i][0]+Math.sin(f*.22+dust[i][3]*TAU)*.24,dust[i][1]+.17*Math.cos(f*.38+i),dust[i][2]]);
    sparks.mat.uniforms.opacity.value=.3+1.85*ease(8.2,10.5,t)*(1-.35*zoom);
    sparks.move(i=>{const lane=i>>3,j=i%8;return nerves[lane].getPointAt(mod(f*.68+lane*.117-j*.013)).toArray();});
    const orbit=locked?.08:.12*Math.sin(f*.52);
    aim(g.camera,[lerp(orbit*12.9,.25,zoom),lerp(.17,1.22,zoom),lerp(12.9,2.22,zoom)],
      [lerp(.53,.20,zoom),lerp(.03,1.04,zoom),0],36,0);
  }};
}

export function heartStage(){
  const g=stage(0x291320,13,35,[0xf9b3bc,0x542537,1.6,[[1,5,6],0xffd2b0,2.5],[[-4,-2,1],0x5da6cc,1.5],[[2,1,-4],0xe43f55,2.5]]);
  const heart=new T.Group();g.scene.add(heart);heart.rotation.z=.14;
  const blood=material(0xaa243b,{roughness:.36,metalness:.12});
  const scarlet=material(0xd05259,{roughness:.39});
  const vein=material(0x6c386a,{roughness:.34});
  const coronary=lit(0xf98471,.15);
  const left=mesh(heart,loft([[.55,-2.37,0,.02,.03],[.52,-2.19,.01,.40,.35],[.46,-1.88,.04,.73,.62],[.43,-1.34,.01,1.02,.88],[.40,-.73,0,1.20,.98],[.34,-.16,-.02,1.25,1.04],[.35,.34,-.03,1.16,1.03],[.40,.67,-.10,.88,.80],[.48,.94,-.2,.49,.42],[.51,1.02,-.29,.025,.025]],56),blood);
  const right=mesh(heart,organic(11,.20,44,28),scarlet,[-.81,-.37,.10],[1.05,1.41,.92]);right.rotation.z=-.39;
  mesh(heart,organic(8,.16),blood,[.94,.88,-.12],[.68,.58,.70]).rotation.z=.31;
  mesh(heart,organic(14,.13),vein,[-.86,.83,-.33],[.67,.68,.66]);
  const aorta=curve([[.37,.42,-.15],[.31,1.34,-.20],[.03,2.15,-.25],[-.64,2.40,-.38],[-1.03,1.96,-.65],[-1.12,1.48,-.87]]);
  const artery=curve([[-.43,.48,.24],[-.51,1.27,.26],[-.23,1.72,.16],[.57,1.73,-.02],[1.24,1.58,-.18]]);
  tube(heart,aorta,.39,scarlet,52,20);tube(heart,artery,.30,vein,46,18);
  tube(heart,[[-1.23,.20,-.19],[-1.40,.98,-.29],[-1.35,1.66,-.35],[-1.48,2.13,-.41]],.25,vein,30,14);
  for(let i=0;i<3;i++){
    const x=-.53+i*.27;
    tube(heart,[[x,2.2,-.33],[x-.09,2.57,-.39],[x-.18,2.84-i*.10,-.41]],.10,scarlet,19,12);
  }
  const channels=[[[.18,.68,1],[.30,.24,1.03],[.13,-.44,1.19],[.21,-1.02,.99],[.42,-1.57,.80],[.54,-2.05,.50]],[[.23,.24,1.03],[.72,.26,1.04],[1.25,.13,.82],[1.48,-.24,.61]],[[-.13,-.25,1.12],[-.65,-.35,1.10],[-1.06,-.58,.84],[-1.30,-.67,.67]],[[.22,-.95,1.02],[.73,-.85,.94],[1.06,-1.03,.66]],[[.27,-1.19,.95],[-.16,-1.23,.85],[-.47,-1.51,.62]]];
  const cords=channels.map((line,i)=>{const path=curve(line);tube(heart,path,.041/(1+i*.25),coronary,28,8);return path;});
  const cut=new T.Group();heart.add(cut);
  const rim=material(0xec9691,{roughness:.38});
  const inside=material(0x320917,{roughness:.55,emissive:0x8b1435,emissiveIntensity:.16});
  for(const [x,y,sx,sy] of [[.61,-.64,.67,1.24],[-.56,-.49,.46,.94]]){
    const pocket=new T.Group();pocket.position.set(x,y,1.07);pocket.rotation.z=.17;cut.add(pocket);
    ball(pocket,inside,[0,0,0],[sx,sy,.09]);
    const lip=ring(pocket,1,.075,rim,[0,0,.035]);lip.rotation.x=0;lip.scale.set(sx,sy,.55);
    for(let i=0;i<8;i++){
      const u=i/7;
      tube(pocket,[[-sx*.85,lerp(-.62,.45,u)*sy,.02],[-sx*.47,lerp(-.79,.76,u)*sy,.08],[-sx*.04,lerp(-.82,.93,u)*sy,.069]],.024,rim,14,6);
    }
  }
  const random=rng(31), debris=Array.from({length:190},()=>[(random()-.5)*20,(random()-.5)*13,(random()-.75)*19]);
  const dust=glow(g.scene,debris.length,{color:0xd95975,size:5.5,opacity:.35});
  const flow=glow(heart,96,{color:0xffae7b,size:8,opacity:1});
  return {...g,update(t,pulse,zoom=0,section=0){
    left.scale.set(1-.13*pulse,1+.06*pulse,1-.12*pulse);
    right.scale.set(1.05-.16*pulse,1.41+.08*pulse,.92-.11*pulse);
    heart.scale.setScalar(1+.035*pulse);heart.rotation.y=.24*Math.sin((t-12)*.55)-.18*section;
    cut.visible=section>.20;cut.scale.setScalar(lerp(.4,1,section));
    dust.move(i=>[debris[i][0]+.3*Math.sin(t*.46+i),debris[i][1]+.32*Math.cos(t*.53+i),debris[i][2]]);
    flow.mat.uniforms.opacity.value=.25+pulse*1.15;
    flow.move(i=>{
      const p=(i<60?(i%2?aorta:artery):cords[i%cords.length]).getPointAt(mod(t*(i<60?.88:.51)+i*.103));
      if(i<60){p.x+=.20*Math.sin(i*1.72);p.z+=.18*Math.cos(i*2.4);}
      return p.toArray();
    });
    aim(g.camera,[.65*Math.cos(t*.53)-.35*zoom,.64+1.05*zoom,lerp(10,3.0,zoom)],
      [lerp(.42,.06,zoom),lerp(.05,1.32,zoom),0],39,-.025*zoom);
  }};
}
