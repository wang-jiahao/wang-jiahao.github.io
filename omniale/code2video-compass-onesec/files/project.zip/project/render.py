"""Frame-accurate local Chromium capture and H.264/AAC assembly."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import subprocess
import tempfile
from threading import Thread
from time import monotonic

from playwright.sync_api import sync_playwright


PROJECT = Path(__file__).resolve().parent
DELIVERY = PROJECT.parent


class QuietHTTP(SimpleHTTPRequestHandler):
    def log_message(self, *_):
        pass


def browser_flags(backend):
    return [
        "--use-gl=angle", f"--use-angle={backend}", "--enable-webgl",
        "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist",
        "--disable-background-timer-throttling", "--disable-renderer-backgrounding",
    ]


def capture(url, spec, backend, work):
    width, height, fps = (spec[key] for key in ("width", "height", "fps"))
    with sync_playwright() as pw:
        browser = pw.chromium.launch(args=browser_flags(backend))
        page = browser.new_page(viewport={"width": width, "height": height}, device_scale_factor=1)
        errors = []
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.goto(url + "/project/index.html?capture=1", wait_until="load")
        try:
            page.wait_for_function("window.filmReady === true", timeout=30000)
            page.evaluate("document.fonts.ready.then(() => true)")
            return work(page, fps)
        except Exception as error:
            raise RuntimeError("\n".join(errors) or str(error)) from error
        finally:
            browser.close()


def preview(page, fps, output, seconds):
    output.mkdir(parents=True, exist_ok=True)
    before = monotonic()
    for t in seconds:
        page.evaluate("t => window.seekTo(t)", t)
        page.screenshot(path=output / f"frame-{t:06.3f}.jpg", type="jpeg", quality=96)
    print(f"{len(seconds)} preview frames in {monotonic() - before:.2f}s", flush=True)


def encode_video(page, fps, frames, output):
    cmd = [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-threads", "2",
        "-f", "image2pipe", "-framerate", str(fps), "-c:v", "mjpeg", "-i", "pipe:0",
        "-vf", "scale=out_color_matrix=bt709:out_range=tv,format=yuv420p",
        "-an", "-c:v", "libx264", "-preset", "fast", "-crf", "16", "-threads", "6",
        "-pix_fmt", "yuv420p", "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709",
        "-g", str(2 * fps), "-video_track_timescale", "30000", str(output),
    ]
    with subprocess.Popen(cmd, stdin=subprocess.PIPE) as encoder:
        try:
            for i in frames:
                page.evaluate("t => window.seekTo(t)", i / fps)
                encoder.stdin.write(page.screenshot(type="jpeg", quality=96, timeout=60000))
                if (i - frames.start + 1) % 90 == 0:
                    print(f"{i - frames.start + 1}/{len(frames)} frames", flush=True)
        finally:
            encoder.stdin.close()
        if encoder.wait():
            raise RuntimeError(f"Encoding failed for {output.name}")
    print(f"{len(frames)}/{len(frames)} frames encoded", flush=True)


def render(url, spec, backend, output):
    from audio import synthesize

    count = round(spec["duration_s"] * spec["fps"])
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".render-", dir=output.parent) as scratch:
        folder = Path(scratch)
        silent_video = folder / "picture.mp4"
        audio = folder / "score.wav"
        synthesize(spec, audio)
        work = partial(encode_video, frames=range(count), output=silent_video)
        capture(url, spec, backend, work)
        staged = folder / "complete.mp4"
        subprocess.run([
            "ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(silent_video),
            "-i", str(audio), "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac",
            "-b:a", "256k", "-ar", "48000", "-ac", "2", "-movflags", "+faststart", str(staged),
        ], check=True)
        os.replace(staged, output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preview", type=float, nargs="+", metavar="SECONDS")
    parser.add_argument("--preview-dir", type=Path, default=DELIVERY.parent / ".work" / "previews")
    parser.add_argument("--output", type=Path, default=DELIVERY / "video.mp4")
    parser.add_argument("--backend", choices=["swiftshader", "d3d11"], default="swiftshader")
    parser.add_argument("--serve", action="store_true", help="Serve the editable browser preview on localhost")
    args = parser.parse_args()
    timing = json.loads((DELIVERY / "timeline.json").read_text(encoding="utf-8"))
    with ThreadingHTTPServer(("127.0.0.1", 0), partial(QuietHTTP, directory=DELIVERY)) as server:
        url = f"http://127.0.0.1:{server.server_port}"
        if args.serve:
            print(url + "/project/index.html", flush=True)
            server.serve_forever()
            return
        thread = Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            if args.preview:
                work = partial(preview, output=args.preview_dir, seconds=args.preview)
                capture(url, timing, args.backend, work)
            else:
                render(url, timing, args.backend, args.output.resolve())
        finally:
            server.shutdown()
            thread.join()


if __name__ == "__main__":
    main()
