"""Original stereo score and effects synthesized from the shared cue sheet."""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy import signal
from scipy.io import wavfile


RATE = 48000
TAU = 2 * np.pi


def smooth(x):
    x = np.clip(x, 0, 1)
    return x * x * (3 - 2 * x)


def fade(t, length, attack, release):
    return smooth(t / attack) * smooth((length - t) / release)


def synthesize(spec, output):
    cues = spec["audio_cues"]
    length = spec["duration_s"]
    frames = round(length * RATE)
    track = np.zeros((frames, 2), dtype=np.float32)
    random = np.random.default_rng(84297)

    def time(duration):
        return np.arange(round(duration * RATE)) / RATE

    def noise(t, low, high):
        sos = signal.butter(2, [low, high], btype="bandpass", fs=RATE, output="sos")
        return signal.sosfilt(sos, random.standard_normal(t.size))

    def put(sound, at, pan=0., delay=0.):
        offset = round(at * RATE)
        if sound.ndim == 1:
            sides = np.stack([sound * np.sqrt((1 - pan) / 2), sound * np.sqrt((1 + pan) / 2)], axis=1)
        else:
            sides = sound
        shift = round(delay * RATE)
        for channel in range(2):
            start = offset + (shift if channel else 0)
            lo, hi = max(0, start), min(frames, start + sides.shape[0])
            if hi > lo:
                track[lo:hi, channel] += sides[lo-start:hi-start, channel]

    # Changing voicings sustain the narrative through the transient effects.
    chords = [
        (0, 5.0, [49, 73.42, 110, 146.83], .037, .48, 1.1),
        (4.54, 10.37, [41.20, 61.74, 82.41, 123.47, 164.81], .105, 1.3, 1.0),
        (9.25, 19.28, [43.65, 65.41, 87.31, 130.81], .073, 1.2, 1.1),
        (18.18, 25.45, [49, 73.42, 98, 146.83, 196], .096, .95, 1.0),
        (24.23, 29.60, [55, 82.41, 110, 164.81, 220], .122, 1.1, 1.2),
        (37.08, 45.8, [46.25, 69.30, 92.50, 138.59, 207.65], .088, .85, .85),
        (44.92, 50.92, [49, 73.42, 110, 146.83, 220], .108, .6, .9),
        (50.25, 56.20, [48.999, 73.42, 98, 146.83, 185], .099, 1.0, 1.3),
        (54.8, 58.0, [49, 73.42, 98, 146.83, 196, 246.94], .103, .83, 1.33),
    ]
    for index, (start, end, notes, level, attack, release) in enumerate(chords):
        t = time(end - start)
        env = fade(t, end-start, attack, release)
        for j, hz in enumerate(notes):
            drift = .13 * np.sin(TAU * (.17 + j*.041) * t + j)
            phase = TAU * hz * t + drift
            voice = np.sin(phase + .27*np.sin(TAU*.23*t+j))
            voice += (.11+.07*np.sin(TAU*.31*t+j)) * np.sin(2*phase+.6)
            voice *= env * level * (.90 + .10*np.sin(TAU*.41*t+index+j)) / (1+.30*j)
            put(voice, start, .30*np.sin(j*1.17+index), .0014 if j%2 else 0)
        bed = noise(t, 200 + 41*index, 510 + 110*index) * env * level * .65
        put(bed, start, -.32, .011)

    for i, at in enumerate(cues["stopwatch_ticks_s"]):
        t = time(.095)
        f = 2650 if i in (0, 5) else 4010
        env = smooth(t/.0007)*np.exp(-t*(82 if i in (0,5) else 122))
        tick = env*(.22*np.sin(TAU*f*t)+.13*np.sin(TAU*1.61*f*t)+.30*noise(t,2000,9500))
        put(tick, at, (-1)**i*.19)
        put(tick*.17, at+.047, (-1)**(i+1)*.43)

    drop = cues["time_dilation_sweep"]
    start, end = drop["start_s"], drop["end_s"]
    t = time(end-start)
    k = np.log(drop["to_hz"]/drop["from_hz"])/(end-start)
    phase = TAU*drop["from_hz"]*np.expm1(k*t)/k
    env = fade(t, end-start, .028, .29)
    air = noise(t, 800, 7300) * np.exp(-4.6*t)
    drop_voice = env*(.145*np.sin(phase)+.069*np.sin(.5*phase)+.11*air)
    put(drop_voice, start, -.18, .007)
    t = time(1.30)
    put(.20*fade(t,1.30,.035,.59)*np.sin(TAU*(43*t+4.0*(1-np.exp(-2*t)))), 4.56, .05)

    def heartbeat(at, hz, amp, duration, pan):
        t = time(duration)
        p = TAU * (hz*t + hz*.28*(1-np.exp(-10*t))/10)
        env = smooth(t/.021)*np.exp(-t*(11.4 if hz<70 else 17.7))*smooth((duration-t)/.08)
        low = amp*env*(np.sin(p)+.28*np.sin(p*1.42+.27)+.14*noise(t,56,143))
        put(low, at, pan)

    for i, (lub, dub) in enumerate(cues["cardiac_lub_dub_s"]):
        heartbeat(lub, 47+i%3*3, .52, .50, -.06)
        heartbeat(dub, 74+i%3*3, .33, .39, .10)
    heartbeat(cues["final_heartbeat_s"], 48, .47, .62, 0)
    heartbeat(cues["final_heartbeat_s"]+.33, 75, .26, .41, .04)

    for n, at in enumerate([9.43, 10.33, 11.04, 11.42, 12.17, 20.14, 20.85, 21.78, 22.91, 24.03, 25.24, 26.84, 38.98, 40.16, 41.22]):
        t = time(.44)
        f = 550+94*(n%7)
        phase = TAU*(f*t+50*(1-np.exp(-6*t)))
        tinkle = smooth(t/.008)*np.exp(-t*14)*(.038*np.sin(phase)+.015*np.sin(2.28*phase)+.028*noise(t,960,4810))
        put(tinkle, at, .66*np.sin(n*2.29), .002)

    rotor = cues["mitochondrial_turbine"]
    at, end = rotor["start_s"], rotor["end_s"]
    t = time(end-at)
    f = t + at - spec["atp_reference_window"]["start_s"]
    spin = TAU*(rotor["rotations_per_s"]*f + .023*np.sin(f*1.38))
    env = fade(t,end-at,.63,.72)
    for i, hz in enumerate([58.27, 87.31, 116.54, 174.61, 233.08, 349.23, 466.16]):
        phase = TAU*hz*t + .7*np.sin(spin*(1+i%3)+i*.4) + .20*np.sin(TAU*.19*t)
        rotor_amp = np.power(.5+.5*np.sin(spin*3+i*.65),1.5)
        carrier = .71*np.sin(phase)+(.09+.25*rotor_amp)*np.sin(2.009*phase+.8)
        carrier *= (.092/(1+.30*i))*env*(.44+.43*rotor_amp+.13*np.sin(spin+i)**2)
        put(carrier, at, .58*np.sin(i*1.9), .003 + i*.00053)
    turn = rotor["rotations_per_s"] * rotor["catalytic_events_per_turn"]
    ref = spec["atp_reference_window"]["start_s"]
    for i in range(-6, 23):
        event = ref+i/turn
        if at+.05<event<end-.08:
            t = time(.43)
            hz = [698.46, 880.0, 1046.5][i%3] * (1+(i%5)*.002)
            env = smooth(t/.011)*np.exp(-t*11)
            shimmer = env*(.044*np.sin(TAU*hz*t)+.033*np.sin(TAU*1.996*hz*t)+.019*noise(t,1650,5580))
            put(shimmer, event, .66*np.sin(i*2.16), .005)
            put(shimmer*.29, event+.099, -.55*np.sin(i*2.16))

    at = cues["t_ion_flash_s"]
    t = time(.33)
    env = smooth(t/.0007)*np.exp(-t*21)
    phase = TAU*(2150*t+202*(1-np.exp(-19*t)))
    electrical = env*(.57*noise(t,1370,7850)+.34*np.sin(phase)+.14*np.sin(1.55*phase+.27))
    put(electrical, at, .19, .00065)
    put(electrical*.19, at+.041, -.62, .002)
    t = time(.99)
    put(.18*noise(t,820,5600)*fade(t,.99,.056,.52), at+.018, -.36, .010)

    for i, at in enumerate(cues["major_transitions_s"]):
        if at == 4.4:
            continue
        duration = .79 if 45.3 < at < 50.7 else 1.11
        t = time(duration)
        f0, f1 = (235, 1620) if 45.3 < at < 50.7 else (1250, 170)
        phase = TAU*(f0*t+.5*(f1-f0)*t*t/duration)
        env = fade(t,duration,.26,.29)
        whoosh = env*(.031*np.sin(phase)+.10*noise(t,190+25*i,2200+100*i))
        put(whoosh, at-.29, .43*np.sin(i*2.1), .012)

    t = time(2.8)
    for i, hz in enumerate([196, 246.94, 293.66, 392]):
        bell = .064/(1+i*.17)*fade(t,2.8,.023,1.08)*np.exp(-t*1.55)*np.sin(TAU*hz*t+.13*np.sin(TAU*2*hz*t))
        put(bell, cues["ending_resolution_s"]+.071*i, .43*np.sin(i*2.1), .004)

    rms = np.sqrt(np.mean(track**2))
    track *= .123 / rms
    track = .79 * np.tanh(track / .79)
    track[-round(.045*RATE):] *= np.linspace(1,0,round(.045*RATE))[:,None]
    wavfile.write(output, RATE, track.astype(np.float32,copy=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    spec = json.loads((Path(__file__).resolve().parents[1] / "timeline.json").read_text(encoding="utf-8"))
    synthesize(spec, args.output)
