import * as T from 'three';

export const TAU = Math.PI * 2;
export const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a, b, x) => a + (b - a) * x;
export const ease = (a, b, x) => { const q = clamp((x-a)/(b-a)); return q*q*(3-2*q); };
export const mod = (x, y = 1) => ((x % y) + y) % y;
export const v = (x=0,y=0,z=0) => new T.Vector3(x,y,z);
export const rng = seed => () => {
  seed = (Math.imul(seed,1664525)+1013904223) >>> 0;
  return seed/4294967296;
};
export const sphere = new T.SphereGeometry(1,20,14);
export const tiny = new T.IcosahedronGeometry(1,1);
export const material = (color, opts={}) => new T.MeshStandardMaterial({color,roughness:.48,metalness:.06,...opts});
export const lit = (color, strength=.35, opts={}) => material(color,{emissive:color,emissiveIntensity:strength,...opts});
export const flat = (color, opts={}) => new T.MeshBasicMaterial({color,...opts});
export function mesh(parent, geo, mat, position=[0,0,0], scale=[1,1,1]) {
  const item = new T.Mesh(geo,mat);
  item.position.set(...position);
  item.scale.set(...scale);
  parent.add(item);
  return item;
}
export const ball = (parent, mat, p, s) => mesh(parent,sphere,mat,p,s);
export const curve = (points, closed=false) => new T.CatmullRomCurve3(points.map(p=>Array.isArray(p)?v(...p):p),closed);
export function tube(parent, points, radius, mat, segments=40, sides=8) {
  return mesh(parent,new T.TubeGeometry(Array.isArray(points)?curve(points):points,segments,radius,sides,false),mat);
}
export function ring(parent, radius, thickness, mat, p=[0,0,0]) {
  const item = mesh(parent,new T.TorusGeometry(radius,thickness,8,56),mat,p);
  item.rotation.x=Math.PI/2;
  return item;
}
export function stage(fogColor, fogNear, fogFar, lights) {
  const scene = new T.Scene();
  if(fogFar) scene.fog = new T.Fog(fogColor,fogNear,fogFar);
  const camera = new T.PerspectiveCamera(40,1280/720,.025,200);
  scene.add(new T.HemisphereLight(lights[0],lights[1],lights[2]));
  for(const [xyz,color,power] of lights.slice(3)) {
    const light=new T.DirectionalLight(color,power);
    light.position.set(...xyz); scene.add(light);
  }
  return {scene,camera};
}
export function aim(camera, pos, target, fov=40, roll=0) {
  camera.position.set(...pos); camera.up.set(Math.sin(roll),Math.cos(roll),0);
  camera.fov=fov; camera.updateProjectionMatrix(); camera.lookAt(...target);
}
export function loft(samples, sides=32) {
  const pos=[], indices=[];
  for (const [x,y,z,rx,rz] of samples) {
    for(let j=0;j<sides;j++){
      const a=j/sides*TAU;
      pos.push(x+rx*Math.cos(a),y,z+rz*Math.sin(a));
    }
  }
  for(let i=0;i<samples.length-1;i++) for(let j=0;j<sides;j++){
    const a=i*sides+j,b=i*sides+(j+1)%sides,c=b+sides,d=a+sides;
    indices.push(a,d,b,b,d,c);
  }
  const geo=new T.BufferGeometry();
  geo.setAttribute('position',new T.Float32BufferAttribute(pos,3));
  geo.setIndex(indices); geo.computeVertexNormals();
  return geo;
}
export function organic(seed, amount=.16, width=24, height=16) {
  const geo=new T.SphereGeometry(1,width,height), p=geo.attributes.position;
  for(let i=0;i<p.count;i++){
    const x=p.getX(i),y=p.getY(i),z=p.getZ(i);
    const r=1+amount*(.55*Math.sin(5*x+3*z+seed)*Math.sin(5*y-2*z)+.3*Math.cos(7*z-4*y+seed)+.25*Math.sin(11*x+9*y+z));
    p.setXYZ(i,x*r,y*r,z*r);
  }
  geo.computeVertexNormals(); return geo;
}
export function instances(parent, geo, mat, count) {
  const item = new T.InstancedMesh(geo,mat,count);
  item.instanceMatrix.setUsage(T.DynamicDrawUsage);
  item.frustumCulled=false;
  parent.add(item);
  return item;
}
const dummy = new T.Object3D();
export function pose(batch,i,p,s,r=[0,0,0]) {
  dummy.position.set(...p); dummy.scale.set(...s); dummy.rotation.set(...r);
  dummy.updateMatrix(); batch.setMatrixAt(i,dummy.matrix);
}
export function glow(parent,count,{color=0x91eaff, size=9, opacity=.9, density=1, seed=17}={}) {
  const random=rng(seed), geo=new T.BufferGeometry();
  const attrs = {
    position: new Float32Array(count*3), pointSize: new Float32Array(count),
    intensity: new Float32Array(count)
  };
  for(let i=0;i<count;i++){attrs.pointSize[i]=.55+random()*1.18;attrs.intensity[i]=.5+random()*.5;}
  for(const [name,values] of Object.entries(attrs)) geo.setAttribute(name,new T.BufferAttribute(values,name==='position'?3:1));
  const mat=new T.ShaderMaterial({
    transparent:true,depthWrite:false,blending:T.AdditiveBlending,
    uniforms:{tint:{value:new T.Color(color)},size:{value:size},opacity:{value:opacity},density:{value:density}},
    vertexShader:`attribute float pointSize; attribute float intensity; varying float a; uniform float size;
    void main(){ vec4 p=modelViewMatrix*vec4(position,1.); gl_Position=projectionMatrix*p; gl_PointSize=clamp(size*pointSize*10./-p.z,1.5,125.); a=intensity; }`,
    fragmentShader:`varying float a; uniform vec3 tint; uniform float opacity; uniform float density;
    void main(){ float r=length(gl_PointCoord-.5)*2.; float soft=exp(-r*r*4.5)*smoothstep(1.,.6,r); float core=exp(-r*r*28.);
      gl_FragColor=vec4(mix(tint,vec3(1.),core*.76),a*opacity*(.33*soft+.71*core)*density); }`
  });
  const obj=new T.Points(geo,mat); obj.frustumCulled=false; parent.add(obj);
  return {obj,mat,move(fn){for(let i=0;i<count;i++){const p=fn(i);attrs.position.set(p,i*3);}geo.attributes.position.needsUpdate=true;}};
}
export function spokes(parent, count, inner, outer, mat) {
  const points=[];
  for(let i=0;i<count;i++){
    const a=i/count*TAU, b=(i%5===0?outer:lerp(inner,outer,.55));
    points.push(v(inner*Math.cos(a),0,inner*Math.sin(a)),v(b*Math.cos(a),0,b*Math.sin(a)));
  }
  const obj=new T.LineSegments(new T.BufferGeometry().setFromPoints(points),mat);parent.add(obj);return obj;
}
