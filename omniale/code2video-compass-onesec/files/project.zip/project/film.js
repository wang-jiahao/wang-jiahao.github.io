import * as T from 'three';
import {clamp,lerp,ease,v} from './geometry.js';
import {bodyStage,heartStage} from './anatomy.js';
import {capillaryStage,mitochondrionStage,turbineStage,channelStage} from './micro.js';
import {drawHUD} from './hud.js';

const response=await fetch('/timeline.json');
if(!response.ok)throw new Error(`Timeline: ${response.status}`);
const timing=await response.json(), cues=timing.audio_cues;
const {width,height,fps,duration_s:duration}=timing;
const canvas=document.querySelector('#world');
const renderer=new T.WebGLRenderer({canvas,alpha:false,antialias:false,powerPreference:'high-performance',preserveDrawingBuffer:true});
renderer.setSize(width,height,false);
renderer.setClearColor(0x000000,0);
renderer.autoClear=false;
renderer.toneMapping=T.NoToneMapping;
const scenes={body:bodyStage(),heart:heartStage(),capillary:capillaryStage(),mito:mitochondrionStage(),turbine:turbineStage(cues.mitochondrial_turbine),channel:channelStage(cues)};
const palette={void:0,body:1,heart:2,capillary:3,mito:4,turbine:5,channel:6};
const targets=[0,1].map(()=>new T.WebGLRenderTarget(width,height,{type:T.HalfFloatType,samples:0}));
const bloomBuffers=[0,1].map(()=>new T.WebGLRenderTarget(320,180,{type:T.HalfFloatType,depthBuffer:false}));
const screen=new T.Scene(), screenCamera=new T.Camera();
const uniforms={
  first:{value:targets[0].texture},second:{value:targets[1].texture},
  bloom:{value:bloomBuffers[1].texture},aMode:{value:0},bMode:{value:0},
  blend:{value:0},time:{value:0},flash:{value:0},warp:{value:0}
};
const screenVertex=`varying vec2 uvp; void main(){uvp=uv;gl_Position=vec4(position.xy,0.,1.);}`;
const blurUniforms={image:{value:targets[0].texture},stepUV:{value:new T.Vector2()},threshold:{value:0}};
const blurScreen=new T.Scene();
blurScreen.add(new T.Mesh(new T.PlaneGeometry(2,2),new T.ShaderMaterial({
  uniforms:blurUniforms,vertexShader:screenVertex,depthWrite:false,depthTest:false,
  fragmentShader:`varying vec2 uvp; uniform sampler2D image; uniform vec2 stepUV; uniform float threshold;
    vec3 sampleLight(float p){vec3 q=texture2D(image,uvp+p*stepUV).rgb;
      return min(vec3(2.4),max(vec3(0.),q-vec3(threshold)));}
    void main(){vec3 sum=sampleLight(0.)*.204164;
      sum+=(sampleLight(1.)+sampleLight(-1.))*.180174;
      sum+=(sampleLight(2.)+sampleLight(-2.))*.123832;
      sum+=(sampleLight(3.)+sampleLight(-3.))*.066282;
      sum+=(sampleLight(4.)+sampleLight(-4.))*.027630;
      gl_FragColor=vec4(sum,1.);}`
})));
const output=new T.ShaderMaterial({uniforms,depthWrite:false,depthTest:false,
  vertexShader:screenVertex,
  fragmentShader:`
    varying vec2 uvp; uniform sampler2D first; uniform sampler2D second; uniform sampler2D bloom;
    uniform float aMode,bMode,blend,time,flash,warp;
    float cloud(vec2 p, vec2 c, vec2 stretch){vec2 q=(p-c)*stretch; return exp(-dot(q,q));}
    vec3 background(float mode,vec2 p){
      vec2 uv=vec2(p.x,1.-p.y);
      if(mode>4.5 && mode<5.5){
        vec3 base=mix(vec3(.107,.089,.087),vec3(.24,.40,.56),smoothstep(.45,1.,uv.y));
        float central=cloud(uv,vec2(.50,.39),vec2(3.9,2.1));
        float a=cloud(uv,vec2(.217+.027*sin(time*.71)+uv.y*.15,.09),vec2(16.,3.25));
        float b=cloud(uv,vec2(.764+.033*cos(time*.56)-uv.y*.11,.10),vec2(14.,3.));
        float middle=cloud(uv,vec2(.509+.018*sin(time*.9),.16),vec2(17.,5.9));
        float strand=cloud(uv,vec2(.28-uv.y*.21,.25),vec2(15.,2.8))*.51;
        float mist=cloud(uv,vec2(.50,.72),vec2(2.05,4.20));
        return base+vec3(.12,.17,.22)*central+vec3(1.12,.90,.58)*(a*1.00+b*.99+middle*.45+strand)+vec3(.16,.31,.41)*mist;
      }
      vec3 base=vec3(.012,.025,.039);
      vec3 tint=vec3(.035,.14,.19);
      if(mode>1.5&&mode<4.5){base=vec3(.035,.014,.025);tint=vec3(.22,.054,.084);}
      if(mode>5.5){base=vec3(.012,.045,.056);tint=vec3(.11,.25,.27);}
      float soft=cloud(uv,vec2(.50,.46),vec2(2.7,2.2));
      float mist=cloud(uv,vec2(.39+uv.y*.35,.52),vec2(5.6,2.5));
      return base+tint*(soft*.53+mist*.34);
    }
    vec3 source(sampler2D tex,float mode,vec2 p){
      if(mode<.5)return background(mode,p);
      vec4 q=texture2D(tex,p);
      if(mode>4.5&&mode<5.5){
        vec3 base=background(mode,p);
        vec3 light=texture2D(bloom,p).rgb;
        float lum=dot(q.rgb,vec3(.23,.64,.13));
        float soft=smoothstep(.16,.75,lum);
        vec3 pearl=mix(q.rgb,vec3(lum),.25+.19*soft)*(1.02+.68*soft);
        vec2 uv=vec2(p.x,1.-p.y);
        float lower=cloud(uv,vec2(.50,.71),vec2(1.53,5.4));
        float warm=cloud(uv,vec2(.49,.28),vec2(2.25,5.2));
        float leftRay=cloud(uv,vec2(.215+uv.y*.16+.014*sin(time*.76),.21),vec2(16.5,3.85));
        float rightRay=cloud(uv,vec2(.788-uv.y*.12+.021*cos(time*.59),.17),vec2(15.5,3.60));
        float flare=cloud(uv,vec2(.504+.017*sin(time*.93),.148),vec2(10.5,6.6));
        return base*(1.-clamp(q.a,0.,1.)) + pearl + light*.74 + base*.18 + lower*vec3(.145,.32,.46)
          +warm*vec3(.16,.13,.12)+(leftRay*.66+rightRay*.53+flare*.50)*vec3(.94,.74,.48);
      }
      return background(mode,p)*(1.-clamp(q.a,0.,1.))+q.rgb;
    }
    void main(){
      vec2 p=uvp; vec2 focus=vec2(.48,.50);
      vec2 d=p-focus;float r=length(d);
      vec2 pp=p+d*warp*(.025+.13*r);
      vec3 raw=source(first,aMode,pp);
      if(blend>0.001)raw=mix(raw,source(second,bMode,p-d*warp*.065),blend);
      float radial=cloud(p,focus,vec2(3.4,4.9));
      raw+=vec3(.19,.51,.58)*flash*(.15+radial*.5);
      float streak=pow(.5+.5*sin(atan(d.y,d.x)*77.+time*7.),14.);
      raw+=vec3(.15,.35,.42)*warp*warp*streak*r*r*.54;
      float m=mix(aMode,bMode,blend);
      float vignette=1.-smoothstep(.21,.76,length((p-.5)*vec2(.96,.9)))*(m>4.7&&m<5.3?.54:.48);
      vec3 graded=pow(max(raw,0.)/(vec3(1.)+raw*.57),vec3(.67))*vignette;
      float n=fract(sin(dot(gl_FragCoord.xy+vec2(floor(time*30.),0.),vec2(12.9898,78.233)))*43758.5453);
      gl_FragColor=vec4(clamp(graded+(n-.5)*.011,0.,1.),1.);
    }`
});
screen.add(new T.Mesh(new T.PlaneGeometry(2,2),output));

const changes=[
  [4.4,1.0,'body'],[12.5,1.15,'heart'],[18.5,1.14,'capillary'],[24.82,1.25,'mito'],
  [28.4,1.44,'turbine'],[37.8,1.60,'channel'],[45.45,.82,'turbine'],[46.25,.81,'mito'],
  [47.15,.88,'capillary'],[48.25,.95,'heart'],[49.35,1.12,'body'],[55.2,.86,'void']
];
function sources(t){
  let last='void';
  for(const [center,span,next] of changes){
    if(t<center-span/2)return [last,'void',0,0];
    if(t<center+span/2){
      const q=ease(center-span/2,center+span/2,t);
      return [last,next,q,Math.sin(q*Math.PI)];
    }
    last=next;
  }
  return [last,'void',0,0];
}
function biologicalClock(t){
  const anchors=timing.biological_clock;
  for(let i=1;i<anchors.length;i++){
    const [x,a]=anchors[i-1],[y,b]=anchors[i];
    if(t<=y)return lerp(a,b,clamp((t-x)/(y-x)));
  }
  return 1;
}
const bump=(t,center,span)=>Math.exp(-Math.pow((t-center)/span,2));
function cardiac(t){
  const beats=cues.cardiac_lub_dub_s.map(([a,b])=>bump(t,a+.085,.15)+.49*bump(t,b+.046,.10));
  beats.push(bump(t,cues.final_heartbeat_s+.08,.19));
  return clamp(Math.max(...beats));
}
function prepare(name,t,pulse){
  const scene=scenes[name];
  if(!scene)return;
  const reverse=t>=45.35;
  switch(name){
    case 'body': scene.update(t,pulse,reverse?1-ease(48.9,50.32,t):ease(10.5,13.02,t),t>=50.6);break;
    case 'heart': scene.update(t,pulse,reverse?1-ease(47.77,49.55,t):ease(16.3,19.11,t),reverse?0:ease(14.0,15.65,t)*(1-ease(16.0,17.45,t)));break;
    case 'capillary': scene.update(t,reverse?1-ease(46.7,48.55,t):ease(19.4,25.24,t),reverse?0:ease(22.55,24.94,t));break;
    case 'mito': scene.update(t,reverse?1-ease(45.8,47.16,t):ease(26.15,28.94,t));break;
    case 'turbine': scene.update(t,reverse?ease(45.08,46.62,t):1.3*(1-ease(27.68,30.13,t))+.65*ease(37.04,38.56,t));break;
    case 'channel': scene.update(t,ease(44.55,45.8,t));break;
  }
  scene.camera.updateMatrixWorld();
}
function renderInto(name,i,t,pulse){
  renderer.setRenderTarget(targets[i]);renderer.clear();
  if(scenes[name]){prepare(name,t,pulse);renderer.render(scenes[name].scene,scenes[name].camera);}
}
function renderBloom(index){
  blurUniforms.image.value=targets[index].texture;
  blurUniforms.stepUV.value.set(8/width,0);
  blurUniforms.threshold.value=.39;
  renderer.setRenderTarget(bloomBuffers[0]);renderer.render(blurScreen,screenCamera);
  blurUniforms.image.value=bloomBuffers[0].texture;
  blurUniforms.stepUV.value.set(0,8/height);
  blurUniforms.threshold.value=0;
  renderer.setRenderTarget(bloomBuffers[1]);renderer.render(blurScreen,screenCamera);
}
function scaleFor(name,t){
  switch(name){
    case 'heart':return [1,t>16.5&&t<19?'5 厘米':'20 厘米'];
    case 'capillary':return [3,'20 微米'];
    case 'mito':return [4,'500 纳米'];
    case 'turbine':case 'channel':return [5,'5 纳米'];
    default:return [0,t>=50.6||t<6.2?'1 米':'50 厘米'];
  }
}
function project(name){
  const xyz={body:[.16,1.50,.28],heart:[-.57,-.32,1.1],capillary:[0,.02,-2.7],mito:[-1.25,.15,1],turbine:[.13,-1.60,.09],channel:[0,.55,.24]}[name];
  if(!xyz)return null;
  const coord=v(...xyz).project(scenes[name].camera);
  return {x:clamp((coord.x+1)*width/2,330,930),y:clamp((1-coord.y)*height/2,142,542)};
}
window.seekTo=(seconds)=>{
  const t=clamp(seconds,0,duration), pulse=cardiac(t), [a,b,blend,warp]=sources(t);
  renderInto(a,0,t,pulse);
  if(blend>.001)renderInto(b,1,t,pulse);
  if(a==='turbine'||b==='turbine'&&blend>.001)renderBloom(a==='turbine'?0:1);
  uniforms.aMode.value=palette[a];uniforms.bMode.value=palette[b];uniforms.blend.value=blend;
  uniforms.time.value=t;uniforms.flash.value=.90*bump(t,cues.t_ion_flash_s,.053)+.20*bump(t,4.43,.17)+.11*bump(t,cues.final_heartbeat_s,.17);
  uniforms.warp.value=warp*(t>=45.1&&t<50.6?1.6:.55);
  renderer.setRenderTarget(null);renderer.clear();renderer.render(screen,screenCamera);
  const stageId=blend>.54?b:a, [scale,ruler]=scaleFor(stageId,t);
  const act=timing.acts.find(row=>t>=row.start_s&&t<row.end_s)?.id??9;
  drawHUD(t,timing,{bio:biologicalClock(t),act,stageId,pulse,scale,ruler,projection:project(stageId)});
};
function resize(){document.querySelector('#frame').style.setProperty('--fit',Math.min(innerWidth/width,innerHeight/height));}
addEventListener('resize',resize);resize();
if(new URLSearchParams(location.search).has('capture')){
  window.seekTo(0);
}else{
  let start;
  function play(now){if(start===undefined)start=now;window.seekTo(((now-start)/1000)%duration);requestAnimationFrame(play);}
  requestAnimationFrame(play);
}
window.filmReady=true;
