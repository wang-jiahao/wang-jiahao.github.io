import * as T from 'three';
import {TAU,clamp,lerp,ease,mod,rng,v,sphere,tiny,material,lit,flat,mesh,ball,curve,tube,ring,stage,aim,organic,instances,pose,glow} from './geometry.js';

export function capillaryStage(){
  const g=stage(0x371b2c,5,26,[0xffc3aa,0x401c36,1.4,[[-3,4,2],0xffad8f,3.3],[[3,-1,-9],0xca829f,2.4]]);
  const random=rng(76);
  const path=curve([[0,0,8],[-.21,.1,2],[.16,.12,-3],[-.23,-.22,-8],[.51,-.07,-13],[1.25,.31,-19],[.28,.1,-27]]);
  const lumen=new T.TubeGeometry(path,85,2.7,42,false);
  const p=lumen.attributes.position, colors=[];
  const shades=[new T.Color(0x581f39),new T.Color(0xb95d68)];
  for(let i=0;i<p.count;i++){
    const x=p.getX(i),y=p.getY(i),z=p.getZ(i);
    const n=.4+.22*Math.sin(4*x+z*1.3)*Math.cos(2.8*y-z*1.1)+.15*Math.sin(3*z+1.8*y)+.14*Math.sin(2*x-y*3);
    const c=shades[0].clone().lerp(shades[1],clamp(n));colors.push(c.r,c.g,c.b);
  }
  lumen.setAttribute('color',new T.Float32BufferAttribute(colors,3));
  mesh(g.scene,lumen,material(0xffffff,{side:T.BackSide,vertexColors:true,roughness:.76}));
  const ridges=material(0x81384f,{roughness:.6,transparent:true,opacity:.55});
  for(let j=0;j<11;j++){
    const a=j/11*TAU;
    const strand=[];
    for(let k=0;k<26;k++){
      const c=path.getPointAt(k/25),b=a+.13*Math.sin(k*.6+j);
      strand.push([c.x+2.64*Math.cos(b),c.y+2.64*Math.sin(b),c.z]);
    }
    tube(g.scene,strand,.042,ridges,65,5);
  }
  for(const s of [-1,1])tube(g.scene,[[s*1.45,.07,-9],[s*2.6,.3,-11],[s*3.5,.51,-15],[s*4,.80,-20]],.89,material(0xa63e59,{side:T.BackSide}),44,19);
  const lathe=new T.LatheGeometry([[0,.105],[.23,.12],[.46,.15],[.65,.22],[.79,.28],[.91,.23],[1,.14],[1.025,0],[1,-.14],[.91,-.23],[.79,-.28],[.65,-.22],[.46,-.15],[.23,-.12],[0,-.105]].map(([x,y])=>new T.Vector2(x,y)),36);
  const cells=instances(g.scene,lathe,material(0xd73c47,{roughness:.31,metalness:.09,emissive:0x621a2c,emissiveIntensity:.23,side:T.DoubleSide}),31);
  const offsets=Array.from({length:31},()=>[(random()-.5)*2.9,(random()-.5)*2.65,random(),.45+.45*random(),random()]);
  for(let i=0;i<31;i++)cells.setColorAt(i,new T.Color().setHSL(.966+random()*.045,.47+random()*.32,.48+random()*.20));
  const oxy=glow(g.scene,170,{size:11,color:0x8cf5ff,opacity:1.2,seed:66});
  const motes=glow(g.scene,110,{size:4.5,color:0xf29b92,opacity:.4,seed:71});
  const seeds=Array.from({length:170},()=>[random(),random(),random(),random()]);
  return {...g,update(t,zoom=0,release=0){
    const f=t-18.5;
    for(let i=0;i<31;i++){
      const [x,y,off,s,a]=offsets[i];const q=mod(off+f*(.07+.04*a));const c=path.getPointAt(q);
      const w=i===0?1.05:s;
      pose(cells,i,[c.x+x,c.y+y,c.z],[w,w,w],[a*6+f*.55,a*2+f*.43,off*6+f*.62]);
    }
    cells.instanceMatrix.needsUpdate=true;
    oxy.mat.uniforms.opacity.value=.55+1.45*release;
    oxy.move(i=>{
      const [x,y,z,s]=seeds[i], q=mod(x+f*.77),c=path.getPointAt(.21+.31*z);
      return [c.x+lerp(-.4+1.2*y,3.3,q)*release+(y-.5)*(1-release),c.y+(s-.5)*2.2+Math.sin(q*TAU+z)*.24,c.z+(q-.5)*1.12];
    });
    motes.move(i=>{const [x,y,z]=seeds[i];return [(x-.5)*5,(y-.5)*5,7-mod(z+f*.08)*31];});
    aim(g.camera,[lerp(.13,1.62,zoom),lerp(.16,.29,zoom),lerp(6,-4,zoom)],[lerp(.16,2.60,release),.03,lerp(-9,-8,zoom)],58,.09*release);
  }};
}

export function mitochondrionStage(){
  const g=stage(0x351e26,10,28,[0xffcaba,0x3e254d,1.5,[[2,4,6],0xffd0a0,3.6],[[-5,0,-3],0x80dce3,2.0]]);
  const mito=new T.Group();g.scene.add(mito);mito.rotation.set(-.12,-.27,.21);
  const rim=lit(0xea7162,.34,{roughness:.48});
  const membrane=lit(0xf58974,.15,{transparent:true,opacity:.26,depthWrite:false,side:T.DoubleSide});
  mesh(mito,organic(4,.13,40,25),membrane,[0,0,0],[3.30,1.59,1.58]);
  const inner=material(0x9481a3,{roughness:.31,side:T.DoubleSide,emissive:0xa1433c,emissiveIntensity:.31});
  const crista=lit(0xf7a87e,.47);
  const perimeter=[];
  for(let i=0;i<=90;i++){
    const a=i/90*TAU;perimeter.push([3.15*Math.cos(a),1.49*Math.sin(a),.30+.12*Math.cos(3*a)]);
  }
  tube(mito,perimeter,.068,rim,94,8);
  for(let k=0;k<12;k++){
    const x=(k-5.5)*.45, r=Math.sqrt(1-(x/3.19)**2), points=[];
    for(let i=0;i<=36;i++){
      const b=i/36*TAU;
      points.push([x+.23*Math.cos(b+1.1*k)+.22*Math.sin(b*2),r*1.35*Math.sin(b),r*1.27*Math.cos(b)]);
    }
    tube(mito,points,.091,crista,36,7);
    const geo=new T.PlaneGeometry(1.85*r,2.35*r,12,12),p=geo.attributes.position;
    for(let i=0;i<p.count;i++){
      const z=p.getX(i),y=p.getY(i);
      const d=Math.sqrt((z/(.95*r))**2+(y/(1.24*r))**2);
      p.setXYZ(i,x+.15*Math.sin(z*4+y*3+k)+.18*Math.sin(y*2),y/(Math.max(1,d)),z/(Math.max(1,d)));
    }
    geo.computeVertexNormals();mesh(mito,geo,inner);
  }
  const random=rng(232);
  const fibers=instances(g.scene,new T.CylinderGeometry(1,1,1,10),material(0x8d404a,{roughness:.63}),92);
  for(let i=0;i<92;i++){
    const y=(random()-.5)*14,z=-3-random()*12,x=(random()-.5)*25;
    pose(fibers,i,[x,y,z],[.08+random()*.11,6+random()*15,.08+random()*.15],[.02,0,1.19+random()*.26]);
    fibers.setColorAt(i,new T.Color().setHSL(.97+random()*.06,.38,.42+random()*.21));
  }
  fibers.instanceMatrix.needsUpdate=true;
  const oxygen=glow(g.scene,150,{size:9,color:0x80faff,opacity:1.45});
  const charges=glow(mito,126,{size:10,color:0xffbe69,opacity:1.15});
  const seeds=Array.from({length:150},()=>[random(),random(),random(),random()]);
  return {...g,update(t,zoom=0){
    mito.rotation.set(-.15+Math.sin(t*.9)*.06,-.20+.17*zoom,.20+.10*Math.sin(t*.8));
    oxygen.move(i=>{const [x,y,z,a]=seeds[i],q=mod(x+t*.29);return [lerp(-7.5,1.6,q),(y-.5)*lerp(5,1,q),lerp(2.8,-.4,q)+(z-.5)*lerp(2.6,.9,q)+.23*Math.sin(a*12+q*8)];});
    charges.move(i=>{const [x,y,z]=seeds[i],a=TAU*mod(x+t*.48),r=1-(2*y-1)**2;return [(y-.5)*5.8,Math.sin(a)*r*1.32,Math.cos(a)*r*1.32+(z-.5)*.33];});
    aim(g.camera,[lerp(-.60,.57,zoom),lerp(.60,.55,zoom),lerp(11,2.0,zoom)],[lerp(.43,.16,zoom),.08,0],43,-.047);
  }};
}

export function turbineStage(cues){
  const g=stage(0xa5b1b5,9,35,[0xfff2da,0x8ccedc,1.9,[[1,4,3],0xffe5c2,3.1],[[-4,1,2],0xb4e8ef,1.6],[[1,2,-4],0xfff4d6,2.7]]);
  const colors={
    mint:lit(0x98dfd4,.46,{roughness:.38}), lavender:lit(0xcab3e8,.53,{roughness:.36}),
    gold:lit(0xf4d18a,.68,{roughness:.41}), cream:lit(0xffedb9,.74,{roughness:.39}),
    mauve:lit(0xbba7db,.38,{roughness:.41}), pale:lit(0xecddf8,.61,{roughness:.40})
  };
  const geoA=organic(47,.12,26,18),geoB=organic(53,.16,26,18),geoC=organic(22,.13,21,14);
  const statorGeo=new T.TubeGeometry(curve([[.71,1.22,-.05],[1.03,.83,.02],[1.10,.14,.10],[1.08,-.55,.08],[1.12,-1.22,.03],[1.02,-1.83,.02]]),23,.119,11,false);
  const stalkGeo=new T.TubeGeometry(curve([[.00,-1.9,0],[-.12,-1.28,.06],[.07,-.64,-.045],[-.045,-.10,.02],[0,.66,0]]),24,.21,13,false);
  const sites=[
    [0,0,0,1],[-5.47,.21,-.60,1.07],[5.8,.28,-1.5,1.05],[-3.52,.24,-4.9,.81],[3.46,.21,-4.6,.84],
    [-6.53,.35,-6.5,.98],[6.51,.44,-7.3,.82],[-1.72,.57,-8.2,.57],[1.82,.40,-9.2,.56],[-4.84,.69,-11.8,.68],
    [4.8,.29,-12,.66],[-7.9,.70,-12,.86],[8.4,.55,-13,.93],[-.22,.50,-13,.46],[-2.83,.61,-17,.63],[3.24,.74,-16,.65],
    [-6.85,.51,-19,.72],[6.70,.68,-19,.78],[0,.53,-22,.62],[-9.4,.36,-6,1.1],[9.35,.51,-6.8,1.14],
    [-1.74,.68,-12.0,.42],[1.81,.57,-13.9,.49],[-3.22,.59,-9.25,.52],[3.09,.65,-9.6,.54],[-5.60,.80,-15.2,.47],[5.75,.66,-15.8,.57]
  ];
  const staticBatches={};
  const dynamicBatches={};
  const parts=(bank,name,geo,mat,n)=>{
    if(!bank[name])bank[name]={batch:instances(g.scene,geo,mat,sites.length*n),index:0};
    return bank[name];
  };
  const staticLocal=[
    ['arm',statorGeo,colors.mauve,[0,0,0],[1,1,1],false],
    ['joint',geoA,colors.pale,[1.02,-1.84,.02],[.24,.31,.22],false],
    ['joint',geoA,colors.pale,[.79,1.31,-.05],[.23,.23,.20],false]
  ];
  const spinLocal=[['stalk',stalkGeo,colors.cream,[0,0,0],[1,1,1],false]];
  for(let j=0;j<6;j++){
    const a=(j/6+.07)*TAU, cx=Math.cos(a),cz=Math.sin(a),alt=j%2;
    const mat=alt?colors.lavender:colors.mint, name=alt?'alpha':'beta';
    spinLocal.push([name,alt?geoA:geoB,mat,[cx*.58,.73+(alt?.07:-.04),cz*.58],[.53,.59,.54],true]);
    spinLocal.push([name,alt?geoA:geoB,mat,[cx*.70,.44,cz*.70],[.34,.40,.34],true]);
    spinLocal.push([name,alt?geoA:geoB,mat,[cx*.40,1.21,cz*.40],[.29,.34,.28],true]);
  }
  for(let j=0;j<10;j++){
    const a=j/10*TAU;
    spinLocal.push(['rotor',geoC,colors.gold,[.49*Math.cos(a),-1.99+.05*Math.sin(j*1.7),.49*Math.sin(a)],[.256,.27,.253],false]);
  }
  spinLocal.push(['hub',geoA,colors.cream,[0,-1.94,0],[.47,.28,.47],false]);
  spinLocal.push(['axleTop',geoC,colors.pale,[0,1.27,0],[.32,.36,.33],false]);
  const counts=rows=>Object.fromEntries(rows.map(([name])=>[name,rows.filter(r=>r[0]===name).length]));
  const fixedCounts=counts(staticLocal),spinCounts=counts(spinLocal);
  const install=(rows,bank,count,turn,t)=>{
    for(const item of Object.values(bank))item.index=0;
    for(let i=0;i<sites.length;i++){
      const [px,py,pz,s]=sites[i], w=turn+i*1.19;
      for(const [name,geo,mat,[x,y,z],[sx,sy,sz],crown] of rows){
        const batch=parts(bank,name,geo,mat,count[name]);
        const angle=bank===staticBatches?(i===0?-.02:i*.72):(crown?w*.245+.16*Math.sin(w):w);
        const a=Math.cos(angle),b=Math.sin(angle), flex=crown?1+.043*Math.sin(w*3+x*5+z*8):1;
        pose(batch.batch,batch.index++,[px+s*(a*x+b*z),py+s*y,pz+s*(a*z-b*x)],[s*sx*flex,s*sy,s*sz*flex],[0,angle,0]);
      }
    }
    for(const item of Object.values(bank))item.batch.instanceMatrix.needsUpdate=true;
  };
  install(staticLocal,staticBatches,fixedCounts,0,0);
  const floor=new T.ShaderMaterial({
    uniforms:{time:{value:0}},side:T.DoubleSide,transparent:true,depthWrite:false,
    vertexShader:`varying vec3 p; varying float d; void main(){p=position;vec4 q=modelViewMatrix*vec4(p,1.);d=-q.z;gl_Position=projectionMatrix*q;}`,
    fragmentShader:`uniform float time;varying vec3 p;varying float d;
    void main(){float a=sin(p.x*3.+1.4*sin(p.y*.89+time*.5))*sin(p.y*3.6+.55*sin(p.x*2.));
      float b=sin(p.x*11.+p.y*4.)*sin(p.y*8.-p.x*2.);float haze=exp(-d*.048);
      vec3 c=mix(vec3(.082,.161,.225),vec3(.30,.51,.66),haze)+(.029*a+.011*b)*haze;
      gl_FragColor=vec4(c,smoothstep(48.,14.,d)*.91);}`
  });
  const ground=mesh(g.scene,new T.PlaneGeometry(106,92),floor,[0,-2.32,-26]);ground.rotation.x=-Math.PI/2;
  const random=rng(181);
  const seeds=Array.from({length:480},()=>[random(),random(),random(),random()]);
  const protons=glow(g.scene,185,{size:37,opacity:1.25,color:0xffdf9e,seed:6});
  const ions=glow(g.scene,480,{size:14,opacity:1.3,color:0xb7e9ff,seed:9});
  const charge=glow(g.scene,63,{size:45,opacity:1.2,color:0xffe2a9,seed:101});
  const protonBeads=instances(g.scene,tiny,lit(0xffedbd,1.18),90);
  return {...g,update(t,warp=0){
    const f=t-30.2, turn=TAU*(f*cues.rotations_per_s+.023*Math.sin(f*1.38));
    install(spinLocal,dynamicBatches,spinCounts,turn,t);floor.uniforms.time.value=f;
    const sway=.42*Math.sin(f*.89)-.28*Math.sin(f*.40);
    const d=8.9+.28*Math.cos(f*1.15)+1.9*warp;
    aim(g.camera,[sway,.43+.19*Math.sin(f*.77),d],[sway*.69-.10,-.23+.11*Math.sin(f*.79),0],39+.9*Math.sin(f*.7),-.012*Math.sin(f*.85));
    const proton=(i)=>{
      const [r,a,b,c]=seeds[i],lane=i<41?0:1+(i%Math.min(sites.length-1,12));
      const [x,y,z,s]=sites[lane], q=mod(r+f*(.58+.31*c)),phi=a*TAU+q*4.4+f*.7;
      const wide=lerp(.20+.38*b,1.02+.5*b,ease(.48,1,q));
      const h=3.30-5.51*q, wind=.37*Math.sin(q*5+c*3)+lerp(-.50,.31,q);
      return [x+s*(wind+Math.cos(phi)*wide),y+s*h,z+s*Math.sin(phi)*wide];
    };
    protons.move(proton);
    for(let i=0;i<90;i++){
      const s=.025+seeds[i][2]*.056;
      pose(protonBeads,i,proton(i),[s,s,s]);
    }
    protonBeads.instanceMatrix.needsUpdate=true;
    ions.move(i=>{const [a,b,c,d]=seeds[i];return [lerp(-13,13,mod(a+f*.031+d*.014)),-2.25+b*2.01+.26*Math.cos(f*1.12+c*TAU),lerp(-26,4,c)+.61*Math.sin(f*.8+d*TAU)];});
    charge.move(i=>{
      const lane=i%7,[x,y,z,s]=sites[lane],j=Math.floor(i/7),q=mod(f*cues.rotations_per_s*3-j*.19+lane*.13);
      const a=turn/3+j*2.19;return [x+s*Math.cos(a)*(.85+.86*q),y+s*(1.41+.93*q),z+s*Math.sin(a)*(.74+.63*q)];
    });
  }};
}

export function channelStage(cues){
  const g=stage(0x102a38,10,40,[0xadefe2,0x26315f,1.36,[[2,6,4],0x9fe8dc,3.1],[[-4,3,-4],0xb88fe6,2.3]]);
  const random=rng(623), grid=[];
  const gatePlaces=[[0,0],[-4.25,-1.85],[4.0,-2.4],[-7,-4.7],[6.45,-7]];
  for(let iz=0;iz<24;iz++)for(let ix=0;ix<37;ix++){
    const x=(ix-18)*.51+(iz%2)*.25+(random()-.5)*.13,z=3-iz*.59+(random()-.5)*.13;
    if(gatePlaces.some(([gx,gz],j)=>Math.hypot(x-gx,z-gz)<(j===0?1.04:.86)))continue;
    if(z>.15&&Math.abs(x)<1.03+z*.20)continue;
    grid.push([x,z,random(),random()]);
  }
  const heads=instances(g.scene,tiny,material(0x65b0aa,{roughness:.35,metalness:.13}),grid.length*2);
  const tailShape=new T.TubeGeometry(curve([[-.06,0,0],[-.12,-.18,-.03],[-.10,-.29,.08],[-.14,-.44,.04],[-.08,-.61,-.02]]),7,.024,4,false);
  const tails=instances(g.scene,tailShape,lit(0xab8f79,.12,{roughness:.53}),grid.length*4);
  for(let i=0;i<grid.length;i++){
    const [x,z,p,w]=grid[i], wave=.11*Math.sin(x*.63+z*.37), r=.147+.047*p;
    for(let j=0;j<2;j++){
      const y=(j?-1:1)*(.69+.09*w)+wave;
      pose(heads,i*2+j,[x,y,z],[r,r,r]);
      heads.setColorAt(i*2+j,new T.Color().setHSL(.40+.12*p,.29+.26*w,.53+.17*w));
      for(let k=0;k<2;k++)pose(tails,i*4+j*2+k,[x+(k-.5)*.1,y,z],[1.11,1.15,1],[0,w*TAU+(k?Math.PI:0),j?Math.PI:0]);
    }
  }
  heads.instanceMatrix.needsUpdate=true;tails.instanceMatrix.needsUpdate=true;
  const shell=lit(0x44998e,.20,{roughness:.37,metalness:.18});
  const inner=lit(0x7961af,.26,{roughness:.32});
  const pale=lit(0x66c5bb,.23,{roughness:.35});
  const closed=lit(0xeb9360,.43,{roughness:.37});
  const lobe=organic(38,.20,22,15);
  const gates=gatePlaces.map(([x,z],j)=>{
    const root=new T.Group();root.position.set(x,0,z);root.scale.set(j===0?1.14:.75,j===0?1.32:.75,j===0?1.14:.75);root.rotation.y=.23+j*.48;g.scene.add(root);
    const flaps=[];
    for(let i=0;i<4;i++){
      const a=i/4*TAU;
      const flap=new T.Group();root.add(flap);flaps.push(flap);flap.rotation.y=-a;
      mesh(flap,lobe,shell,[.60,.07,0],[.45,1.19,.51]).rotation.z=-.13;
      mesh(flap,lobe,pale,[.70,.85,.01],[.45,.33,.47]).rotation.z=.22;
      mesh(flap,lobe,inner,[.45,-.40,.0],[.34,.63,.39]);
      mesh(flap,lobe,closed,[.17,.86,.01],[.34,.18,.22]);
      tube(flap,[[.57,-.78,-.33],[.86,-.47,-.27],[.95,.12,-.20],[.83,.63,-.29],[.65,.88,-.33]],.064,pale,17,6);
    }
    ring(root,.65,.04,inner,[0,-.75,0]);
    return {root,flaps};
  });
  const flashMat=flat(0xa9faff,{transparent:true,opacity:0,depthWrite:false,blending:T.AdditiveBlending});
  const halo=ring(gates[0].root,1.1,.035,flashMat,[0,.8,0]);
  const flashRay=mesh(gates[0].root,new T.CylinderGeometry(.20,.38,3.5,16,1,true),flashMat,[0,-.45,0]);
  flashRay.material=flashMat.clone();
  const reservoir=Array.from({length:510},()=>[random(),random(),random(),random()]);
  const wait=glow(g.scene,260,{color:0xffc169,size:13,opacity:1.35,seed:8});
  const current=glow(g.scene,510,{color:0x7cf1ff,size:15,opacity:1.9,seed:712});
  const beads=instances(g.scene,tiny,lit(0xf0b268,.73),115);
  return {...g,update(t,zoom=0){
    const f=t-cues.t_ion_flash_s;
    const opened=ease(cues.gate_open.start_s,cues.t_ion_flash_s,t)*(1-ease(cues.t_ion_flash_s+.025,cues.gate_open.end_s,t));
    const flashed=Math.exp(-Math.pow(f/.043,2));
    for(const {flaps} of gates)for(let i=0;i<4;i++){
      const a=i/4*TAU;
      flaps[i].position.set(.48*opened*Math.cos(a),0,.48*opened*Math.sin(a));
      flaps[i].rotation.z=-.30*opened;
    }
    halo.scale.setScalar(1+1.8*clamp(f*4));flashMat.opacity=.83*flashed;
    flashRay.material.opacity=.41*flashed;
    const waitPosition=i=>{
      const [a,b,c,d]=reservoir[i],phi=TAU*a+.42*t,s=.57+Math.pow(b,1.42)*3.9;
      return [Math.cos(phi)*s+.18*Math.sin(t*2+c*12),1.05+1.96*c+.12*Math.cos(t*3+a*6),Math.sin(phi)*s-.65];
    };
    wait.mat.uniforms.opacity.value=1.3-.82*ease(0,.22,f)+.52*ease(1.0,1.8,f);
    wait.move(waitPosition);
    for(let i=0;i<115;i++){
      const s=(.04+reservoir[i][2]*.075)*(1-.57*ease(0,.19,f));
      pose(beads,i,waitPosition(i),[s,s,s]);
    }
    beads.instanceMatrix.needsUpdate=true;
    current.mat.uniforms.opacity.value=(1.6+flashed*1.3)*(1-ease(.69,1.6,f));
    current.move(i=>{
      const [a,b,c,d]=reservoir[i];const q=f*(1.49+.68*d)-b*.59+.40*flashed*(1-b);
      if(f<-.01||q<-.23||q>1.9)return [0,-60,0];
      const spread=lerp(.14+.19*b,1.6+c,ease(.14,1.4,q));
      const phi=a*TAU+q*2.1, h=1.15-4.2*q;
      return [Math.sin(phi)*spread,h,Math.cos(phi)*spread];
    });
    const close=.36*ease(38.7,42.35,t)+.08*flashed;
    aim(g.camera,[.20+.43*Math.cos(t*.94),2.88-close*.77,lerp(10.2-close*2.0,14.0,zoom)],
      [.42,.10,0],43,-.02);
  }};
}
