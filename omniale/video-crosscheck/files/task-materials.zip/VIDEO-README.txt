原视频单独下载后保存到media/source.mp4。完整文件摘要见material-manifest.json。
