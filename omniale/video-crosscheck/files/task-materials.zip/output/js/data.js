window.DATA = {
  "meta": {
    "theme": "t05",
    "category": "消费电子",
    "lang": "zh"
  },
  "summary": "",
  "video": {
    "src": "media/source.mp4",
    "title": "【大家测】中兴 Axon 40 Ultra开箱体验",
    "duration": 986.069
  },
  "segments": [],
  "anchors": [],
  "research": [],
  "insights": []
};
