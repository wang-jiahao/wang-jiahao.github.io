"""Local-only media helpers: FFmpeg frames/audio and faster-whisper."""
import argparse
import json
from pathlib import Path
import subprocess
import wave

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
MODELS = {
    "small": "C:/Users/wjjhh/.cache/huggingface/hub/models--Systran--faster-whisper-small/snapshots/536b0662742c02347bc0e980a01041f333bce120",
    "large-v3-turbo": "C:/Users/wjjhh/.cache/huggingface/hub/models--mobiuslabsgmbh--faster-whisper-large-v3-turbo/snapshots/0a363e9161cbc7ed1431c9597a8ceaf0c4f78fcf",
}


def media_path(value):
    path = (ROOT / value).resolve()
    if not path.is_relative_to(ROOT.resolve()) or not path.is_file():
        raise ValueError("Media must be a file inside this run")
    return path


def duration(path):
    raw = subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "csv=p=0", str(path),
    ], text=True)
    return float(raw.strip())


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="action", required=True)
    frames = sub.add_parser("frame")
    frames.add_argument("--seconds", nargs="+", type=float, required=True)
    frames.add_argument("--out", type=Path, required=True)
    frames.add_argument("--media", default="media/source.mp4")
    audio = sub.add_parser("audio")
    audio.add_argument("--start", type=float, default=0)
    audio.add_argument("--end", type=float)
    audio.add_argument("--out", type=Path, required=True)
    audio.add_argument("--media", default="media/source.mp4")
    transcript = sub.add_parser("transcribe")
    transcript.add_argument("--start", type=float, default=0)
    transcript.add_argument("--end", type=float)
    transcript.add_argument("--model", choices=sorted(MODELS), default="small")
    transcript.add_argument("--language", default="zh")
    transcript.add_argument("--out", type=Path, required=True)
    transcript.add_argument("--media", default="media/source.mp4")
    args = parser.parse_args()
    source = media_path(args.media)
    total = duration(source)
    if args.action == "frame":
        args.out.mkdir(parents=True, exist_ok=True)
        for timestamp in args.seconds:
            if not 0 <= timestamp < total:
                raise ValueError("Time outside video")
            target = args.out / f"frame-{timestamp:09.3f}.png"
            subprocess.run([
                "ffmpeg", "-y", "-v", "error", "-ss", str(timestamp),
                "-i", str(source), "-frames:v", "1", str(target),
            ], check=True)
            print(str(target))
        return
    end = total if args.end is None else args.end
    if not 0 <= args.start < end <= total + 0.01:
        raise ValueError("Use a valid time range inside the media")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    if args.action == "audio":
        subprocess.run([
            "ffmpeg", "-y", "-v", "error", "-ss", str(args.start),
            "-to", str(end), "-i", str(source), "-vn", "-ac", "1",
            "-ar", "16000", "-c:a", "pcm_s16le", str(args.out),
        ], check=True)
        print(str(args.out))
        return
    from faster_whisper import WhisperModel
    clip = args.out.parent / (args.out.stem + "-clip.wav")
    try:
        subprocess.run([
            "ffmpeg", "-y", "-v", "error", "-ss", str(args.start),
            "-to", str(end), "-i", str(source), "-vn", "-ac", "1",
            "-ar", "16000", "-c:a", "pcm_s16le", str(clip),
        ], check=True)
        model = WhisperModel(
            MODELS[args.model], device="cpu", compute_type="int8",
            cpu_threads=4, local_files_only=True,
        )
        with wave.open(str(clip), "rb") as stream:
            assert stream.getnchannels() == 1 and stream.getsampwidth() == 2
            audio = np.frombuffer(
                stream.readframes(stream.getnframes()), dtype=np.int16,
            ).astype(np.float32) / 32768.0
        segments, info = model.transcribe(
            audio, language=args.language, beam_size=5, vad_filter=True,
        )
        rows = [{
            "start": round(args.start + segment.start, 3),
            "end": round(args.start + segment.end, 3),
            "text": segment.text.strip(),
        } for segment in segments]
        result = {
            "media": args.media,
            "requested_range": [args.start, end],
            "model": args.model,
            "engine": "faster-whisper/local CPU; no cloud media service",
            "language": info.language,
            "language_probability": info.language_probability,
            "segments": rows,
        }
        args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        args.out.with_suffix(".txt").write_text(
            "\n".join(f"[{r['start']:.3f} --> {r['end']:.3f}] {r['text']}" for r in rows) + "\n",
            encoding="utf-8",
        )
        print(json.dumps(result, ensure_ascii=False))
    finally:
        clip.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
