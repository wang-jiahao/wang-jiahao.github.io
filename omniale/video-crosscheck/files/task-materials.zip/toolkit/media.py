"""CLI media tools. The private service only receives media inside this run."""
import argparse
import json
from pathlib import Path
import subprocess
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest='action', required=True)
    frames = sub.add_parser('frame')
    frames.add_argument('--seconds', nargs='+', type=float, required=True)
    frames.add_argument('--out', type=Path, required=True)
    inspect = sub.add_parser('inspect')
    inspect.add_argument('--start', type=float, required=True)
    inspect.add_argument('--end', type=float, required=True)
    inspect.add_argument('--mode', choices=['audio', 'video'], default='video')
    inspect.add_argument('--prompt', default='忠实记录可听和可见的内容及片段内相对时间，区分观察与推断，不查外部资料。')
    inspect.add_argument('--out', type=Path, required=True)
    inspect.add_argument('--media', default='media/source.mp4', help='Local source or retrieved media within this run')
    args = p.parse_args()
    if args.action == 'frame':
        args.out.mkdir(parents=True, exist_ok=True)
        for t in args.seconds:
            if not 0 <= t < 986.069:
                raise ValueError('Time outside video')
            target = args.out/f'frame-{t:09.3f}.png'
            subprocess.run(['ffmpeg','-y','-v','error','-ss',str(t),'-i',str(ROOT/'media/source.mp4'),'-frames:v','1',str(target)],check=True)
            print(str(target))
    else:
        cfg = json.loads((ROOT/'toolkit/service.json').read_text(encoding='utf-8'))
        payload = {k:getattr(args,k) for k in ['start','end','mode','prompt','media']}
        req = urllib.request.Request(cfg['url']+'/inspect',data=json.dumps(payload).encode(),
            headers={'Content-Type':'application/json','X-Run-Token':cfg['token']})
        with urllib.request.urlopen(req,timeout=360) as r:result=json.load(r)
        args.out.parent.mkdir(parents=True,exist_ok=True)
        args.out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(result,ensure_ascii=False))


if __name__ == '__main__':
    main()
