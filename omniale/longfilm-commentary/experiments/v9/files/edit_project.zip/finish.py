from pathlib import Path
import json,math,sys,subprocess
import numpy as np
import soundfile as sf
import pyloudnorm as pyln
from scipy.signal import resample_poly
from make_voice import base,work,voices,read_edit

FPS=24
SR=48000
UNIT=SR//FPS
srcfps=29.97
out=base/'submission';out.mkdir(exist_ok=True)
meter=pyln.Meter(SR)
def stamp(sec,kind='clock'):
    ms=round(sec*1000);h,ms=divmod(ms,3600000);mn,ms=divmod(ms,60000);ss,ms=divmod(ms,1000)
    if kind=='srt':return f'{h:02d}:{mn:02d}:{ss:02d},{ms:03d}'
    if kind=='ass':return f'{h:d}:{mn:02d}:{ss:02d}.{ms//10:02d}'
    return f'{mn:02d}:{ss:02d}'

def level(audio,target,lo=-30,hi=12):
    loud=meter.integrated_loudness(audio) if len(audio)>SR*0.4 else -35
    return audio*10**(np.clip(target-loud,lo,hi)/20)

def fade(audio,attack,release):
    length=len(audio);attack=min(round(attack*SR),length//2);release=min(round(release*SR),length//2)
    if attack:audio[:attack]*=np.sin(np.linspace(0,np.pi/2,attack))**2
    if release:audio[-release:]*=np.cos(np.linspace(0,np.pi/2,release))**2

sync_notes={1024:'撞车的声响与片头',4431:'山姆说明为何回城',5568:'玛莎第一次确认山姆不在场',5580:'山姆划清亲见与听说的界线',6699:'山姆在枪口下的回答',6839:'两只手和第一声枪响',6867:'窗外的第二声枪响',6922:'离城时的劝告与玩笑',6943:'原片尾乐'}

def compile_edit():
    blocks=read_edit();clips=[];cues=[];events=[];cursor=0;script=['# 回头的人','《The Strange Love of Martha Ivers》（1946）中文剧情解说。标时为成片时间。'];last_chapter=''
    with sf.SoundFile(work/'film.wav') as film,sf.SoundFile(work/'master.wav','w',SR,1,subtype='PCM_24') as snd:
        for number,block in enumerate(blocks):
            chapter=block['chapter'];kind=block['kind'];start=cursor;rows=block['lines']; local_cues=[]; shots=[];source_points=[]
            if chapter!=last_chapter:
                script.extend(['',f'## {chapter}　{stamp(start/FPS)}']);last_chapter=chapter
            if kind=='sync':
                duration=round((block['end']-block['start'])*FPS);source_points=[(0,block['start'])];mix=np.zeros(duration*UNIT,dtype='float32');note=sync_notes.get(int(block['start']),'同期原声')
                for idx,(boundary,text) in enumerate(rows):
                    begin=round(float(boundary)*FPS);end=round(float(rows[idx+1][0])*FPS) if idx+1<len(rows) else duration-2
                    if int(block['start'])==6922:end=min(end,begin+[88,61,39,54,60][idx])
                    local_cues.append((begin,end,text))
                script.extend(['',f'**{stamp(start/FPS)}　原声｜{note}**'+('　“'+' / '.join(line[1] for line in rows)+'”' if rows else '（无旁白）')]);tag=None
            else:
                tag=block['tag'];raw,rate=sf.read(voices/(tag+'.wav'),dtype='float32');assert rate==24000 and raw.ndim==1
                coords=json.loads((voices/(tag+'.json')).read_text(encoding='utf8'));bounds=coords['bounds']
                active=np.flatnonzero(abs(raw)>0.004);trim0=max(0,active[0]-round(0.10*rate));trim1=min(len(raw),active[-1]+round(0.15*rate))
                voice=resample_poly(raw[trim0:trim1],2,1);voice=level(voice,-17.4,-8,10);fade(voice,0.009,0.02)
                lead=round((0.30 if number==0 or blocks[number-1]['kind']=='sync' else 0.14)*SR);trail=round((0.30 if number+1<len(blocks) and blocks[number+1]['kind']=='sync' else .20)*SR)
                duration=math.ceil((lead+len(voice)+trail)/UNIT);mix=np.zeros(duration*UNIT,dtype='float32');mix[lead:lead+len(voice)]=voice
                ticks=[max(0,round((lead/SR+bound-trim0/rate-.025)*FPS)) for bound in bounds];ticks[0]=max(0,round((lead/SR-0.045)*FPS))
                for idx,(position,text) in enumerate(rows):
                    tick=ticks[idx];end=ticks[idx+1] if idx+1<len(rows) else min(duration,math.ceil((len(voice)+lead)/UNIT)+1)
                    if tick>=end:raise RuntimeError((block,ticks))
                    local_cues.append((tick,end,text))
                    if position!='+':source_points.append((tick if idx else 0,float(position)))
                script.extend(['',f'**{stamp(start/FPS)}**　'+block['text']])
            for idx,(local,source) in enumerate(source_points):
                end=source_points[idx+1][0] if idx+1<len(source_points) else duration
                span=end-local;assert span>0
                source=round(source*srcfps)/srcfps;film.seek(round(source*SR));bed=film.read(span*UNIT,dtype='float32');assert len(bed)==span*UNIT
                if kind=='sync':
                    target=-17.9 if rows else -20.7;bed=level(bed,target,-10,12);fade(bed,.10,.20 if rows else .30)
                else:
                    bed=level(bed,-38.0,-32,1);fade(bed,.12,.14)
                mix[local*UNIT:end*UNIT]+=bed
                clips.append(dict(output_start_s=round((start+local)/FPS,6),output_end_s=round((start+end)/FPS,6),source_start_s=round(source,6),source_end_s=round(source+span/FPS,6),chapter=chapter,audio='原声' if kind=='sync' else '中文旁白＋低混原声',block=number+1))
            peak=np.abs(mix);mask=peak>.80;mix[mask]=np.sign(mix[mask])*(.80+.065*np.tanh((peak[mask]-.80)/.065));snd.write(mix*.96)
            for begin,end,text in local_cues:cues.append(dict(start=(start+begin)/FPS,end=(start+end)/FPS,text=text,sync=kind=='sync'))
            cursor+=duration;events.append(dict(start=start/FPS,end=cursor/FPS,chapter=chapter,kind=kind,tag=tag,original=block.get('start')))
    (work/'timeline.json').write_text(json.dumps(dict(clips=clips,cues=cues,events=events),ensure_ascii=False,indent=1),encoding='utf8');(out/'source_map.json').write_text(json.dumps(clips,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    (out/'script.md').write_text('\n'.join(script)+'\n',encoding='utf8');(out/'subtitles.srt').write_text('\n\n'.join(f"{idx}\n{stamp(c['start'],'srt')} --> {stamp(c['end'],'srt')}\n{c['text']}" for idx,c in enumerate(cues,1))+'\n',encoding='utf-8-sig')
    print('timeline',cursor/FPS,'seconds,',len(clips),'shots,',len(cues),'captions',flush=True)
    style(events,cues)

def style(events,cues):
    header='''[Script Info]
ScriptType: v4.00+
PlayResX: 960
PlayResY: 816
WrapStyle: 2
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.601

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Main,Microsoft YaHei,39,&H00F5F2EC,&H00FFFFFF,&H00171A18,&H00000000,0,0,0,0,100,100,0,0,1,0,0,5,0,0,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
''';lineout=[]
    def line(start,end,body,layer=1):lineout.append(f'Dialogue: {layer},{stamp(start,"ass")},{stamp(end,"ass")},Main,,0,0,0,,{body}')
    def txt(start,end,x,y,text,opts='',anchor=4):line(start,end,'{\\an'+str(anchor)+f'\\pos({x},{y})'+opts+'}'+text)
    def rect(start,end,x,y,width,height,color,alpha='00',extra=''):
        line(start,end,'{\\an7'+f'\\pos({x},{y})\\p1\\c&H{color}&\\alpha&H{alpha}&'+extra+'}'+f'm 0 0 l {width} 0 {width} {height} 0 {height}',0)
    total=events[-1]['end'];rect(0,total,0,720,960,1,'46463F');rect(0,total,33,740,25,2,'83ACBD')
    for event in events:
        start,end=event['start'],event['end'];is_sync=event['kind']=='sync';chapter=event['chapter'];idx,label=chapter.split(' ',1)
        txt(start,end,68,741,idx+'    /    '+label,r'\fs19\c&H9EB1B8&');txt(start,end,928,741,'原  声' if is_sync else 'I V E R S T O W N     /     1 9 4 6',r'\fs17\c&H9EB1B8&',6)
        if is_sync and int(event['original'])==1024:
            begin=start+2.25;finish=end-.25;fx=r'\fad(320,220)';rect(begin,finish,32,462,476,201,'171B19','20',fx);rect(begin,finish,32,462,4,201,'84B6CD','00',fx)
            txt(begin,finish,60,495,'归 乡 疑 云　 /　 黑 白 电 影 手 记',r'\fs21\c&HA1CAD7&'+fx);txt(begin,finish,58,559,'回头的人',r'\fnSimSun\b1\fs77\c&HF1F4F5&'+fx);txt(begin,finish,62,631,'THE STRANGE LOVE OF MARTHA IVERS    ·    1946',r'\fnSegoe UI\b1\fs18\c&HCBCAC3&'+fx)
        if is_sync and int(event['original'])==6943:txt(start,end,480,779,'原片导演  Lewis Milestone　 /　 中文剧情解说改编',r'\fs30\c&HD3DAD9&',5)
    for cue in cues:
        font=38 if len(cue['text'])<=25 else 36
        txt(cue['start'],cue['end'],480,780,cue['text'],f'\\fs{font}'+(r'\c&HBEE0ED&' if cue['sync'] else ''),5)
    labels=[(1318.6,'托尼','TONI MARACHEK'),(2883.1,'沃尔特','WALTER O’NEIL'),(3038,'玛莎','MARTHA IVERS'),(1006.4,'山姆','SAM MASTERSON'),(606.8,'十八年前','IVERSTOWN   /   1928'),(439.4,'案发当晚','IVERSTOWN   /   1928')]
    clips=json.loads((out/'source_map.json').read_text(encoding='utf8'))
    for source,name,small in labels:
        item=next((c for c in clips if abs(c['source_start_s']-source)<.025),None)
        if item is None:continue
        start=item['output_start_s']+.18;end=start+3.00;fx=r'\fad(170,180)';rect(start,end,27,33,195,77,'111612','24',fx);rect(start,end,27,33,3,77,'84B6CD','00',fx)
        txt(start,end,43,60,name,r'\fnSimSun\b1\fs33'+fx);txt(start,end,45,92,small,r'\fnSegoe UI\fs15\c&HA1CAD7&'+fx)
    (work/'final.ass').write_text(header+'\n'.join(lineout)+'\n',encoding='utf-8-sig')

def render():
    import cv2
    timeline=json.loads((work/'timeline.json').read_text(encoding='utf8'));clips=timeline['clips'];source=base/'input/source.mp4';cap=cv2.VideoCapture(str(source));assert cap.isOpened()
    cmd=['ffmpeg','-hide_banner','-loglevel','warning','-y','-f','rawvideo','-pixel_format','bgr24','-video_size','320x240','-framerate',str(FPS),'-i','pipe:0','-i','work/master.wav','-vf','scale=960:720:flags=lanczos,setsar=1,pad=960:816:0:0:color=0x151a19,ass=work/final.ass','-c:v','libx264','-threads','7','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','144k','-movflags','+faststart','-metadata','title=回头的人｜归乡疑云','-metadata','comment=中文剧情解说改编 · The Strange Love of Martha Ivers (1946)','submission/commentary.mp4']
    with (work/'video.log').open('w',encoding='utf8') as log:
        proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=log,bufsize=1024*1024)
        for idx,clip in enumerate(clips):
            first=round(clip['source_start_s']*srcfps);count=round((clip['output_end_s']-clip['output_start_s'])*FPS);cap.set(cv2.CAP_PROP_POS_FRAMES,first);current=first-1
            for frame in range(count):
                desired=first+round(frame*srcfps/FPS)
                while current<desired:
                    if not cap.grab():raise RuntimeError((idx,current))
                    current+=1
                ok,image=cap.retrieve();assert ok;proc.stdin.write(image.data)
            if idx%20==0:print('cut',idx+1,'/',len(clips),flush=True)
        proc.stdin.close();result=proc.wait();cap.release();assert result==0,result

if __name__=='__main__':
    if sys.argv[1] in ('compile','all'):compile_edit()
    if sys.argv[1] in ('render','all'):render()
