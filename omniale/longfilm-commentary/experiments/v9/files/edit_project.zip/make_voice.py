import hashlib,subprocess,sys,time,re
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

base=Path(__file__).resolve().parent
work=base/'work'; voices=work/'voices'; voices.mkdir(parents=True,exist_ok=True)
def read_edit():
    chapter=''; blocks=[]
    for block in re.split(r'\n\s*\n',(base/'edit.txt').read_text(encoding='utf8').strip()):
        lines=block.splitlines()
        if lines[0].startswith('# '):
            chapter=lines[0][2:];continue
        if lines[0].startswith('!'):
            start,end=map(float,lines[0][1:].split()); blocks.append(dict(kind='sync',chapter=chapter,start=start,end=end,lines=[row.split('|',1) for row in lines[1:]])); continue
        rows=[line.split('|',1) for line in lines]; text=''.join(row[1] for row in rows)
        tag=hashlib.sha256(text.encode()).hexdigest()[:14]; blocks.append(dict(kind='voice',chapter=chapter,lines=rows,text=text,tag=tag))
    return blocks

def get(block):
    if block['kind']!='voice':return
    tag=block['tag']; txt=voices/(tag+'.txt'); wav=voices/(tag+'.wav')
    if wav.exists() and wav.stat().st_size>1000:return
    txt.write_text(block['text'],encoding='utf8')
    for attempt in range(4):
        run=subprocess.run([sys.executable,str(base/'tools/tts.py'),'--text-file',str(txt),'--out',str(wav)],capture_output=True)
        if run.returncode==0:
            print(tag,wav.stat().st_size,flush=True); return
        print(run.stderr.decode(errors='replace'),flush=True);time.sleep(2+attempt*2)
    raise RuntimeError(tag)

if __name__=='__main__':
    with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(get,read_edit()))
