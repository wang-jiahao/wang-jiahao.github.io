import json,os
from pathlib import Path
import numpy as np
from faster_whisper import WhisperModel
from faster_whisper.audio import decode_audio,pad_or_trim
from faster_whisper.tokenizer import Tokenizer
from make_voice import read_edit,voices

def run():
    folder=Path.home()/'.cache/huggingface/hub/models--Systran--faster-whisper-small/snapshots'
    model=WhisperModel(str(next(folder.iterdir())),device='cpu',compute_type='int8',cpu_threads=6)
    tokenizer=Tokenizer(model.hf_tokenizer,model.model.is_multilingual,task='transcribe',language='zh')
    for block in read_edit():
        if block['kind']!='voice':continue
        path=voices/(block['tag']+'.json'); wav=path.with_suffix('.wav')
        if path.exists():continue
        audio=decode_audio(str(wav)); feat=model.feature_extractor(audio)
        starts=[]; pos=0
        for _,caption in block['lines']:
            starts.append(pos);pos+=len(caption)
        tokens=tokenizer.encode(block['text']);encoded=model.encode(pad_or_trim(feat)); aligned=model.find_alignment(tokenizer,[tokens],encoded,feat.shape[-1])[0]
        text='';words=[]
        for item in aligned:
            words.append(dict(text=item['word'],pos=len(text),start=item['start'],end=item['end'])); text+=item['word']
        assert text==block['text'],(text,block['text'])
        bounds=[]
        for offset in starts:
            word=next(w for w in words if w['pos']<=offset<w['pos']+len(w['text']));frac=(offset-word['pos'])/len(word['text']);bounds.append(word['start']+frac*(word['end']-word['start']))
        path.write_text(json.dumps(dict(bounds=bounds,words=words),ensure_ascii=False),encoding='utf8')
        print(block['tag'],','.join(f'{bound:.2f}' for bound in bounds),flush=True)

if __name__=='__main__':run()
