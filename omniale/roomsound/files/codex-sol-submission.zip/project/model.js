export const CLASSES = ['speech','clapping','telephone','laughter','domestic','footsteps','door','music','instrument','water','bell','knock'];
export const wrap = angle => ((angle + 180) % 360 + 360) % 360 - 180;
export const clone = value => JSON.parse(JSON.stringify(value));
export const active = (event, time) => event.start <= time && time < event.end;
export const order = (a,b) => a.start-b.start || a.id.localeCompare(b.id);
export function direction(event, time) {
  const points = [...event.trajectory].sort((a,b)=>a.time-b.time);
  if (time <= points[0].time) return {...points[0]};
  for (let i=1; i<points.length; i++) {
    if (time <= points[i].time) {
      const a=points[i-1], b=points[i], f=(time-a.time)/(b.time-a.time || 1);
      return {azimuth:wrap(a.azimuth+wrap(b.azimuth-a.azimuth)*f),elevation:a.elevation+(b.elevation-a.elevation)*f};
    }
  }
  return {...points.at(-1)};
}
export function validate(document) {
  if (!document || typeof document !== 'object' || Array.isArray(document) || document.version !== 1 || !Array.isArray(document.events)) throw Error('Use an object with version: 1 and an events array.');
  if (document.events.length > 600) throw Error('An annotation can contain at most 600 events.');
  const ids=new Set(), finite=n=>typeof n==='number' && Number.isFinite(n);
  for (const [i,e] of document.events.entries()) {
    const prefix=`Event ${i+1}: `;
    if (!e || typeof e!=='object' || typeof e.id!=='string' || ids.has(e.id)) throw Error(prefix+'each ID must be a unique string.');
    ids.add(e.id);
    if (!CLASSES.includes(e.class)) throw Error(prefix+'choose a valid sound class.');
    if (typeof e.source!=='string') throw Error(prefix+'source must be a string.');
    if (!finite(e.start) || !finite(e.end) || e.start<0 || e.end>60 || e.end<=e.start) throw Error(prefix+'use 0 ≤ start < end ≤ 60 seconds.');
    if (!Array.isArray(e.trajectory) || !e.trajectory.length) throw Error(prefix+'a trajectory needs at least one keyframe.');
    for (const p of e.trajectory) {
      if (!p || !finite(p.time) || !finite(p.azimuth) || !finite(p.elevation) || p.azimuth< -180 || p.azimuth>180 || p.elevation< -90 || p.elevation>90) throw Error(prefix+'keyframes need finite time, azimuth (−180…180°), and elevation (−90…90°).');
    }
  }
  return document;
}
export function reviewStale(review, events) {
  return !review.unresolved && !events.some(e=>review.event_ids.includes(e.id) && e.start<review.end && e.end>review.start);
}
