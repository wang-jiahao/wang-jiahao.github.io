# RoomSound

Run from the workspace root:

```powershell
node project/serve.mjs
```

Open the printed loopback URL (normally http://127.0.0.1:4173). The server uses the supplied sibling `public/media/` directory. The app itself needs no build, packages or network access. Alternatively, the supplied `toolkit/serve.mjs` serves the same project and media.

Press Play to enable the original FOA stereo preview. Drag the panorama or use the direction slider. Click a timeline segment to pause, seek and face its source. Class and performer filters change annotations, while the whole recording remains audible. Select a performer and enable Follow to track it.

The workbench edits an event's class and interval. Select an event, seek into it and drag its highlighted marker to edit the nearest trajectory keyframe. Changes save locally. Undo, redo, reset, JSON import and export are included. Five bookmarks are unresolved and explain why. [evidence.md](evidence.md) documents inference limits and actual tests.

Browser checks in this environment (Node 24+, Playwright and installed Chrome):

```powershell
$env:NODE_PATH='C:/Users/wjjhh/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'
$env:OMNIALE_CHROMIUM='C:/Program Files/Google/Chrome/Application/chrome.exe'
& 'C:/Users/wjjhh/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe' project/tests/verify.mjs
```

`tests/artifacts/verification.json` records the checks; PNGs show actual rendering. Tests use an explicit silent audio render sink because this headless Windows session has no physical audio endpoint. Independent synthetic signals are self-authored test inputs and are not scene annotations. See the evidence record for details.
