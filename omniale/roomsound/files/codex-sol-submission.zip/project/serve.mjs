// Dependency-free local server. Media stays in the supplied, immutable directory.
import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const project=path.dirname(fileURLToPath(import.meta.url)),media=path.resolve(project,'../public/media');
const allowedMedia=new Set(['scene.mp4','scene-foa.wav','scene-mono.wav','scene-stereo.wav']);
const types={'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.md':'text/plain; charset=utf-8','.mp4':'video/mp4','.wav':'audio/wav'};
const server=http.createServer(async(req,res)=>{
  try {
    const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);let target;
    if(pathname.startsWith('/media/')){const name=pathname.slice(7);if(!allowedMedia.has(name))throw Error();target=path.join(media,name);}
    else {target=path.resolve(project,pathname==='/'?'index.html':pathname.slice(1));if(!target.startsWith(project+path.sep))throw Error();}
    const ext=path.extname(target);if(!types[ext])throw Error();
    const bytes=await fs.readFile(target);let start=0,end=bytes.length-1,code=200;
    const headers={'Content-Type':types[ext],'Accept-Ranges':'bytes','Cache-Control':'no-store'};
    if(req.headers.range){
      const match=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range);if(!match)throw Error();
      if(match[1]){start=Number(match[1]);if(match[2])end=Math.min(end,Number(match[2]));}else start=Math.max(0,bytes.length-Number(match[2]));
      if(start>end||start>=bytes.length){res.writeHead(416,{'Content-Range':`bytes */${bytes.length}`}).end();return;}
      code=206;headers['Content-Range']=`bytes ${start}-${end}/${bytes.length}`;
    }
    headers['Content-Length']=Math.max(0,end-start+1);res.writeHead(code,headers).end(req.method==='HEAD'?undefined:bytes.subarray(start,end+1));
  }catch{res.writeHead(404).end('Resource not found');}
});
server.on('error',error=>{if(error.code==='EADDRINUSE')server.listen(0,'127.0.0.1');else throw error;});
server.on('listening',()=>console.log(`RoomSound: http://127.0.0.1:${server.address().port}`));
server.listen(Number(process.env.PORT)||4173,'127.0.0.1');
