import {CLASSES,wrap,clone,active,order,direction,validate,reviewStale} from './model.js';
import {SpatialAudio} from './audio.js';

const $=selector=>document.querySelector(selector), $$=selector=>[...document.querySelectorAll(selector)], test=id=>$(`[data-testid="${id}"]`);
const video=test('scene-video'), viewport=test('viewport'), canvas=$('#panorama'), ctx=canvas.getContext('2d',{alpha:false});
const audio=new SpatialAudio();
let original, documentState, reviews=[], undoStack=[], redoStack=[], storageKey, yaw=150, drag=null, isStarting=false, lastAudioSync=0, wavePeaks=[];
const sourceNames={p1:'Table · near seat',p2:'Table · far seat',p3:'Door-side performer',background:'Room equipment'};
const shortSource=id=>({p1:'P1',p2:'P2',p3:'P3',background:'Room'}[id] || id);
const sourceName=id=>sourceNames[id] || id;
const pretty=text=>text.charAt(0).toUpperCase()+text.slice(1);
const timeText=t=>`${String(Math.floor(t/60)).padStart(2,'0')}:${(t%60).toFixed(1).padStart(4,'0')}`;
const degreeText=n=>`${n>=0?'+':'−'}${Math.abs(n).toFixed(0)}°`;
const eventColor=e=>`var(--${e.class})`;
const events=()=>documentState?.events || [];
const matches=e=>(test('filter').value==='all' || e.class===test('filter').value) && (test('source-filter').value==='all' || e.source===test('source-filter').value);
const safeText=(tag,text,className)=>{const e=document.createElement(tag);e.textContent=text;if(className)e.className=className;return e;};
function status(message) {$('#audio-state').textContent=message;}
function setYaw(value,manual=false) {
  yaw=wrap(Number(value));
  if(manual)test('follow-source').checked=false;
  test('yaw').value=yaw;
  $('#yaw-value').textContent=$('#view-yaw').textContent=$('#compass-degrees').textContent=degreeText(yaw);
  audio.setYaw(yaw);
}
function follow(time) {
  if(!test('follow-source').checked || test('source-filter').value==='all')return;
  const target=events().filter(e=>e.source===test('source-filter').value && active(e,time)).sort(order)[0];
  if(target)setYaw(direction(target,time).azimuth);
}
function drawPanorama() {
  if(video.readyState<2)return;
  const width=canvas.width,height=canvas.height, sourceW=video.videoWidth,sourceH=video.videoHeight;
  const cropW=sourceW/3,cropH=sourceH/2;
  let left=((180-yaw)/360*sourceW-cropW/2+sourceW)%sourceW;
  const first=Math.min(cropW,sourceW-left),dest=first/cropW*width;
  ctx.drawImage(video,left,sourceH/4,first,cropH,0,0,dest,height);
  if(first<cropW)ctx.drawImage(video,0,sourceH/4,cropW-first,cropH,dest,0,width-dest,height);
  $('#scene-loading').hidden=true;
}
function drawCompass(time) {
  const cv=$('#compass'), c=cv.getContext('2d'), w=cv.width,h=cv.height,cx=w/2,cy=98,r=72;
  c.clearRect(0,0,w,h);c.save();c.translate(cx,cy);
  c.strokeStyle='#d8e1cd';c.lineWidth=1;
  for(const rad of [r,r*.61]){c.beginPath();c.arc(0,0,rad,0,Math.PI*2);c.stroke();}
  for(let a=0;a<360;a+=15){const x=a*Math.PI/180;c.beginPath();c.moveTo(Math.sin(x)*(r-4),-Math.cos(x)*(r-4));c.lineTo(Math.sin(x)*(r+1),-Math.cos(x)*(r+1));c.stroke();}
  const ang=-yaw*Math.PI/180-Math.PI/2;
  c.fillStyle='#dce9c7';c.beginPath();c.moveTo(0,0);c.arc(0,0,r,ang-Math.PI/3,ang+Math.PI/3);c.closePath();c.fill();
  c.strokeStyle='#94ad7c';c.beginPath();c.moveTo(0,0);c.lineTo(Math.cos(ang)*r,Math.sin(ang)*r);c.stroke();
  c.font='9px Segoe UI';c.fillStyle='#8d9b7f';c.textAlign='center';c.fillText('0°',0,-r-12);c.fillText('−90°',r+20,3);c.fillText('+90°',-r-22,3);
  for(const e of events().filter(e=>matches(e)&&active(e,time))){
    const p=direction(e,time),a=-p.azimuth*Math.PI/180-Math.PI/2;
    c.fillStyle=getComputedStyle(document.documentElement).getPropertyValue('--'+e.class).trim()||'#8a9c7a';
    c.beginPath();c.arc(Math.cos(a)*r*.82,Math.sin(a)*r*.82,4,0,Math.PI*2);c.fill();c.strokeStyle='#fff';c.stroke();
  }
  c.fillStyle='#28533f';c.beginPath();c.arc(0,0,4,0,Math.PI*2);c.fill();c.restore();
}
function updateMarkers(time) {
  const current=events().filter(e=>active(e,time)&&matches(e));
  const ids=new Set(current.map(e=>e.id));
  for(const el of $$('#markers .marker')) {
    const e=events().find(e=>e.id===el.dataset.eventId);
    const p=direction(e,time),d=wrap(p.azimuth-yaw),visible=ids.has(e.id)&&Math.abs(d)<60&&Math.abs(p.elevation)<45;
    el.hidden=!visible;
    if(visible && !(drag?.type==='marker' && drag.id===e.id)) {el.style.left=`${(0.5-d/120)*100}%`;el.style.top=`${(0.5-p.elevation/90)*100}%`;}
    el.classList.toggle('selected',test('edit-target').value===e.id);
  }
  const signature=current.map(e=>e.id).join('|');
  if($('#now-playing').dataset.signature!==signature){
    $('#now-playing').dataset.signature=signature;$('#now-playing').replaceChildren();
    for(const e of current) {const chip=safeText('div','', 'now-chip');chip.style.setProperty('--event-color',eventColor(e));chip.append(document.createElement('i'),document.createTextNode(pretty(e.class)),safeText('span',shortSource(e.source)));$('#now-playing').append(chip);}
    if(!current.length)$('#now-playing').append(safeText('span','No matching annotations at this moment.','status-empty'));
  }
  $('#active-count').textContent=current.length;
  for(const bar of $$('[data-role="event"]'))bar.classList.toggle('current',ids.has(bar.dataset.eventId));
}
function renderCurrent() {
  if(!documentState)return;
  const t=Math.max(0,Math.min(60,video.currentTime));
  follow(t);drawPanorama();drawCompass(t);updateMarkers(t);
  test('seek').value=t;$('#current-time').textContent=timeText(t);
  const playhead=$('.timeline-playhead');
  if(playhead)playhead.style.left=`calc(128px + (100% - 128px) * ${t/60})`;
  drawWaveform(t);
}
function pause() {video.pause();audio.stop();updatePlay();}
function updatePlay() {const playing=!video.paused;$('#play-icon').textContent=playing?'Ⅱ':'▶';test('play').setAttribute('aria-label',playing?'Pause recording':'Play recording');test('play').setAttribute('aria-pressed',String(playing));if(!isStarting)status(playing?'Spatial stereo · playing':'Paused · look around');}
function seek(time) {time=Math.max(0,Math.min(60,Number(time)));audio.stop();video.currentTime=time;renderCurrent();}
function loopSettings() {
  const a=test('loop-start').value,b=test('loop-end').value,start=Number(a),end=Number(b);
  const valid=a.trim()!==''&&b.trim()!==''&&Number.isFinite(start)&&Number.isFinite(end)&&start>=0&&end<=60&&start<end;
  return {start,end,valid,enabled:test('loop').checked&&valid};
}
function updateLoop() {
  const s=loopSettings();$('#loop-status').textContent=s.valid?'seconds':'Use 0 ≤ In < Out ≤ 60';
  $('#loop-status').style.color=s.valid?'':'#a4452d';
  const r=$('#loop-region');r.style.display=s.enabled?'block':'none';r.style.left=`${s.start/60*100}%`;r.style.width=`${(s.end-s.start)/60*100}%`;
}
function drawWaveform(time=video.currentTime) {
  const cv=$('#waveform'),c=cv.getContext('2d'),w=cv.width,h=cv.height;c.clearRect(0,0,w,h);
  const n=wavePeaks.length||160;
  for(let i=0;i<n;i++) {const height=wavePeaks.length?Math.max(2,Math.sqrt(wavePeaks[i])*h*.95):2;c.fillStyle=i/n<time/60?'#6d8e5b':'#d1dbc7';c.fillRect(i*w/n,(h-height)/2,Math.max(1,w/n-1.5),height);}
}
function options(select,values,label,first) {
  const previous=select.value;select.replaceChildren(new Option(first,'all'));
  for(const v of values)select.add(new Option(label(v),v));
  select.value=values.includes(previous)?previous:'all';
}
function renderFilters() {
  const classes=CLASSES.filter(c=>events().some(e=>e.class===c));
  const sources=[...new Set(events().map(e=>e.source))].sort();
  options(test('filter'),classes,pretty,'All sounds');options(test('source-filter'),sources,s=>`${shortSource(s)} · ${sourceName(s)}`,'All performers');
  if(test('source-filter').value==='all')test('follow-source').checked=false;
  test('follow-source').disabled=test('source-filter').value==='all';
}
function renderTimeline() {
  const root=$('#timeline-content');root.replaceChildren();
  const ruler=safeText('div','', 'ruler');for(let t=0;t<=60;t+=10){const label=safeText('span',`${String(t).padStart(2,'0')}s`);label.style.left=`${t/60*100}%`;ruler.append(label);}root.append(ruler);
  const shown=events().filter(matches),classOrder=['music','domestic','speech','laughter','clapping','bell',...CLASSES];
  const groups=[...new Set(shown.map(e=>e.source+'\0'+e.class))].sort((a,b)=>classOrder.indexOf(a.split('\0')[1])-classOrder.indexOf(b.split('\0')[1]) || a.localeCompare(b));
  for(const key of groups) {
    const [source,cls]=key.split('\0'),row=safeText('div','','timeline-row'),label=safeText('div','','track-label'),area=safeText('div','','track-area');
    label.style.setProperty('--event-color',`var(--${cls})`);label.append(document.createElement('i'),safeText('span',`${pretty(cls)} `),safeText('small',shortSource(source)));label.title=sourceName(source);row.append(label,area);
    const laneEnds=[];
    for(const e of shown.filter(e=>e.source===source&&e.class===cls).sort(order)) {
      let lane=laneEnds.findIndex(t=>t<=e.start);if(lane<0)lane=laneEnds.length;laneEnds[lane]=e.end;
      const bar=safeText('button',`${pretty(e.class)} · ${shortSource(e.source)}`,'event-bar');bar.dataset.role='event';bar.dataset.eventId=e.id;bar.style.setProperty('--event-color',eventColor(e));bar.style.left=`${e.start/60*100}%`;bar.style.width=`${(e.end-e.start)/60*100}%`;bar.style.top=`${7+lane*27}px`;bar.title=`${e.id} · ${sourceName(e.source)} · ${e.start.toFixed(2)}–${e.end.toFixed(2)} s`;bar.setAttribute('aria-label',bar.title);bar.classList.toggle('editing',test('edit-target').value===e.id);bar.addEventListener('click',()=>navigateEvent(e.id));area.append(bar);
    }
    area.style.height=`${Math.max(1,laneEnds.length)*27+7}px`;root.append(row);
  }
  if(!shown.length)root.append(safeText('p','No events match these filters. Try all sounds or all performers.','empty-state'));
  root.append(safeText('div','','timeline-playhead'));
  $('#event-count').textContent=`${shown.length} of ${events().length} events`;
  $('#legend').replaceChildren();
  for(const cls of CLASSES.filter(c=>shown.some(e=>e.class===c))) {const item=safeText('span','');item.style.setProperty('--event-color',`var(--${cls})`);item.append(document.createElement('i'),document.createTextNode(pretty(cls)));$('#legend').append(item);}
}
function renderMarkers() {
  $('#markers').replaceChildren();
  for(const e of events()) {
    const marker=safeText('div','','marker');marker.dataset.role='marker';marker.dataset.eventId=e.id;marker.style.setProperty('--event-color',eventColor(e));marker.append(safeText('span',`${pretty(e.class)} · ${shortSource(e.source)}`,'marker-label'));marker.hidden=true;
    marker.addEventListener('pointerdown',ev=>beginMarkerDrag(ev,e.id));$('#markers').append(marker);
  }
  $('#now-playing').dataset.signature='';
}
function loadEditor() {
  const e=events().find(e=>e.id===test('edit-target').value);
  test('edit-class').value=e?.class||'speech';test('edit-start').value=e?.start??'';test('edit-end').value=e?.end??'';
  test('edit-apply').disabled=!e;
  $('#edit-description').textContent=e?`${e.id} · ${sourceName(e.source)} · ${e.trajectory.length} direction keyframe${e.trajectory.length===1?'':'s'}. Seek into this event, then drag its highlighted marker to move the nearest keyframe.`:'Choose an event to edit its timing and class. To move a direction, seek into that event and drag its selected marker. Edits save in this browser.';
  for(const bar of $$('[data-role="event"]'))bar.classList.toggle('editing',bar.dataset.eventId===e?.id);
  renderCurrent();
}
function renderEditorOptions() {
  const previous=test('edit-target').value, select=test('edit-target');select.replaceChildren(new Option('Choose an event…','none'));
  for(const e of events())select.add(new Option(`${e.id} · ${pretty(e.class)} · ${shortSource(e.source)}`,e.id));
  select.value=events().some(e=>e.id===previous)?previous:'none';loadEditor();
}
const reviewTitles=['Two performers laugh together','Two performers clap together','Laughing while clapping','The longest speech interval','Five sounds at once','Bell meets laughter','Bell & two overlapping voices','The first overlapping voices','The continuous background pair','Speech after the final clap'];
function renderReviews() {
  $('#reviews').replaceChildren();
  for(const [i,r] of reviews.entries()) {
    const card=safeText('button','',`review-card${r.unresolved?' unresolved':''}`);card.dataset.role='review';card.dataset.reviewId=r.id;card.dataset.stale=String(reviewStale(r,events()));
    card.append(safeText('span',`${String(i+1).padStart(2,'0')} ${r.unresolved?' / OPEN QUESTION':'↗'}`,'review-number'),safeText('strong',reviewTitles[Number(r.id.slice(1))-1]||r.id));
    if(r.unresolved)card.append(safeText('span',r.reason||r.note,'review-reason'));
    card.append(safeText('span',r.unresolved?'Needs closer review':`${r.start.toFixed(2)} — ${r.end.toFixed(2)} s`,'review-time'));card.title=r.note;
    card.addEventListener('click',()=>navigateReview(r));$('#reviews').append(card);
  }
}
function navigateEvent(id) {
  const e=events().find(e=>e.id===id);if(!e)return;
  pause();test('follow-source').checked=false;const time=(e.start+e.end)/2;seek(time);setYaw(direction(e,time).azimuth);test('edit-target').value=id;loadEditor();renderCurrent();
}
function navigateReview(r) {
  let note=$('#review-note');if(!note){note=safeText('p','','small-copy');note.id='review-note';note.style.marginTop='14px';$('#reviews').after(note);}note.textContent=`${r.id.toUpperCase()} · ${r.note}`;
  if(r.unresolved)return;
  pause();test('follow-source').checked=false;const time=(r.start+r.end)/2,source=r.source_ids[0];
  test('filter').value='all';test('source-filter').value=source;test('follow-source').disabled=!source||test('source-filter').value==='all';
  const candidates=events().filter(e=>r.event_ids.includes(e.id)&&e.source===source);
  const target=candidates.filter(e=>active(e,time)).sort(order)[0]||candidates.sort((a,b)=>Math.max(a.start-time,0,time-a.end)-Math.max(b.start-time,0,time-b.end)||order(a,b))[0];
  seek(time);if(target){setYaw(direction(target,time).azimuth);test('edit-target').value=target.id;loadEditor();}renderTimeline();renderCurrent();
}
function setError(text='') {test('edit-error').textContent=text;}
function persist() {
  try{localStorage.setItem(storageKey,JSON.stringify(documentState));$('#saved-state').textContent='● Saved in this browser';}
  catch{$('#saved-state').textContent='● Session only · storage unavailable';}
}
function refreshDerived() {
  renderFilters();renderTimeline();renderMarkers();renderEditorOptions();renderReviews();
  test('undo').disabled=undoStack.length===0;test('redo').disabled=redoStack.length===0;
  // This complete synchronous render follows a single state replacement.
  renderCurrent();persist();
}
function commit(next) {
  try{validate(next);}catch(e){setError(e.message);return false;}
  undoStack.push(clone(documentState));redoStack=[];documentState=clone(next);setError();refreshDerived();return true;
}
function beginMarkerDrag(ev,id) {
  if(test('edit-target').value!==id)return;
  ev.preventDefault();ev.stopPropagation();test('follow-source').checked=false;
  const rect=ev.currentTarget.getBoundingClientRect(),box=viewport.getBoundingClientRect();
  drag={type:'marker',id,startX:ev.clientX,startY:ev.clientY,x:rect.x+rect.width/2-box.x,y:rect.y+rect.height/2-box.y,yaw,element:ev.currentTarget};
  ev.currentTarget.setPointerCapture(ev.pointerId);
}
viewport.addEventListener('pointerdown',ev=>{
  if(ev.button!==0 || drag)return;
  ev.preventDefault();test('follow-source').checked=false;drag={type:'view',startX:ev.clientX,yaw};viewport.setPointerCapture(ev.pointerId);
});
viewport.addEventListener('pointermove',ev=>{
  if(!drag)return;
  const box=viewport.getBoundingClientRect();
  if(drag.type==='view') {setYaw(drag.yaw+(ev.clientX-drag.startX)/box.width*120,true);renderCurrent();}
  else {drag.element.style.left=`${drag.x+ev.clientX-drag.startX}px`;drag.element.style.top=`${drag.y+ev.clientY-drag.startY}px`;}
});
viewport.addEventListener('pointerup',ev=>{
  if(!drag)return;const state=drag;drag=null;
  if(state.type==='marker') {
    const box=viewport.getBoundingClientRect(),x=state.x+ev.clientX-state.startX,y=state.y+ev.clientY-state.startY;
    const next=clone(documentState),event=next.events.find(e=>e.id===state.id),t=video.currentTime;
    const p=event.trajectory.map((p,i)=>({p,i})).sort((a,b)=>Math.abs(a.p.time-t)-Math.abs(b.p.time-t)||a.p.time-b.p.time||a.i-b.i)[0].p;
    p.azimuth=wrap(state.yaw+120*(.5-x/box.width));p.elevation=Math.max(-90,Math.min(90,90*(.5-y/box.height)));commit(next);
  }
  renderCurrent();
});
viewport.addEventListener('pointercancel',()=>{drag=null;renderCurrent();});
viewport.addEventListener('keydown',ev=>{if(['ArrowLeft','ArrowRight'].includes(ev.key)){ev.preventDefault();setYaw(yaw+(ev.key==='ArrowLeft'?5:-5),true);renderCurrent();}});
for(const type of ['input','change']) {
  test('yaw').addEventListener(type,()=>{setYaw(test('yaw').value,true);renderCurrent();});
  test('seek').addEventListener(type,()=>{if(Math.abs(video.currentTime-Number(test('seek').value))>.001)seek(test('seek').value);else renderCurrent();});
  test('volume').addEventListener(type,()=>{audio.setVolume(Number(test('volume').value));$('#volume-value').textContent=`${Math.round(audio.volume*100)}%`;});
  for(const id of ['loop','loop-start','loop-end'])test(id).addEventListener(type,updateLoop);
}
test('play').addEventListener('click',async()=>{
  if(!video.paused){pause();return;}if(isStarting)return;
  isStarting=true;status('Preparing spatial audio…');test('play').disabled=true;let failure;
  try {
    await audio.prepare();const loop=loopSettings();
    if(video.currentTime>=59.99 || (loop.enabled && (video.currentTime<loop.start || video.currentTime>=loop.end)))seek(loop.enabled?loop.start:0);
    if(video.seeking)await new Promise(resolve=>video.addEventListener('seeked',resolve,{once:true}));
    await video.play();audio.start(video.currentTime);
  } catch(error){pause();failure=error.message;}
  finally{isStarting=false;test('play').disabled=false;updatePlay();if(failure)status(failure);}
});
video.addEventListener('pause',()=>{audio.stop();updatePlay();renderCurrent();});
video.addEventListener('play',updatePlay);
video.addEventListener('waiting',()=>audio.stop());
video.addEventListener('playing',()=>{if(audio.buffer)audio.start(video.currentTime);});
video.addEventListener('seeking',()=>{audio.stop();renderCurrent();});
video.addEventListener('seeked',()=>{if(!video.paused)audio.start(video.currentTime);renderCurrent();});
video.addEventListener('loadeddata',()=>{resize();renderCurrent();});
video.addEventListener('timeupdate',renderCurrent);
video.addEventListener('ended',()=>{
  audio.stop();
  const loop=loopSettings();
  // At an Out point of 60 the media can reach ended between animation frames.
  if(loop.enabled){seek(loop.start);video.play().then(()=>audio.start(video.currentTime)).catch(error=>status(error.message));}
  updatePlay();
});
test('filter').addEventListener('change',()=>{renderTimeline();renderCurrent();});
test('source-filter').addEventListener('change',()=>{
  if(test('source-filter').value==='all')test('follow-source').checked=false;
  test('follow-source').disabled=test('source-filter').value==='all';renderTimeline();renderCurrent();
});
test('follow-source').addEventListener('change',renderCurrent);
test('edit-target').addEventListener('change',loadEditor);
test('edit-apply').addEventListener('click',()=>{
  const id=test('edit-target').value;if(id==='none'){setError('Choose an event first.');return;}
  const start=test('edit-start').value,end=test('edit-end').value;
  if(start.trim()==='' || end.trim()===''){setError('Start and end must both be finite numbers.');return;}
  const next=clone(documentState),e=next.events.find(e=>e.id===id);if(!e){setError('This event no longer exists.');return;}
  e.class=test('edit-class').value;e.start=Number(start);e.end=Number(end);commit(next);
});
test('undo').addEventListener('click',()=>{if(!undoStack.length)return;redoStack.push(clone(documentState));documentState=undoStack.pop();setError();refreshDerived();});
test('redo').addEventListener('click',()=>{if(!redoStack.length)return;undoStack.push(clone(documentState));documentState=redoStack.pop();setError();refreshDerived();});
test('reset').addEventListener('click',()=>{commit(original);});
function exportDocument(){const text=JSON.stringify(documentState,null,2);test('export-output').value=text;return text;}
test('export').addEventListener('click',exportDocument);
$('#download-export').addEventListener('click',()=>{const blob=new Blob([exportDocument()],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='roomsound-events.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
test('import-apply').addEventListener('click',()=>{try{const next=JSON.parse(test('import-input').value);commit(next);}catch(error){setError('Invalid JSON: '+error.message);}});
function resize(){const r=viewport.getBoundingClientRect(),scale=Math.min(2,devicePixelRatio||1);canvas.width=Math.round(r.width*scale);canvas.height=Math.round(r.height*scale);const w=$('#waveform').getBoundingClientRect();$('#waveform').width=Math.round(w.width*scale);$('#waveform').height=Math.round(w.height*scale);renderCurrent();}
new ResizeObserver(resize).observe(viewport);
async function init() {
  const [doc,reviewDoc]=await Promise.all([fetch('events.json').then(r=>r.json()),fetch('reviews.json').then(r=>r.json())]);
  original=clone(validate(doc));reviews=reviewDoc.reviews;
  let hash=2166136261;for(const ch of JSON.stringify(original)){hash=Math.imul(hash^ch.charCodeAt(0),16777619);}
  storageKey='roomsound.annotations.v1.'+(hash>>>0);documentState=clone(original);
  let restored=false;
  try{const saved=localStorage.getItem(storageKey);if(saved){documentState=validate(JSON.parse(saved));restored=true;}}catch{}
  for(const cls of CLASSES)test('edit-class').add(new Option(pretty(cls),cls));
  refreshDerived();$('#saved-state').textContent=restored?'● Restored from this browser':'● Original annotation';
  setYaw(yaw);resize();updateLoop();status('Ready when you are');
  audio.loaded.then(w=>{const signal=w.channels[0],count=220;wavePeaks=Array.from({length:count},(_,i)=>{const a=Math.floor(i*signal.length/count),b=Math.floor((i+1)*signal.length/count);let sum=0;for(let j=a;j<b;j++)sum+=signal[j]*signal[j];return Math.sqrt(sum/(b-a));});const max=Math.max(...wavePeaks,.001);wavePeaks=wavePeaks.map(p=>p/max);drawWaveform();}).catch(()=>status('Spatial audio unavailable · press Play for details'));
  document.body.dataset.ready='true';
}
function tick(now) {
  if(!video.paused && documentState){
    const loop=loopSettings();if(loop.enabled&&video.currentTime>=loop.end-.008)seek(loop.start);
    if(!video.seeking && video.readyState>=3 && now-lastAudioSync>200){audio.sync(video.currentTime);lastAudioSync=now;}
    renderCurrent();
  }
  requestAnimationFrame(tick);
}
requestAnimationFrame(tick);
init().catch(error=>{const el=$('#app-error');el.hidden=false;el.textContent='Unable to open the annotation: '+error.message;console.error(error);});
