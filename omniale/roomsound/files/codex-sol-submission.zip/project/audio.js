// Deinterleave the original W,Y,Z,X samples ourselves. decodeAudioData may
// assign speaker layouts to four-channel WAVs and remap the Ambisonic channels.
export function parseWave(bytes) {
  const v=new DataView(bytes), tag=offset=>String.fromCharCode(...new Uint8Array(bytes,offset,4));
  if (tag(0)!=='RIFF' || tag(8)!=='WAVE') throw Error('The spatial recording is not a RIFF WAV.');
  let format, data;
  for(let offset=12;offset+8<=v.byteLength;) {
    const name=tag(offset), size=v.getUint32(offset+4,true), start=offset+8;
    if(start+size>v.byteLength) throw Error('Incomplete audio file.');
    if(name==='fmt ') {
      let encoding=v.getUint16(start,true);
      if(encoding===65534 && size>=40) encoding=v.getUint16(start+24,true);
      format={encoding,channels:v.getUint16(start+2,true),rate:v.getUint32(start+4,true),block:v.getUint16(start+12,true),bits:v.getUint16(start+14,true)};
    }
    if(name==='data') data={start,size};
    offset=start+size+(size%2);
  }
  if(!format || !data || format.channels!==4 || ![1,3].includes(format.encoding)) throw Error('The spatial recording must have four W,Y,Z,X channels.');
  const count=Math.floor(data.size/format.block), channels=Array.from({length:4},()=>new Float32Array(count)), stride=format.bits/8;
  for(let i=0;i<count;i++) for(let c=0;c<4;c++) {
    const o=data.start+i*format.block+c*stride;
    let sample;
    if(format.encoding===3 && format.bits===32) sample=v.getFloat32(o,true);
    else if(format.bits===16) sample=v.getInt16(o,true)/32768;
    else if(format.bits===24) sample=((v.getUint8(o)|v.getUint8(o+1)<<8|v.getUint8(o+2)<<16)<<8>>8)/8388608;
    else if(format.bits===32) sample=v.getInt32(o,true)/2147483648;
    else if(format.bits===8) sample=(v.getUint8(o)-128)/128;
    else throw Error('Unsupported PCM depth.');
    channels[c][i]=sample;
  }
  return {channels,rate:format.rate,count};
}

export class SpatialAudio {
  constructor() {
    this.volume=.8;this.yaw=0;this.source=null;
    this.loaded=fetch('/media/scene-foa.wav').then(r=>{if(!r.ok)throw Error('Spatial audio could not be loaded.');return r.arrayBuffer();}).then(parseWave);
    // Attach a rejection handler immediately; display any load error on Play.
    this.loaded.catch(()=>{});
  }
  async prepare() {
    if(!this.context) {
      this.context=new AudioContext({latencyHint:'interactive'});
      this.split=this.context.createChannelSplitter(4);
      this.merger=this.context.createChannelMerger(2);
      this.master=this.context.createGain();this.master.gain.value=this.volume;
      this.master.channelCount=2;this.master.channelCountMode='explicit';
      this.merger.connect(this.master).connect(this.context.destination);
      this.coefficients=[];
      for(const [channel,ear] of [[0,0],[0,1],[3,0],[3,1],[1,0],[1,1]]) {
        const gain=this.context.createGain();this.split.connect(gain,channel);gain.connect(this.merger,0,ear);this.coefficients.push(gain);
      }
      this.setYaw(this.yaw);
    }
    await this.context.resume();
    if(!this.buffer) {
      const wave=await this.loaded;
      this.buffer=this.context.createBuffer(4,wave.count,wave.rate);
      wave.channels.forEach((data,i)=>this.buffer.copyToChannel(data,i));
    }
  }
  setYaw(yaw) {
    this.yaw=yaw;
    if(!this.coefficients)return;
    const a=yaw*Math.PI/180, values=[.5,.5,-.5*Math.sin(a),.5*Math.sin(a),.5*Math.cos(a),-.5*Math.cos(a)];
    this.coefficients.forEach((gain,i)=>gain.gain.setValueAtTime(values[i],this.context.currentTime));
  }
  setVolume(volume) {
    this.volume=volume;
    if(this.master)this.master.gain.setValueAtTime(volume,this.context.currentTime);
  }
  start(time) {
    this.stop();
    if(!this.buffer || this.context.state!=='running' || time>=this.buffer.duration)return;
    this.source=this.context.createBufferSource();this.source.buffer=this.buffer;this.source.connect(this.split);
    this.offset=time;this.startedAt=this.context.currentTime;
    this.source.start(0,Math.max(0,time));
  }
  stop() {if(this.source){try{this.source.stop();}catch{}this.source.disconnect();this.source=null;}}
  sync(time) {
    if(!this.context || !this.buffer)return;
    if(!this.source || Math.abs(this.offset+this.context.currentTime-this.startedAt-time)>.085)this.start(time);
  }
}
