export const CLASSES=['speech','clapping','telephone','laughter','domestic','footsteps','door','music','instrument','water','bell','knock'];
export const wrap=a=>((a+180)%360+360)%360-180;
export const copy=o=>structuredClone(o);
export function validate(doc){
  if(!doc||typeof doc!=='object'||Array.isArray(doc)||doc.version!==1||!Array.isArray(doc.events))throw Error('Use a document with version: 1 and an events array.');
  if(doc.events.length>600)throw Error('An annotation can contain at most 600 events.');
  const ids=new Set();
  const finite=x=>typeof x==='number'&&Number.isFinite(x);
  for(const e of doc.events){
    if(!e||typeof e!=='object'||typeof e.id!=='string'||!e.id.trim()||ids.has(e.id))throw Error('Every event needs a nonempty, unique string ID.');
    ids.add(e.id);
    if(typeof e.source!=='string'||!e.source.trim())throw Error(`Event ${e.id} needs a nonempty source ID.`);
    if(!CLASSES.includes(e.class))throw Error(`Event ${e.id} has an unsupported sound class.`);
    if(!finite(e.start)||!finite(e.end)||e.start<0||e.end>60||e.end<=e.start)throw Error(`Event ${e.id}: start and end must satisfy 0 ≤ start < end ≤ 60.`);
    if(!Array.isArray(e.trajectory)||e.trajectory.length<1||e.trajectory.length>1000)throw Error(`Event ${e.id} needs 1–1000 trajectory keyframes.`);
    let prev=-Infinity;
    for(const k of e.trajectory){
      if(!k||!finite(k.time)||k.time<0||k.time>60||k.time<=prev||!finite(k.azimuth)||k.azimuth< -180||k.azimuth>180||!finite(k.elevation)||k.elevation< -90||k.elevation>90)throw Error(`Event ${e.id}: keyframes need increasing times in [0,60] and valid directions.`);
      prev=k.time;
    }
  }
  return {version:1,events:copy(doc.events)};
}
export function direction(event,time){
  const ks=event.trajectory;
  if(time<=ks[0].time)return {azimuth:ks[0].azimuth,elevation:ks[0].elevation};
  const last=ks.at(-1);if(time>=last.time)return {azimuth:last.azimuth,elevation:last.elevation};
  const b=ks.findIndex(k=>k.time>time),left=ks[b-1],right=ks[b],f=(time-left.time)/(right.time-left.time);
  return {azimuth:wrap(left.azimuth+wrap(right.azimuth-left.azimuth)*f),elevation:left.elevation+(right.elevation-left.elevation)*f};
}
export const active=(e,t)=>e.start<=t&&t<e.end;
export const order=(a,b)=>a.start-b.start||(a.id<b.id?-1:a.id>b.id?1:0);
export function splitEvent(doc,id,cut){
  const event=doc.events.find(e=>e.id===id);
  if(!event)throw Error('Select an event to split.');
  if(typeof cut!=='number'||!Number.isFinite(cut)||cut<=event.start||cut>=event.end)throw Error('Split time must be strictly inside the selected interval.');
  if(doc.events.length>=600)throw Error('Splitting would exceed the 600-event limit.');
  const next=copy(doc),index=next.events.findIndex(e=>e.id===id);
  let n=1;while(doc.events.some(e=>e.id===`${id}~split-${n}`))n++;
  const piece=(start,end,newId)=>({...copy(event),id:newId,start,end,trajectory:[{time:start,...direction(event,start)},...copy(event.trajectory.filter(k=>k.time>start&&k.time<end)),{time:end,...direction(event,end)}]});
  next.events.splice(index,1,piece(event.start,cut,id),piece(cut,event.end,`${id}~split-${n}`));
  return next;
}
export function numberField(input){if(input.value.trim()===''||!Number.isFinite(Number(input.value)))throw Error('Fill every numeric field with a finite number.');return Number(input.value);}
