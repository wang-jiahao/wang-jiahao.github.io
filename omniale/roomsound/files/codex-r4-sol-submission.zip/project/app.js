import {CLASSES,wrap,copy,validate,direction,active,order,splitEvent,numberField} from './model.js';
import {SpatialPlayer} from './player.js';
const $=id=>document.querySelector(`[data-testid="${id}"]`), el=id=>document.getElementById(id);
const colors={speech:'#7762c5',clapping:'#cb8c40',telephone:'#c25774',laughter:'#d07975',domestic:'#84917d',footsteps:'#678fa9',door:'#8b7262',music:'#4c8b79',instrument:'#938047',water:'#5797a7',bell:'#b19b41',knock:'#8b7262'};
const names={'table-near':'Table · near','table-far':'Table · far','door-performer':'Door · moving','room-background':'Room background'};
const hasName=id=>Object.hasOwn(names,id);
const sourceName=id=>hasName(id)?names[id]:id;
const titles=['Two performers laughing','Two performers clapping','Laughing while clapping','Longest continuous speech','Five overlapping sources','Bell meets laughter','Bell & two speakers','Two simultaneous speakers','Continuous backgrounds','Speech after the last clap'];
const storageKey='roomsound.annotation.v1';
let original,state,reviews=[],undo=[],redo=[],yaw=0,editId='none',drag=null,frameId=0,looping=false,eventMap=new Map(),visibleEvents=[];
const video=$('scene-video'),canvas=el('panorama'),ctx=canvas.getContext('2d'),viewport=$('viewport');
const player=new SpatialPlayer(video,text=>{el('audio-status').textContent=text;updateTransport();});
const timeText=t=>`${String(Math.floor(t/60)).padStart(2,'0')}:${(t%60).toFixed(1).padStart(4,'0')}`;
function option(value,label){const o=document.createElement('option');o.value=value;o.textContent=label;return o;}
function error(message){$('edit-error').textContent=message;}
function attempt(fn){try{fn();}catch(e){error(e.message);}}
function store(){try{localStorage.setItem(storageKey,JSON.stringify(state));el('save-status').textContent='Saved in this browser · '+state.events.length+' events';}catch{el('save-status').textContent='Browser storage unavailable. Export to keep your edits.';}}
function commit(doc,message='Annotation updated'){
  const valid=validate(doc);undo.push(copy(state));redo=[];state=valid;error('');rebuild();store();el('save-status').textContent+=' · '+message;
}
function updateHistory(){ $('undo').disabled=!undo.length;$('redo').disabled=!redo.length; }
function selectOptions(select,values,first,labeler=x=>x){const selected=select.value;select.replaceChildren(option(first[0],first[1]),...values.map(v=>option(v,labeler(v))));select.value=values.includes(selected)?selected:first[0];}
function rebuild(){
  eventMap=new Map(state.events.map(e=>[e.id,e]));
  const classes=CLASSES.filter(c=>state.events.some(e=>e.class===c)),sources=[...new Set(state.events.map(e=>e.source))];
  selectOptions($('filter'),classes,['all','All sounds'],c=>c[0].toUpperCase()+c.slice(1));
  selectOptions($('source-filter'),sources,['all','All performers'],s=>`${sourceName(s)}${hasName(s)?' · '+s:''}`);
  if($('source-filter').value==='all')$('follow-source').checked=false;
  if(!state.events.some(e=>e.id===editId))editId='none';
  $('edit-target').replaceChildren(option('none','Select an event…'),...state.events.map(e=>option(e.id,`${e.id} · ${e.class} · ${e.source}`)));$('edit-target').value=editId;
  loadEditor();renderTimeline();renderReviews();renderMarkers();updateHistory();updateFollowUI();refresh();
}
function filtered(){return state.events.filter(e=>($('filter').value==='all'||e.class===$('filter').value)&&($('source-filter').value==='all'||e.source===$('source-filter').value)).sort(order);}
function renderTimeline(){
  const events=filtered(),list=el('event-list');visibleEvents=events;list.replaceChildren();el('event-count').textContent=`${events.length} events`;
  for(const e of events){
    const row=document.createElement('button');row.className='event-entry';row.dataset.eventId=e.id;row.dataset.role='event';row.style.setProperty('--event-color',colors[e.class]);
    const title=document.createElement('div');title.className='event-title';const dot=document.createElement('i');dot.className='event-dot';const text=document.createElement('span'),label=document.createElement('b'),sub=document.createElement('small');label.textContent=e.class;sub.textContent=sourceName(e.source);text.append(label,sub);title.append(dot,text);
    const bar=document.createElement('div');bar.className='event-bar';const span=document.createElement('div');span.className='event-span';span.style.left=e.start/60*100+'%';span.style.width=(e.end-e.start)/60*100+'%';const stamp=document.createElement('span');stamp.className='event-time';stamp.textContent=`${e.start.toFixed(2)}–${e.end.toFixed(2)}s`;bar.append(span,stamp);row.append(title,bar);row.title=`${e.id} · ${e.source} · ${e.start}–${e.end}s`;
    row.addEventListener('click',()=>{player.pause();$('follow-source').checked=false;const t=(e.start+e.end)/2;seek(t);setYaw(direction(e,t).azimuth);editId=e.id;$('edit-target').value=e.id;loadEditor();renderMarkers();refresh();});list.append(row);
  }
  if(!events.length){const p=document.createElement('p');p.className='empty-state';p.textContent=state.events.length?'No events match these filters.':'No events yet. Add a missed event below.';list.append(p);}
  const overview=el('overview');overview.replaceChildren();const sources=[...new Set(events.map(e=>e.source))];for(const s of sources){const track=document.createElement('div');track.className='overview-track';for(const e of events.filter(e=>e.source===s)){const seg=document.createElement('span');seg.className='overview-segment';seg.style.setProperty('--event-color',colors[e.class]);seg.style.left=e.start/60*100+'%';seg.style.width=(e.end-e.start)/60*100+'%';track.append(seg);}overview.append(track);}
  const head=document.createElement('div');head.className='overview-playhead';overview.append(head);
}
function loadEditor(){const e=state.events.find(e=>e.id===editId);$('event-delete').disabled=!e;$('event-split').disabled=!e;$('edit-apply').disabled=!e;
  if(e){$('edit-class').value=e.class;$('edit-start').value=e.start;$('edit-end').value=e.end;$('split-time').value=((e.start+e.end)/2).toFixed(3);el('edit-context').textContent=`${e.source} · ${e.trajectory.length} keyframe${e.trajectory.length===1?'':'s'} · drag its active marker to move a keyframe.`;}
  else{$('edit-start').value='';$('edit-end').value='';$('split-time').value='';el('edit-context').textContent='Select an event to edit its interval or drag its marker.';}
}
function renderMarkers(){el('markers').replaceChildren();for(const e of filtered()){
  const m=document.createElement('div');m.className='marker'+(e.id===editId?' selected':'');m.dataset.eventId=e.id;m.dataset.role='marker';m.style.setProperty('--event-color',colors[e.class]);m.style.display='none';m.setAttribute('aria-label',`${e.class}, ${e.source}`);const label=document.createElement('span');label.className='marker-label';label.textContent=e.class;const s=document.createElement('small');s.textContent=sourceName(e.source);label.append(s);m.append(label);el('markers').append(m);
  m.addEventListener('pointerdown',ev=>{if(e.id!==editId)return;ev.preventDefault();ev.stopPropagation();$('follow-source').checked=false;updateFollowUI();const rect=m.getBoundingClientRect();drag={type:'marker',id:e.id,pointer:ev.pointerId,element:m,startX:ev.clientX,startY:ev.clientY,centerX:rect.left+rect.width/2,centerY:rect.top+rect.height/2,yaw,time:video.currentTime};m.setPointerCapture(ev.pointerId);});
  m.addEventListener('pointermove',ev=>{if(drag?.type!=='marker'||drag.pointer!==ev.pointerId)return;ev.stopPropagation();const r=viewport.getBoundingClientRect();m.style.left=drag.centerX+ev.clientX-drag.startX-r.left+'px';m.style.top=drag.centerY+ev.clientY-drag.startY-r.top+'px';});
  m.addEventListener('pointerup',ev=>{if(drag?.type!=='marker'||drag.pointer!==ev.pointerId)return;ev.stopPropagation();const d=drag;drag=null;const r=viewport.getBoundingClientRect(),x=d.centerX+ev.clientX-d.startX-r.left,y=d.centerY+ev.clientY-d.startY-r.top;
    attempt(()=>{const doc=copy(state),event=doc.events.find(e=>e.id===d.id),time=video.currentTime;let nearest=0;for(let i=1;i<event.trajectory.length;i++)if(Math.abs(event.trajectory[i].time-time)<Math.abs(event.trajectory[nearest].time-time)-1e-9)nearest=i;event.trajectory[nearest].azimuth=wrap(d.yaw+120*(.5-x/r.width));event.trajectory[nearest].elevation=Math.max(-90,Math.min(90,90*(.5-y/r.height)));commit(doc,'Direction corrected');});
  });m.addEventListener('pointercancel',()=>{drag=null;refresh();});
}}
function follow(){if(!$('follow-source').checked||$('source-filter').value==='all')return;const e=state.events.filter(e=>e.source===$('source-filter').value&&active(e,video.currentTime)).sort(order)[0];if(e)setYaw(direction(e,video.currentTime).azimuth,false);}
function updateFollowUI(){const all=$('source-filter').value==='all';$('follow-source').disabled=all;el('follow-status').textContent=all?'Select one to follow':$('follow-source').checked?'Following · holds during silence':'View stays in your hands';}
function setYaw(value,paint=true){yaw=wrap(value);$('yaw').value=yaw;el('yaw-value').textContent=`${Math.round(yaw)}°`;el('bearing').textContent=(yaw<0?'R ':'L ')+Math.abs(yaw).toFixed(0).padStart(3,'0')+'°';player.setYaw(yaw);if(paint){draw();updateMarkers();}}
function manualYaw(value){$('follow-source').checked=false;updateFollowUI();setYaw(value);}
function seek(time){player.seek(time);$('seek').value=time;refresh();}
function updateTransport(){const playing=!video.paused;el('play-label').textContent=playing?'Pause':'Play';el('play-symbol').textContent=playing?'Ⅱ':'▶';$('play').setAttribute('aria-label',playing?'Pause recording':'Play recording');el('view-state').textContent=playing?'PLAYING':'PAUSED';}
function updateMarkers(){
  const t=video.currentTime;
  for(const m of el('markers').children){const e=eventMap.get(m.dataset.eventId);if(!e)continue;if(drag?.type==='marker'&&drag.id===e.id)continue;if(!active(e,t)){m.style.display='none';continue;}const pos=direction(e,t),d=wrap(pos.azimuth-yaw),visible=Math.abs(d)<60&&Math.abs(pos.elevation)<45;m.style.display=visible?'block':'none';if(visible){m.style.left=(.5-d/120)*100+'%';m.style.top=(.5-pos.elevation/90)*100+'%';}}
}
let nowSignature='';
function refresh(){if(!state)return;follow();const t=video.currentTime;$('seek').value=t;el('time-current').textContent=timeText(t);updateTransport();updateMarkers();for(const row of el('event-list').children)if(row.dataset.eventId){const e=eventMap.get(row.dataset.eventId);row.classList.toggle('is-active',active(e,t));}
  const head=el('overview').querySelector('.overview-playhead');if(head)head.style.left=t/60*100+'%';const audible=visibleEvents.filter(e=>active(e,t));el('now-count').textContent=audible.length+' ACTIVE';const sig=audible.map(e=>e.id+e.class+e.source).join('|');if(sig!==nowSignature){nowSignature=sig;el('now-events').replaceChildren();for(const e of audible){const chip=document.createElement('span');chip.className='now-chip';chip.style.setProperty('--event-color',colors[e.class]);const dot=document.createElement('i'),name=document.createTextNode(e.class),source=document.createElement('span');source.textContent=sourceName(e.source);chip.append(dot,name,source);el('now-events').append(chip);}if(!audible.length)el('now-events').textContent='No matching annotated activity.';}draw();}
function draw(){if(video.readyState<2)return;el('video-loading').style.display='none';const r=viewport.getBoundingClientRect(),scale=Math.min(devicePixelRatio||1,2),w=Math.round(r.width*scale),h=Math.round(r.height*scale);if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}const vw=video.videoWidth,vh=video.videoHeight,cropW=vw/3,cropH=vh/2,center=(180-yaw)/360*vw,left=((center-cropW/2)%vw+vw)%vw,top=vh/4,first=Math.min(cropW,vw-left);ctx.drawImage(video,left,top,first,cropH,0,0,w*first/cropW,h);if(first<cropW)ctx.drawImage(video,0,top,cropW-first,cropH,w*first/cropW,0,w*(cropW-first)/cropW,h);}
function loopBounds(){const start=Number($('loop-start').value),end=Number($('loop-end').value);return $('loop-start').value!==''&&$('loop-end').value!==''&&Number.isFinite(start)&&Number.isFinite(end)&&start>=0&&end<=60&&start<end?{start,end}:null;}
function tick(){if(state){if($('loop').checked&&!video.paused&&!looping){const b=loopBounds();if(b&&(video.currentTime>=b.end||video.currentTime<b.start-.02)){looping=true;seek(b.start);}}
  player.sync();refresh();}frameId=requestAnimationFrame(tick);}
function renderReviews(){const root=el('reviews');root.replaceChildren();for(const [index,r] of reviews.entries()){
  const stale=!r.unresolved&&!state.events.some(e=>r.event_ids?.includes(e.id)&&e.start<r.end&&e.end>r.start);
  const b=document.createElement('button');b.className='review-card'+(r.unresolved?' unresolved':'');b.dataset.role='review';b.dataset.reviewId=r.id;b.dataset.stale=String(stale);b.title=r.note||r.reason||'';
  const top=document.createElement('span');top.className='review-top';const id=document.createElement('span');id.textContent=r.id.toUpperCase();const tag=document.createElement('span');tag.textContent=r.unresolved?'UNRESOLVED':stale?'NEEDS REVIEW':'↗ REVIEW';top.append(id,tag);const title=document.createElement('span');title.textContent=titles[Number(r.id.slice(1))-1]||`Evidence ${index+1}`;const meta=document.createElement('small');meta.textContent=r.unresolved?(r.reason||r.note||'Evidence insufficient'):timeText(r.start)+' – '+timeText(r.end);b.append(top,title,meta);
  b.addEventListener('click',()=>{el('review-message').textContent=`${r.id.toUpperCase()} · ${r.note||r.reason||''}${stale?' Referenced events no longer overlap this window.':''}`;if(r.unresolved)return;player.pause();$('follow-source').checked=false;const t=(r.start+r.end)/2,source=r.source_ids?.[0];$('source-filter').value=[...$('source-filter').options].some(o=>o.value===source)?source:'all';$('filter').value='all';updateFollowUI();renderTimeline();renderMarkers();seek(t);
    const candidates=state.events.filter(e=>r.event_ids?.includes(e.id)&&e.source===source),on=candidates.filter(e=>active(e,t)).sort(order);const nearest=[...candidates].sort((a,b)=>Math.max(a.start-t,t-a.end,0)-Math.max(b.start-t,t-b.end,0)||order(a,b));const e=on[0]||nearest[0];if(e)setYaw(direction(e,t).azimuth);refresh();});root.append(b);
}}
// All annotation mutations pass through the same validator and snapshot commit.
for(const testid of ['edit-class','new-class'])$(testid).replaceChildren(...CLASSES.map(c=>option(c,c[0].toUpperCase()+c.slice(1))));
$('edit-target').addEventListener('change',()=>{editId=$('edit-target').value;loadEditor();renderMarkers();refresh();});
$('edit-apply').addEventListener('click',()=>attempt(()=>{const doc=copy(state),e=doc.events.find(e=>e.id===editId);if(!e)throw Error('Select an event to edit.');e.class=$('edit-class').value;e.start=numberField($('edit-start'));e.end=numberField($('edit-end'));commit(doc,'Event updated');}));
$('event-create').addEventListener('click',()=>attempt(()=>{const start=numberField($('new-start')),e={id:$('new-id').value,source:$('new-source').value,class:$('new-class').value,start,end:numberField($('new-end')),trajectory:[{time:start,azimuth:numberField($('new-azimuth')),elevation:numberField($('new-elevation'))}]};const doc=copy(state);doc.events.push(e);commit(doc,'Event created');}));
$('event-delete').addEventListener('click',()=>attempt(()=>{if(editId==='none')throw Error('Select an event to delete.');const doc=copy(state);doc.events=doc.events.filter(e=>e.id!==editId);commit(doc,'Event deleted');}));
$('event-split').addEventListener('click',()=>attempt(()=>commit(splitEvent(state,editId,numberField($('split-time'))),'Event split')));
$('undo').addEventListener('click',()=>{if(!undo.length)return;redo.push(copy(state));state=undo.pop();error('');rebuild();store();});
$('redo').addEventListener('click',()=>{if(!redo.length)return;undo.push(copy(state));state=redo.pop();error('');rebuild();store();});
$('export').addEventListener('click',()=>{$('export-output').value=JSON.stringify(state,null,2);el('save-status').textContent='Complete annotation exported below. Copy the JSON to keep it.';});
$('import-apply').addEventListener('click',()=>attempt(()=>{let doc;try{doc=JSON.parse($('import-input').value);}catch{throw Error('Import is not valid JSON.');}commit(doc,'Annotation imported');}));
$('reset').addEventListener('click',()=>attempt(()=>commit(original,'Original annotation restored')));
$('filter').addEventListener('change',()=>{renderTimeline();renderMarkers();refresh();});
$('source-filter').addEventListener('change',()=>{if($('source-filter').value==='all')$('follow-source').checked=false;updateFollowUI();renderTimeline();renderMarkers();refresh();});
$('follow-source').addEventListener('change',()=>{if($('source-filter').value==='all')$('follow-source').checked=false;updateFollowUI();refresh();});
$('play').addEventListener('click',()=>{if(!video.paused||player.wanted)player.pause();else{const b=loopBounds();if($('loop').checked&&b&&(video.currentTime<b.start||video.currentTime>=b.end))seek(b.start);player.play();}});
for(const name of ['input','change']){
  $('seek').addEventListener(name,()=>seek(Number($('seek').value)));
  $('yaw').addEventListener(name,()=>manualYaw(Number($('yaw').value)));
  $('volume').addEventListener(name,()=>{const v=Number($('volume').value);player.setVolume(v);el('volume-value').textContent=Math.round(v*100)+'%';});
}
el('center-view').addEventListener('click',()=>manualYaw(0));
for(const name of ['loop-start','loop-end','loop'])$(name).addEventListener('change',()=>{const valid=loopBounds();el('loop-note').textContent=valid?'seconds':'Enter 0 ≤ from < to ≤ 60';});
el('overview').addEventListener('click',ev=>{const r=el('overview').getBoundingClientRect();seek(Math.max(0,Math.min(60,(ev.clientX-r.left)/r.width*60)));});
viewport.addEventListener('pointerdown',ev=>{if(ev.button!==0)return;ev.preventDefault();$('follow-source').checked=false;updateFollowUI();drag={type:'view',pointer:ev.pointerId,startX:ev.clientX,yaw};viewport.setPointerCapture(ev.pointerId);});
viewport.addEventListener('pointermove',ev=>{if(drag?.type==='view'&&drag.pointer===ev.pointerId)setYaw(drag.yaw+(ev.clientX-drag.startX)/viewport.getBoundingClientRect().width*120);});
viewport.addEventListener('pointerup',()=>{if(drag?.type==='view')drag=null;});viewport.addEventListener('pointercancel',()=>{drag=null;});
viewport.addEventListener('keydown',ev=>{if(ev.key==='ArrowLeft'||ev.key==='ArrowRight'){ev.preventDefault();manualYaw(yaw+(ev.key==='ArrowLeft'?5:-5));}});
for(const event of ['loadeddata','seeked','timeupdate','play','pause','ended'])video.addEventListener(event,()=>{if(event==='seeked')looping=false;if(event==='ended'&&$('loop').checked&&loopBounds()){seek(loopBounds().start);player.play();}refresh();});
video.addEventListener('error',()=>{el('video-loading').textContent='The video could not load. Refresh to try again.';});
new ResizeObserver(draw).observe(viewport);
document.addEventListener('keydown',ev=>{if(ev.code==='Space'&&!/INPUT|TEXTAREA|SELECT|BUTTON/.test(document.activeElement.tagName)){ev.preventDefault();$('play').click();}});
async function init(){try{const [doc,reviewDoc]=await Promise.all([fetch('events.json').then(r=>r.json()),fetch('reviews.json').then(r=>r.json())]);original=validate(doc);state=copy(original);reviews=reviewDoc.reviews||[];try{const saved=localStorage.getItem(storageKey);if(saved!==null){state=validate(JSON.parse(saved));el('save-status').textContent='Restored your saved annotation · '+state.events.length+' events';}}catch{el('save-status').textContent='Saved annotation could not be restored. Original annotation loaded.';}rebuild();setYaw(0);tick();}catch(e){error('Could not load the annotation: '+e.message);}}
init();
