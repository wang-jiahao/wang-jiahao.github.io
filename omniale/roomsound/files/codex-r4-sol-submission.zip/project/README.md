# RoomSound

Local spatial-audio scene explorer. Open through the supplied server so `/media/` resolves to the original assets:

```powershell
$env:NODE_PATH = 'C:/Users/wjjhh/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'
$env:OMNIALE_CHROMIUM = 'C:/Program Files/Google/Chrome/Application/chrome.exe'
& 'C:/Users/wjjhh/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe' toolkit/serve.mjs
```

Run that from the workspace root, then open the printed loopback URL. No build step, install, CDN, or network connection is needed by the app. The runtime JavaScript files are ES modules.

`index.html`, `styles.css`, `app.js`, `model.js`, and `player.js` implement the app. `events.json` is the initial editable annotation; `reviews.json` holds all ten evidence bookmarks. Read `evidence.md` for the observation/inference distinction and unresolved questions. Annotation edits persist in local storage; export copies the complete document to the visible export field, and Reset recovers the submitted original.

Reproduce real-browser checks from the workspace root using the same environment variables above:

```powershell
& 'C:/Users/wjjhh/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe' project/qa/browser-test.mjs
```

The browser test launches local Chrome and serves the project itself. It writes results/screenshots only inside `project/qa/`. Analysis scripts and sampled-media artifacts are under `project/analysis/`; no analysis model is required by the app.

`project/qa/repair-edge-test.mjs` and `project/qa/follow-playback-test.mjs` run with the same Node command/environment. They extend the checks to deleting the last event, strict invalid-input rejection, the 600-event limit, and Follow/decoder synchronization during moving playback. The three suites passed 29 named checks; see `qa/verification.json` for combined results. Timing checks measure alignment after the browser completes a seek, not seek latency.
