export class SpatialPlayer{
  constructor(video,onStatus){this.video=video;this.onStatus=onStatus;this.yaw=0;this.volume=.8;this.generation=0;this.wanted=false;this.loading=null;
    video.muted=true;
    video.addEventListener('seeking',()=>this.stopAudio());
    video.addEventListener('seeked',()=>{if(!video.paused&&this.wanted)this.startAudio();});
    video.addEventListener('playing',()=>{if(this.wanted)this.startAudio();});
    video.addEventListener('waiting',()=>this.stopAudio());
    video.addEventListener('pause',()=>this.stopAudio());
    video.addEventListener('ended',()=>{this.wanted=false;this.stopAudio();});
  }
  async prepare(){
    if(!this.context){
      this.context=new AudioContext();const c=this.context;
      this.splitter=c.createChannelSplitter(4);this.merger=c.createChannelMerger(2);this.master=c.createGain();this.master.gain.value=this.volume;
      // W,Y,Z,X; Z intentionally has no connection in this horizontal decoder.
      this.decodeGains=[];
      for(const [channel,output] of [[0,0],[3,0],[1,0],[0,1],[3,1],[1,1]]){const g=c.createGain();this.splitter.connect(g,channel);g.connect(this.merger,0,output);this.decodeGains.push(g);}
      this.merger.connect(this.master);this.master.connect(c.destination);this.setYaw(this.yaw);
    }
    await this.context.resume();
    if(!this.loading)this.loading=fetch('/media/scene-foa.wav').then(r=>{if(!r.ok)throw Error('Audio file unavailable');return r.arrayBuffer();}).then(b=>this.context.decodeAudioData(b)).then(b=>{if(b.numberOfChannels!==4)throw Error('This preview needs the original four audio channels.');this.buffer=b;}).catch(e=>{this.loading=null;throw e;});
    await this.loading;
  }
  setYaw(degrees){this.yaw=degrees;if(!this.context)return;const a=degrees*Math.PI/180,values=[.5,-.5*Math.sin(a),.5*Math.cos(a),.5,.5*Math.sin(a),-.5*Math.cos(a)];this.decodeGains.forEach((g,i)=>g.gain.setValueAtTime(values[i],this.context.currentTime));}
  setVolume(value){this.volume=value;if(this.master)this.master.gain.setValueAtTime(value,this.context.currentTime);}
  stopAudio(){if(this.node){try{this.node.stop();}catch{}this.node.disconnect();this.node=null;}}
  startAudio(){this.stopAudio();if(!this.buffer||this.video.paused||this.video.seeking||!this.wanted||this.video.currentTime>=60)return;const c=this.context,node=c.createBufferSource();node.buffer=this.buffer;node.connect(this.splitter);this.offset=this.video.currentTime;this.started=c.currentTime;node.start(0,Math.min(this.offset,this.buffer.duration));this.node=node;}
  sync(){if(this.node&&Math.abs(this.offset+this.context.currentTime-this.started-this.video.currentTime)>.09)this.startAudio();}
  async play(){const ticket=++this.generation;this.wanted=true;this.onStatus('Preparing spatial audio…');try{await this.prepare();if(ticket!==this.generation||!this.wanted)return;if(this.video.currentTime>=59.99)this.video.currentTime=0;await this.video.play();if(ticket!==this.generation){this.video.pause();return;}this.startAudio();this.onStatus('Spatial stereo · full mix');}catch(e){this.wanted=false;this.video.pause();this.onStatus('Playback unavailable: '+e.message);}}
  pause(){this.generation++;this.wanted=false;this.video.pause();this.stopAudio();this.onStatus('Paused · full mix');}
  seek(time){this.stopAudio();this.video.currentTime=Math.max(0,Math.min(60,time));}
}
