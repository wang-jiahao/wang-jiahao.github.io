Original R4 frontend deliverables. Use immutable media from ../media/ with the supplied local server. Analysis intermediates remain in the full local run. Candidate source bytes unchanged.
