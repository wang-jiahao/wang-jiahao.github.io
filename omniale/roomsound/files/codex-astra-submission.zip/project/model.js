export const CLASSES = ['speech','clapping','telephone','laughter','domestic','footsteps','door','music','instrument','water','bell','knock'];
export const COLORS = {speech:'#548a75',clapping:'#c7864b',telephone:'#af7786',laughter:'#bf9851',domestic:'#859484',footsteps:'#879cba',door:'#9e7964',music:'#7e88af',instrument:'#9e80a5',water:'#63a1b5',bell:'#b3914f',knock:'#a18576'};
export const wrap = a => ((a + 180) % 360 + 360) % 360 - 180;
export const active = (e,t) => e.start <= t && t < e.end;
export function direction(e,t) {
  const keys = [...e.trajectory].sort((a,b)=>a.time-b.time);
  if(t<=keys[0].time) return {...keys[0]};
  for(let i=1;i<keys.length;i++) {
    if(t<=keys[i].time) {
      const a=keys[i-1],b=keys[i],r=(t-a.time)/(b.time-a.time||1);
      return {azimuth:wrap(a.azimuth+wrap(b.azimuth-a.azimuth)*r),elevation:a.elevation+(b.elevation-a.elevation)*r};
    }
  }
  return {...keys.at(-1)};
}
export function validate(doc) {
  if(!doc || typeof doc!=='object' || Array.isArray(doc) || doc.version!==1 || !Array.isArray(doc.events)) throw Error('Use an object with version: 1 and an events array.');
  if(doc.events.length>600) throw Error('A document may contain at most 600 events.');
  const ids=new Set();
  const finite=v=>typeof v==='number' && Number.isFinite(v);
  for(const [i,e] of doc.events.entries()) {
    const name=`Event ${i+1}`;
    if(!e || typeof e!=='object' || Array.isArray(e)) throw Error(`${name} must be an object.`);
    if(typeof e.id!=='string' || ids.has(e.id)) throw Error(`${name} needs a unique string id.`);
    ids.add(e.id);
    if(typeof e.source!=='string') throw Error(`${name} needs a string source.`);
    if(!CLASSES.includes(e.class)) throw Error(`${name} has an unsupported class.`);
    if(!finite(e.start)||!finite(e.end)||e.start<0||e.end>60||e.end<=e.start) throw Error(`${name}: use finite times with 0 ≤ start < end ≤ 60.`);
    if(!Array.isArray(e.trajectory)||!e.trajectory.length) throw Error(`${name} needs at least one trajectory keyframe.`);
    for(const k of e.trajectory) if(!k||!finite(k.time)||!finite(k.azimuth)||!finite(k.elevation)||Math.abs(k.azimuth)>180||Math.abs(k.elevation)>90) throw Error(`${name}: each keyframe needs finite time, azimuth within ±180°, and elevation within ±90°.`);
  }
  return doc;
}
export function reviewStale(review,events) {
  return !review.unresolved && !events.some(e=>review.event_ids.includes(e.id)&&e.start<review.end&&e.end>review.start);
}
export function followTarget(events,source,t) {
  return events.filter(e=>e.source===source&&active(e,t)).sort((a,b)=>a.start-b.start||(a.id<b.id?-1:a.id>b.id?1:0))[0];
}
export function reviewTarget(review,events,t) {
  const refs=events.filter(e=>e.source===review.source_ids[0]&&review.event_ids.includes(e.id));
  const present=followTarget(refs,review.source_ids[0],t);
  if(present)return present;
  const distance=e=>t<e.start?e.start-t:t>=e.end?t-e.end:0;
  return refs.sort((a,b)=>distance(a)-distance(b)||a.start-b.start||(a.id<b.id?-1:1))[0];
}
