import {CLASSES,COLORS,wrap,active,direction,validate,reviewStale,followTarget,reviewTarget} from './model.js';
import {SpatialAudio} from './audio.js';
const $=s=>document.querySelector(s), hook=s=>$(`[data-testid="${s}"]`), el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
const ui=Object.fromEntries(['scene-video','viewport','play','seek','yaw','volume','loop-start','loop-end','loop','filter','source-filter','follow-source','edit-target','edit-class','edit-start','edit-end','edit-apply','edit-error','undo','redo','export','export-output','import-input','import-apply','reset'].map(k=>[k,hook(k)]));
const video=ui['scene-video'],canvas=$('#panorama'),ctx=canvas.getContext('2d',{alpha:false}),audio=new SpatialAudio();
const sourceNames={'table-near':'Near table','table-far':'Far table','room':'Room background','doorway':'Doorway'};
const sourceName=s=>sourceNames[s]||s;
const title=s=>s.charAt(0).toUpperCase()+s.slice(1);
const stamp=t=>`${String(Math.floor(t/60)).padStart(2,'0')}:${(t%60).toFixed(1).padStart(4,'0')}`;
const seconds=t=>Number(t.toFixed(2)).toString();
const eventLabel=e=>`${title(e.class)} · ${sourceName(e.source)} · ${seconds(e.start)}–${seconds(e.end)}s`;
let events=[],original=[],reviews=[],undo=[],redo=[],storageKey='',yaw=0,requestedPlay=false,playToken=0,ready=false,drag=null,lastDrawTime=-1,lastDrawYaw=null,lastActiveKey='',toastTimer;
const markers=new Map(),bars=new Map();
const snapshot=()=>JSON.stringify({version:1,events});
const clone=x=>JSON.parse(JSON.stringify(x));
function toast(message){$('#toast').textContent=message;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),2800);}
function error(message){ui['edit-error'].textContent=message;}
function filtered(e){return(ui.filter.value==='all'||ui.filter.value===e.class)&&(ui['source-filter'].value==='all'||ui['source-filter'].value===e.source);}
function setYaw(value,manual=false){if(manual)ui['follow-source'].checked=false;yaw=wrap(value);ui.yaw.value=String(yaw);$('#yaw-value').textContent=`${Math.round(yaw)}°`;$('#view-heading').textContent=`${yaw>=0?'+':''}${Math.round(yaw)}°`;audio.setYaw(yaw);}
function updateFollow(t){if(!drag&&ui['follow-source'].checked&&ui['source-filter'].value!=='all'){const e=followTarget(events,ui['source-filter'].value,t);if(e)setYaw(direction(e,t).azimuth);}}
function populate(select,values,first,label=v=>v){const old=select.value;select.replaceChildren(new Option(first[1],first[0]),...values.map(v=>new Option(label(v),v)));select.value=values.includes(old)?old:first[0];}
function loadEditFields(){const e=events.find(e=>e.id===ui['edit-target'].value);if(e){ui['edit-class'].value=e.class;ui['edit-start'].value=e.start;ui['edit-end'].value=e.end;}else{ui['edit-class'].value=CLASSES[0];ui['edit-start'].value='';ui['edit-end'].value='';}$('#edit-guidance').textContent=e?`${e.trajectory.length} direction keyframe${e.trajectory.length===1?'':'s'}. Drag this event’s marker to move the keyframe nearest the playhead. Dragging pauses playback.`:'Select an event to edit its interval, or drag its marker to correct the nearest direction keyframe.';}
function persist(){try{localStorage.setItem(storageKey,snapshot());$('#saved-status').textContent='Saved locally';}catch{$('#saved-status').textContent='Not saved';toast('Browser storage is unavailable. Export to keep your edits.');}}
function commit(next,message){validate({version:1,events:next});undo.push(snapshot());redo=[];events=clone(next);error('');rebuild();persist();if(message)toast(message);}
function restoreFromStack(from,to){if(!from.length)return;to.push(snapshot());events=JSON.parse(from.pop()).events;error('');rebuild();persist();}
function rebuild(){
  populate(ui.filter,CLASSES.filter(c=>events.some(e=>e.class===c)),['all','All sounds'],title);
  populate(ui['source-filter'],[...new Set(events.map(e=>e.source))],['all','All performers'],sourceName);
  if(ui['source-filter'].value==='all')ui['follow-source'].checked=false;
  populate(ui['edit-target'],events.map(e=>e.id),['none','Choose an event…'],id=>eventLabel(events.find(e=>e.id===id)));
  loadEditFields();ui.undo.disabled=!undo.length;ui.redo.disabled=!redo.length;
  buildTimeline();buildMarkers();buildReviews();lastActiveKey='';render();
}
function buildTimeline(){
  const visible=events.filter(filtered),groups=new Map();
  for(const e of visible){const key=JSON.stringify([e.source,e.class]);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(e);}
  const rows=$('#timeline-rows');rows.replaceChildren();bars.clear();
  for(const group of groups.values()){
    // Extra lanes keep even same-source, same-class overlaps individually clickable.
    const lanes=[];
    for(const e of [...group].sort((a,b)=>a.start-b.start||a.end-b.end)){
      let lane=lanes.find(a=>a.at(-1).end<=e.start);if(!lane){lane=[];lanes.push(lane);}lane.push(e);
    }
    for(const laneEvents of lanes){
      const first=laneEvents[0],row=el('div','timeline-row'),label=el('div','lane-label'),dot=el('i');dot.style.setProperty('--event-color',COLORS[first.class]);label.append(dot,el('span','',sourceName(first.source)),el('small','',title(first.class)));row.append(label);
      const lane=el('div','lane');
      for(const e of laneEvents){const bar=el('button','event-bar');bar.dataset.eventId=e.id;bar.dataset.role='event';bar.title=eventLabel(e);bar.setAttribute('aria-label',eventLabel(e));bar.style.left=`${e.start/60*100}%`;bar.style.width=`${(e.end-e.start)/60*100}%`;bar.style.setProperty('--event-color',COLORS[e.class]);if(e.end-e.start>4)bar.append(el('span','',title(e.class)));bar.onclick=()=>navigateEvent(e);lane.append(bar);bars.set(e.id,bar);}
      lane.append(el('div','lane-playhead'));row.append(lane);rows.append(row);
    }
  }
  $('#event-count').textContent=`${visible.length} / ${events.length} events`;$('#timeline-empty').hidden=visible.length>0;
  $('#legend').replaceChildren(...CLASSES.filter(c=>visible.some(e=>e.class===c)).map(c=>{const n=el('span'),i=el('i');i.style.setProperty('--event-color',COLORS[c]);n.append(i,document.createTextNode(c));return n;}));
}
function buildMarkers(){const box=$('#markers');box.replaceChildren();markers.clear();for(const e of events){const m=el('div','marker'),label=el('span','marker-label',title(e.class));m.dataset.eventId=e.id;m.dataset.role='marker';m.style.setProperty('--event-color',COLORS[e.class]);label.append(el('small','',sourceName(e.source)));m.append(label);m.hidden=true;m.title=eventLabel(e);m.addEventListener('pointerdown',ev=>beginMarkerDrag(ev,e,m));box.append(m);markers.set(e.id,m);}}
const questions=['Two performers laughing','Two performers clapping','Laughing while clapping','Longest continuous speech','Five simultaneous sounds','Bell with laughter','Bell with two speakers','Two performers speaking','The continuous background','Speech after the final clap'];
function buildReviews(){const box=$('#reviews');box.replaceChildren();for(const r of reviews){const b=el('button',`review-button${r.unresolved?' unresolved':''}`);b.dataset.role='review';b.dataset.reviewId=r.id;b.dataset.stale=String(reviewStale(r,events));const top=el('div','review-top');top.append(el('span','',r.id.toUpperCase()),el('b','',r.unresolved?'UNRESOLVED':b.dataset.stale==='true'?'NEEDS REVIEW':`${seconds(r.start)}–${seconds(r.end)}s ↗`));b.append(top,el('span','review-title',questions[Number(r.id.slice(1))-1]||r.id),el('span','review-note',r.unresolved?r.reason||r.note:r.note));b.onclick=()=>navigateReview(r);box.append(b);}}
function navigateEvent(e){pause();ui['follow-source'].checked=false;const t=(e.start+e.end)/2;ui['edit-target'].value=e.id;loadEditFields();seek(t);setYaw(direction(e,t).azimuth);render();}
function navigateReview(r){
  if(r.unresolved){$('#review-status').textContent=`${r.id.toUpperCase()}: ${r.reason||r.note}`;toast('Unresolved: no inferred answer to navigate to.');return;}
  pause();ui['follow-source'].checked=false;const t=(r.start+r.end)/2,source=r.source_ids[0],target=reviewTarget(r,events,t);
  if([...ui['source-filter'].options].some(o=>o.value===source))ui['source-filter'].value=source;else ui['source-filter'].value='all';
  // A review can reference several classes; show all of them for its first performer.
  ui.filter.value='all';if(target){ui['edit-target'].value=target.id;loadEditFields();}
  seek(t);if(target)setYaw(direction(target,t).azimuth);buildTimeline();lastActiveKey='';render();$('#review-status').textContent=`${r.id.toUpperCase()}: ${r.note}${reviewStale(r,events)?' Its referenced events no longer overlap this window.':''}`;
}
function drawPanorama(){
  if(video.readyState<2||!video.videoWidth)return;
  if(lastDrawTime===video.currentTime&&lastDrawYaw===yaw)return;
  const w=video.videoWidth,h=video.videoHeight,sw=w/3,sh=h/2,start=((180-yaw)/360*w-sw/2+w)%w,first=Math.min(sw,w-start);
  ctx.drawImage(video,start,h/4,first,sh,0,0,canvas.width*first/sw,canvas.height);
  if(first<sw)ctx.drawImage(video,0,h/4,sw-first,sh,canvas.width*first/sw,0,canvas.width*(sw-first)/sw,canvas.height);
  lastDrawTime=video.currentTime;lastDrawYaw=yaw;$('#scene-loading').hidden=true;
}
function render(){
  const t=video.currentTime||0;updateFollow(t);drawPanorama();ui.seek.value=String(t);$('#current-time').textContent=stamp(t);
  const current=events.filter(e=>active(e,t)&&filtered(e));
  for(const e of events){const m=markers.get(e.id);if(!m)continue;const p=direction(e,t),d=wrap(p.azimuth-yaw);const visible=active(e,t)&&filtered(e)&&Math.abs(d)<60&&Math.abs(p.elevation)<45;m.hidden=!visible;m.classList.toggle('editable',ui['edit-target'].value===e.id);if(visible&&drag?.id!==e.id){m.style.left=`${(0.5-d/120)*100}%`;m.style.top=`${(0.5-p.elevation/90)*100}%`;}}
  for(const [id,b] of bars){const e=events.find(e=>e.id===id);b.classList.toggle('current',active(e,t));b.classList.toggle('selected',id===ui['edit-target'].value);}
  document.querySelectorAll('.lane-playhead').forEach(n=>n.style.left=`${t/60*100}%`);
  const key=current.map(e=>e.id).join('\u0000');
  if(key!==lastActiveKey||$('#active-events').childElementCount===0){lastActiveKey=key;const area=$('#active-events');area.replaceChildren();for(const e of current){const row=el('div','active-item');row.style.setProperty('--event-color',COLORS[e.class]);const info=el('div');info.append(el('b','',title(e.class)),el('p','',`${sourceName(e.source)} · ${seconds(e.start)}–${seconds(e.end)}s`));const dir=el('span','direction');dir.dataset.directionId=e.id;row.append(el('span','sound-icon',e.class==='music'?'♫':e.class==='speech'?'≋':e.class==='clapping'?'✳':e.class==='bell'?'♧':'◉'),info,dir);area.append(row);}if(!current.length)area.append(el('p','empty-live','No matching annotation at this moment. The full recording is still available.'));}
  $('#active-count').textContent=current.length;
  document.querySelectorAll('[data-direction-id]').forEach(n=>{const e=events.find(e=>e.id===n.dataset.directionId),p=direction(e,t);n.textContent=`${Math.round(p.azimuth)}°`;});
}
function resize(){const r=ui.viewport.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);lastDrawTime=-1;drawPanorama();}
function transportState(){const playing=requestedPlay;$('#play-label').textContent=playing?'Pause':'Play';$('#play-icon').textContent=playing?'Ⅱ':'▶';ui.play.setAttribute('aria-label',playing?'Pause recording':'Play recording');ui.play.setAttribute('aria-pressed',String(playing));}
function pause(){playToken++;requestedPlay=false;video.pause();audio.stop();transportState();$('#audio-status').textContent=audio.buffer?'Paused · FOA stereo ready':'Press Play to enable sound.';}
async function play(){
  const token=++playToken;requestedPlay=true;transportState();$('#audio-status').textContent='Preparing four-channel audio…';
  try{await audio.initialize();if(token!==playToken||!requestedPlay)return;audio.setYaw(yaw);audio.setVolume(Number(ui.volume.value));if(video.currentTime>=59.99)seek(validLoop()?Number(ui['loop-start'].value):0);if(validLoop()&&(video.currentTime<Number(ui['loop-start'].value)||video.currentTime>=Number(ui['loop-end'].value)))seek(Number(ui['loop-start'].value));await video.play();if(token!==playToken){if(!requestedPlay)video.pause();return;}$('#audio-status').textContent='Playing · FOA stereo follows your view';}
  catch(e){pause();$('#audio-status').textContent=`Playback unavailable: ${e.message}`;}
}
function seek(time){audio.stop();video.currentTime=Math.max(0,Math.min(60,time));render();}
function validLoop(){const a=ui['loop-start'].value,b=ui['loop-end'].value;return ui.loop.checked&&a!==''&&b!==''&&Number.isFinite(+a)&&Number.isFinite(+b)&&+a>=0&&+b<=60&&+a<+b;}
function loopChange(){const valid=validLoop();$('#loop-message').textContent=ui.loop.checked&&!valid?'Use 0 ≤ In < Out ≤ 60':'seconds';if(valid&&requestedPlay&&(video.currentTime<+ui['loop-start'].value||video.currentTime>=+ui['loop-end'].value))seek(+ui['loop-start'].value);}
function tick(){
  if(requestedPlay&&!video.paused&&!video.seeking){
    if(validLoop()&&video.currentTime>=+ui['loop-end'].value){seek(+ui['loop-start'].value);}
    else if(video.readyState>=3&&audio.buffer){const p=audio.position();if(p===null||Math.abs(p-video.currentTime)>.08)audio.start(video.currentTime);}
  }
  render();requestAnimationFrame(tick);
}
function beginMarkerDrag(ev,e,m){
  if(ui['edit-target'].value!==e.id)return;ev.preventDefault();ev.stopPropagation();pause();ui['follow-source'].checked=false;
  const r=ui.viewport.getBoundingClientRect(),b=m.getBoundingClientRect();drag={type:'marker',id:e.id,pointer:ev.pointerId,startX:ev.clientX,startY:ev.clientY,x:b.x+b.width/2-r.x,y:b.y+b.height/2-r.y,width:r.width,height:r.height,yaw,time:video.currentTime};m.setPointerCapture(ev.pointerId);
}
ui.viewport.addEventListener('pointerdown',ev=>{if(ev.button!==0)return;ev.preventDefault();ui['follow-source'].checked=false;drag={type:'view',pointer:ev.pointerId,startX:ev.clientX,yaw,width:ui.viewport.getBoundingClientRect().width};ui.viewport.setPointerCapture(ev.pointerId);});
ui.viewport.addEventListener('pointermove',ev=>{if(!drag||drag.pointer!==ev.pointerId)return;const dx=ev.clientX-drag.startX;if(drag.type==='view'){setYaw(drag.yaw+dx/drag.width*120,true);render();}else{const m=markers.get(drag.id);m.style.left=`${(drag.x+dx)/drag.width*100}%`;m.style.top=`${(drag.y+ev.clientY-drag.startY)/drag.height*100}%`;}});
ui.viewport.addEventListener('pointerup',ev=>{if(!drag||drag.pointer!==ev.pointerId)return;const d=drag;drag=null;if(d.type==='marker'){const next=clone(events),e=next.find(e=>e.id===d.id);let best=0;for(let i=1;i<e.trajectory.length;i++){const a=e.trajectory[i],b=e.trajectory[best];if(Math.abs(a.time-d.time)<Math.abs(b.time-d.time)||(Math.abs(a.time-d.time)===Math.abs(b.time-d.time)&&a.time<b.time))best=i;}const x=d.x+ev.clientX-d.startX,y=d.y+ev.clientY-d.startY;e.trajectory[best].azimuth=wrap(d.yaw+120*(.5-x/d.width));e.trajectory[best].elevation=Math.max(-90,Math.min(90,90*(.5-y/d.height)));commit(next,'Direction keyframe corrected.');}render();});
ui.viewport.addEventListener('pointercancel',()=>{drag=null;render();});
ui.viewport.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();setYaw(yaw+(e.key==='ArrowLeft'?5:-5),true);render();}});
ui.play.onclick=()=>requestedPlay?pause():play();
for(const type of ['input','change']){
  ui.seek.addEventListener(type,()=>seek(Number(ui.seek.value)));
  ui.yaw.addEventListener(type,()=>{setYaw(Number(ui.yaw.value),true);render();});
  ui.volume.addEventListener(type,()=>{audio.setVolume(Number(ui.volume.value));$('#volume-value').textContent=`${Math.round(+ui.volume.value*100)}%`;});
  for(const k of ['loop','loop-start','loop-end'])ui[k].addEventListener(type,loopChange);
}
$('#home-view').onclick=()=>{setYaw(0,true);render();};
for(const k of ['filter','source-filter'])ui[k].onchange=()=>{if(ui['source-filter'].value==='all')ui['follow-source'].checked=false;buildTimeline();lastActiveKey='';render();};
ui['follow-source'].onchange=()=>{if(ui['source-filter'].value==='all'){ui['follow-source'].checked=false;toast('Choose one performer to follow.');}render();};
ui['edit-target'].onchange=()=>{loadEditFields();render();};
ui['edit-class'].replaceChildren(...CLASSES.map(c=>new Option(title(c),c)));
ui['edit-apply'].onclick=()=>{try{const id=ui['edit-target'].value,e=events.find(e=>e.id===id);if(!e)throw Error('Choose an event before applying a correction.');const a=ui['edit-start'].value,b=ui['edit-end'].value;if(a.trim()===''||b.trim()==='')throw Error('Start and end are required numbers.');const next=clone(events),target=next.find(e=>e.id===id);target.class=ui['edit-class'].value;target.start=Number(a);target.end=Number(b);commit(next,'Correction saved.');}catch(e){error(e.message);}};
ui.undo.onclick=()=>restoreFromStack(undo,redo);ui.redo.onclick=()=>restoreFromStack(redo,undo);
ui.export.onclick=()=>{ui['export-output'].value=JSON.stringify({version:1,events},null,2);toast('Complete annotation exported below.');};
ui['import-apply'].onclick=()=>{try{const doc=validate(JSON.parse(ui['import-input'].value));commit(doc.events,'Annotation imported as one change.');}catch(e){error(`Import rejected: ${e.message}`);}};
ui.reset.onclick=()=>commit(clone(original),'Original annotation restored.');
video.addEventListener('seeking',()=>{audio.stop();render();});
video.addEventListener('seeked',()=>{lastDrawTime=-1;render();if(requestedPlay&&!video.paused&&video.readyState>=3)audio.start(video.currentTime);});
video.addEventListener('playing',()=>{if(requestedPlay&&audio.buffer){audio.start(video.currentTime);$('#audio-status').textContent='Playing · FOA stereo follows your view';}});
video.addEventListener('waiting',()=>audio.stop());
video.addEventListener('pause',()=>audio.stop());
video.addEventListener('ended',()=>{audio.stop();if(requestedPlay&&validLoop()){seek(+ui['loop-start'].value);video.play().catch(()=>pause());}else pause();});
video.addEventListener('loadeddata',()=>{lastDrawTime=-1;render();});
video.addEventListener('error',()=>{$('#scene-loading').hidden=false;$('#scene-loading').textContent='The scene video could not be loaded.';});
new ResizeObserver(resize).observe(ui.viewport);
document.addEventListener('keydown',e=>{if(e.code==='Space'&&!['INPUT','SELECT','TEXTAREA','BUTTON'].includes(document.activeElement.tagName)){e.preventDefault();ui.play.click();}});
async function boot(){try{
  const [doc,reviewDoc]=await Promise.all(['events.json','reviews.json'].map(path=>fetch(path).then(r=>{if(!r.ok)throw Error(`Cannot load ${path}`);return r.json();})));
  original=clone(validate(doc).events);events=clone(original);reviews=reviewDoc.reviews;
  // Scope edits to this starting document, including when a reviewer loads another recording.
  let hash=2166136261;for(const c of JSON.stringify(original))hash=Math.imul(hash^c.charCodeAt(0),16777619)>>>0;storageKey=`roomsound.v1.${hash}`;
  try{const saved=localStorage.getItem(storageKey);if(saved){events=clone(validate(JSON.parse(saved)).events);$('#saved-status').textContent='Restored';}}catch{toast('Stored annotation could not be restored; showing the original.');}
  ready=true;rebuild();resize();setYaw(0);requestAnimationFrame(tick);
}catch(e){error(e.message);$('#audio-status').textContent=e.message;}}
boot();
