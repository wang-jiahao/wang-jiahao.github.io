# RoomSound

A dependency-free browser app for the supplied 60-second spatial recording. Open through the supplied local server, which mounts the immutable media at `/media/`.

## Run on this machine

From the workspace root in PowerShell:

```powershell
$env:NODE_PATH='C:/Users/wjjhh/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules'
$env:OMNIALE_CHROMIUM='C:/Program Files/Google/Chrome/Application/chrome.exe'
& 'C:/Users/wjjhh/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe' toolkit/serve.mjs
```

Open the loopback URL printed by the command. Press Play to enable audio. Drag the panorama or move Direction to rotate both the view and decoded stereo sound. Space toggles playback when a form control is not focused.

Choose a sound class and/or performer to filter annotations. Follow centers the selected performer's earliest active event, holding direction during silence. Selecting a timeline interval pauses, seeks, faces the event and loads it into the workbench. Review bookmarks navigate similarly; unresolved entries explain the evidence gap.

In the workbench, apply interval/class edits, or drag the selected event's marker to correct its nearest direction keyframe. Undo and redo operate on complete changes. Export prints the whole editable document; import validates and replaces it as one change. Changes persist for this starting document at the same browser origin. Reset restores the submitted state and is undoable. Starting the server at a new port creates a different browser origin; use export/import to move saved revisions between ports or browsers.

## Files

- `index.html`, `styles.css`, `app.js`: layout, panorama, interactions, and atomic revision state.
- `audio.js`: original four-channel PCM parsing and the specified FOA stereo decoder.
- `model.js`: ontology, validation, trajectories and review/follow selection rules.
- `events.json`, `reviews.json`: editable starting hypotheses and ten evidence bookmarks.
- `evidence.md`: media inspection, event ledger, provenance and uncertainties.
- `verification.md`, `qa/test-results.json`, `qa/page-*.png`: actual browser test results and inspected screenshots.
- `tests/browser-test.mjs`: functional and output-PCM checks in local Chrome.
- `tests/inspect.mjs`: desktop/mobile page capture.
- `analysis/`, `analyze.py`, `signal-analysis.py`, `analysis-summary.txt`: local media analysis artifacts. These are not official annotations.
- `build-data.py`: reproducible transcription of the manual starting inference.

## Test

With the same two environment variables set:

```powershell
& 'C:/Users/wjjhh/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe' project/tests/browser-test.mjs
```

The tests start and stop their own local servers and Chrome sessions. They use actual media first, then locally authored synthetic four-channel WAV samples and event documents to verify generic behavior. No remote dependency is used by the web app. Node 22+ is recommended for the supplied toolkit; the default machine `node` is older, so the commands above use the bundled runtime explicitly.
