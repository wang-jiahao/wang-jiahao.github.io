# Verification performed

The implementation was exercised in **real Google Chrome through Playwright**, with the supplied local server and media. Screenshots at 1280 × 900 and 390 × 844 viewport sizes were generated and opened with the image tool. No browser JavaScript errors occurred during these interactions.

The executable test suite completed **29 passing checks**. The timestamped machine-readable results and measurements are in `qa/test-results.json`. These are development checks, not an official evaluation score.

## Actual-media checks

- The initial page contains all 32 event entries and 10 review entries. The panorama's exact visible rectangle is 4:3. The video is muted; no AudioContext exists before Play.
- Turning while paused changes real canvas image pixels. Seeking to 48 seconds displays the corresponding supplied video frame. Active markers' centers match the specified projection and hide when inactive or outside the view.
- Class and performer filters combine for markers and timeline. Timeline selection pauses, seeks to the event midpoint, and faces the source.
- All ten review buttons were exercised. Resolved entries seek and face the first referenced performer; unresolved entries leave playback position unchanged and show their reason.
- The actual FOA WAV produces nonzero rendered left/right PCM. Play/pause/resume, yaw changes, playing seeks and repeated segment loops were exercised. Audio-source clock position was compared with the video clock after seeking and looping (asserted within 90 ms). Paused output becomes zero.
- Invalid field edits preserve the exported annotation byte-for-byte and do not add undo history. A successful class/start/end edit changes the timeline, filter options and review freshness together; a single undo/redo restores/reapplies all fields.
- Reload restores the current edits. Reset restores the submitted annotation as one undoable change. A new edit clears redo history.
- Imports reject invalid shape/version, nonnumeric times, duplicate IDs, unknown classes, missing/out-of-bounds trajectory data and more than 600 events without mutating state. Exports round-trip through import.
- Dragging a selected marker changes the correct trajectory coordinate using inverse projection, does not turn the panorama, and is undone in one step. Unselected markers remain inert, allowing view rotation through their positions.
- The 390px mobile page has no horizontal page overflow and retains the exact viewport aspect ratio. Its timeline scrolls within its own region.

## Synthetic browser checks

Synthetic fixtures were authored locally for this implementation; no hidden evaluator fixtures were accessed.

- A moving track crosses +180/−180 along the shortest arc. Markers interpolate and clamp correctly. Follow uses earliest start then event ID, ignores the class filter, updates on paused seeking and during playback, holds its last direction in silence, and disables on manual yaw or selecting all performers.
- A marker drag midway between two keyframe times selects the earlier keyframe and leaves the other unchanged.
- Review navigation handles both earliest active and nearest inactive referenced events. Freshness is true only if no reference overlaps, recomputes through undo, and remains false for unresolved entries.
- All twelve ontology classes were imported and exercised through class filters and visible markers.
- An instrumented AudioContext captured **rendered output PCM** using two analyser nodes connected at the actual master output. Independent W, Y, X, and Z PCM16 sections verified the prescribed formula at 0°, ±90° and 180°. Z output was zero. A combined four-channel section verified a live 45° → −45° rotation during playback. Master volume was checked at 0, 0.4 and 0.8. Output means and RMS were compared within 0.0001 of the expected values.

The browser launch disables physical audio-device output; the WebAudio graph still renders and the analyser measures its real PCM. No claim of human listening or loudspeaker/headphone calibration is made.

## Inspected artifacts

- `qa/page-1.png`: initial desktop page, including panorama, transport, workbench, timeline and reviews.
- `qa/page-2.png`: desktop at 48 seconds / +155°, showing both table performers and active clapping/laughter hypotheses.
- `qa/page-3.png`: the same moment in the responsive phone layout.
- `qa-inspection.jsonl`: observed page text, DOM/control state, media time and marker boxes for these captures.

## Limits

Tests establish application behavior, not annotation truth. Laughter, speaker overlap, quiet background audibility and bell directions remain uncertain as documented in `evidence.md`. q7 and q8 remain unresolved. Only Chrome was tested. Long-running background-tab playback and other browser engines were not evaluated. The simple horizontal stereo decoder is not an HRTF renderer.

The genuine CLI protocol was used. Historical constrained-harness turn/tool/frame limits do not apply to this run, so these checks are not an equal-budget benchmark replacement.
