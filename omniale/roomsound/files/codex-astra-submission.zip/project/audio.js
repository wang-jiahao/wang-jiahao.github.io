// Preserve W,Y,Z,X explicitly. Browser decodeAudioData may interpret four-channel
// WAVs as speaker layouts; parsing PCM avoids that ambiguity.
export function parseWav(array) {
  const v=new DataView(array),str=(p,n)=>String.fromCharCode(...new Uint8Array(array,p,n));
  if(str(0,4)!=='RIFF'||str(8,4)!=='WAVE')throw Error('The audio is not a RIFF WAV file.');
  let format,channels,rate,bits,block,dataOffset,dataLength;
  for(let p=12;p+8<=v.byteLength;) {
    const id=str(p,4),n=v.getUint32(p+4,true),q=p+8;
    if(q+n>v.byteLength)throw Error('Incomplete WAV data.');
    if(id==='fmt ') {
      format=v.getUint16(q,true);channels=v.getUint16(q+2,true);rate=v.getUint32(q+4,true);block=v.getUint16(q+12,true);bits=v.getUint16(q+14,true);
      if(format===65534&&n>=40)format=v.getUint16(q+24,true);
    } else if(id==='data') {dataOffset=q;dataLength=n;}
    p=q+n+(n%2);
  }
  if(channels!==4||!rate||!block||dataOffset===undefined||!(format===1&&[16,24,32].includes(bits)||format===3&&bits===32))throw Error('Expected four-channel PCM or float FOA audio.');
  const frames=Math.floor(dataLength/block),data=Array.from({length:4},()=>new Float32Array(frames));
  for(let i=0;i<frames;i++)for(let ch=0;ch<4;ch++) {
    const p=dataOffset+i*block+ch*bits/8;
    let x;
    if(format===3)x=v.getFloat32(p,true);
    else if(bits===16)x=v.getInt16(p,true)/32768;
    else if(bits===32)x=v.getInt32(p,true)/2147483648;
    else {x=v.getUint8(p)|(v.getUint8(p+1)<<8)|(v.getUint8(p+2)<<16);if(x&0x800000)x-=0x1000000;x/=8388608;}
    data[ch][i]=Number.isFinite(x)?x:0;
  }
  return {rate,frames,data};
}
export class SpatialAudio {
  constructor() {this.context=null;this.buffer=null;this.source=null;this.yaw=0;this.volume=.8;this.offset=0;this.startedAt=0;this.loading=null;}
  async initialize() {
    if(!this.context) {
      this.context=new AudioContext();
      this.master=this.context.createGain();this.master.gain.value=this.volume;
      this.merger=this.context.createChannelMerger(2);this.merger.channelInterpretation='discrete';this.merger.connect(this.master);this.master.connect(this.context.destination);
      this.splitter=this.context.createChannelSplitter(4);this.splitter.channelInterpretation='discrete';
      this.coefficients=[];
      for(const channel of [0,3,1]) for(let side=0;side<2;side++) {
        const gain=this.context.createGain();this.splitter.connect(gain,channel);gain.connect(this.merger,0,side);this.coefficients.push(gain);
      }
      this.setYaw(this.yaw);
    }
    // Called directly in the Play gesture, before awaiting network work.
    const resume=this.context.resume();
    if(!this.loading)this.loading=fetch('/media/scene-foa.wav').then(r=>{if(!r.ok)throw Error('Could not load FOA audio.');return r.arrayBuffer();}).then(array=>{
      const {rate,frames,data}=parseWav(array);this.buffer=this.context.createBuffer(4,frames,rate);data.forEach((samples,c)=>this.buffer.copyToChannel(samples,c));
    }).catch(e=>{this.loading=null;throw e;});
    await Promise.all([resume,this.loading]);
  }
  setYaw(degrees) {
    this.yaw=degrees;
    if(!this.coefficients)return;
    const a=degrees*Math.PI/180;
    const values=[.5,.5,-.5*Math.sin(a),.5*Math.sin(a),.5*Math.cos(a),-.5*Math.cos(a)];
    this.coefficients.forEach((node,i)=>node.gain.setValueAtTime(values[i],this.context.currentTime));
  }
  setVolume(value) {this.volume=value;if(this.master)this.master.gain.setValueAtTime(value,this.context.currentTime);}
  stop() {if(this.source){try{this.source.stop();}catch{}this.source.disconnect();this.source=null;}}
  start(time) {
    this.stop();if(!this.buffer||this.context.state!=='running'||time>=this.buffer.duration)return;
    const source=this.context.createBufferSource();source.buffer=this.buffer;source.channelInterpretation='discrete';source.connect(this.splitter);source.start(0,Math.max(0,time));
    this.source=source;this.offset=time;this.startedAt=this.context.currentTime;
  }
  position() {return this.source?this.offset+this.context.currentTime-this.startedAt:null;}
}
