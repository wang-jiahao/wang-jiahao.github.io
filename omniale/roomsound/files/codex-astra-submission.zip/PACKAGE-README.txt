Original frontend deliverables from r3-astra-codex-xhigh-01.
Media and analysis caches remain in the complete local run directory. Serve project/ with immutable /media/* from the same RoomSound R3 public inputs. Candidate files are unmodified.
