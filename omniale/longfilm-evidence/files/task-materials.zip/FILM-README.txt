正式输入为完整film.mp4，101:47.776、3413859075字节；SHA256见冻结清单。网页节选不是正式输入。原片来源https://archive.org/details/the-cosmonaut；主英语音轨stream-copy remux，不剪辑。
