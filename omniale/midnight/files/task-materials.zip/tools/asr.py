"""Transcribe a media file with faster-whisper (local, CPU).

Usage: python asr.py <media> [--lang zh] [--model large-v3] [--out segments.json]
Prints one line per segment: [start -> end] text
"""
import argparse
import json
import subprocess
import tempfile
import wave

import numpy as np
from faster_whisper import WhisperModel


def load_audio(path: str, rate: int = 16000) -> "np.ndarray":
    """Decode any media file to mono float32 PCM with ffmpeg."""
    with tempfile.TemporaryDirectory() as tmp:
        wav = f"{tmp}/audio.wav"
        subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", path,
                        "-vn", "-ac", "1", "-ar", str(rate), "-f", "wav", wav],
                       check=True)
        with wave.open(wav, "rb") as fh:
            frames = fh.readframes(fh.getnframes())
    return np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("media")
    ap.add_argument("--lang", default=None, help="e.g. zh, en; omit to auto-detect")
    ap.add_argument("--model", default="large-v3")
    ap.add_argument("--compute-type", default="int8")
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--out", default=None, help="also write segments as JSON here")
    args = ap.parse_args()

    model = WhisperModel(args.model, device="cpu", compute_type=args.compute_type,
                         cpu_threads=args.threads)
    segments, info = model.transcribe(load_audio(args.media), language=args.lang,
                                      vad_filter=True, word_timestamps=True)
    print(f"# language={info.language} prob={info.language_probability:.2f} "
          f"duration={info.duration:.1f}s")
    rows = []
    for seg in segments:
        print(f"[{seg.start:7.2f} -> {seg.end:7.2f}] {seg.text.strip()}", flush=True)
        rows.append({
            "start": round(seg.start, 2), "end": round(seg.end, 2),
            "text": seg.text.strip(),
            "words": [{"w": w.word, "s": round(w.start, 2), "e": round(w.end, 2)}
                      for w in (seg.words or [])],
        })
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(rows, fh, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
