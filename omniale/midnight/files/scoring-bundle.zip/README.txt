Requires Python, Playwright, Microsoft Edge. Candidate contains site/index.html.
Original diagnostic: python evaluate.py <candidate-output-folder> <new-raw-result-folder>
Measurement-corrected: python evaluate_audited.py <candidate-output-folder> <new-measurement-folder>
Public conservative score: python apply_score_policy.py <new-measurement-folder>/result.json v1/score-policy.json <new-final-score.json>
The policy excludes four debatable deictic scopes and a schedule check whose source times are clipped. Automatic failures still require visual audit for equivalent implementations. This adaptation score is not official EFS.
