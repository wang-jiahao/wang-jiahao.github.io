"""Reproduce an existing human review only for its exact submitted HTML hash."""
from pathlib import Path
import argparse,copy,json

def apply_review(result,review):
    assert result['submission_sha256']==review['submission_sha256'], 'Review belongs to another submission; new outputs require a new manual review.'
    out=copy.deepcopy(result)
    for item in out['items']:
        if item['id'] in review['corrections']:
            item['automatic_passed']=item['passed'];item['passed']=True
            item['manual_correction']=review['corrections'][item['id']]
    for group,data in out['groups'].items():
        scored=[i for i in out['items'] if i['group']==group and not i.get('excluded_from_score')]
        data.update(passed=sum(i['passed'] for i in scored),total=len(scored))
    out['score']=round(sum(d['weight']*d['passed']/d['total'] for d in out['groups'].values()),4)
    out['manual_review_complete']=True
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('result',type=Path);ap.add_argument('review',type=Path);ap.add_argument('out',type=Path);n=ap.parse_args()
    result=apply_review(json.loads(n.result.read_text(encoding='utf-8')),json.loads(n.review.read_text(encoding='utf-8')))
    n.out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(result['score'])
