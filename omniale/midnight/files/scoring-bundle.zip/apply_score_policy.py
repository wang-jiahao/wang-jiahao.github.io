"""Apply a visible and shared conservative scope policy without changing raw data."""
from pathlib import Path
import argparse,json,copy
def apply(result,policy):
 d=copy.deepcopy(result);excluded=policy['excluded_items'];weights=policy.get('weights',dict(final=60,base=20,behavior=10,mobile=10))
 for item in d['items']:
  if item['id'] in excluded:item['excluded_from_score']=True;item['exclusion_reason']=excluded[item['id']]
 groups={g:dict(passed=sum(x['passed'] for x in d['items'] if x['group']==g and x['id'] not in excluded),total=sum(x['group']==g and x['id'] not in excluded for x in d['items']),weight=w) for g,w in weights.items()}
 d.update(version=policy['version'],measurement_score=result['score'],score=round(sum(x['weight']*x['passed']/x['total'] for x in groups.values()),4),groups=groups,excluded_items=excluded)
 return d
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('result',type=Path);ap.add_argument('policy',type=Path);ap.add_argument('out',type=Path);n=ap.parse_args();d=apply(json.loads(n.result.read_text(encoding='utf-8')),json.loads(n.policy.read_text(encoding='utf-8')));n.out.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');print(d['score'])
