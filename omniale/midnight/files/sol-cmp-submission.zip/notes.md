# The Midnight Note — 交付说明

网站入口：[`site/index.html`](site/index.html)。可直接在浏览器打开；所有图片、样式与脚本均为本地资源，无构建步骤、无在线字体、无第三方服务。

也可在任务目录运行：

```powershell
python -m http.server 8765 --directory output/site
```

然后访问 `http://localhost:8765`。

## 完成状态

- 根据完整原型导览和英文评审制作了真实 HTML 页面，保留首屏、感官内容、16 条演出、餐饮/酒水菜单、三条 FAQ、评价、统计、四项档案、三篇文章预览、会员介绍、完整预约表单和页脚导航。
- Programming 菜单支持展开、站内跳转、点击外部关闭和 Escape；感官面板支持切换和再次点击收起。
- 五个演出筛选可用。餐饮和 FAQ 每组同时展开一项。档案支持悬停、聚焦、点击及方向键，图片、标题、提示和正文同步更新。
- 预约保留日期、场次、人数、座位、姓名、邮箱、备注和 tasting 勾选项，并进行必填/邮箱验证。提交仅在当前页面显示原型确认文案及本地说明，不发出请求、不保存个人数据、不发送邮件。
- 文章、媒体标记和会员申请使用本地说明弹窗；其他导航均滚动到相应栏目。

## 评审的累积最终状态

按语音时序结合光标停留位置解释指代；以下记录的是实际实现范围。

| 次序 / 大约时间 | 最终处理 |
| --- | --- |
| 1 / 00:01 | 演出类别改为左右两列；手机单列。 |
| 2 / 00:11 | 交换 Bebop 与 Modern Jazz 类别位置。 |
| 3 / 00:18 | Bebop 卡片背景改为深蓝。 |
| 4 / 00:27 | 页脚 Membership 入口临时移到 Visit 列顶部。 |
| 5 / 00:35 | 仅将该入口移回原来的第三位，最终为 Reserve / Experiences / Membership。 |
| 6 / 00:44 | Bebop 标题与副标题改为金色，保留深蓝卡片。 |
| 7 / 00:53 | 页脚 Experiences 入口背景使用提供的 `10.jpg` 纹理。 |
| 8 / 01:04 | 隐藏原来的大型 Feel 胶囊。为满足三个感官面板仍须可用的要求，在面板下方保留文字导航，Room atmosphere 可打开对应完整内容。 |
| 9 / 01:12 | 页脚 Experiences 入口文字居中。 |
| 10 / 01:23 | Second Chorus 标题放大并加粗，其原始说明缩小一级。 |
| 11–12 / 01:33–01:46 | Clara 与 Harrison 的交换及随后位置恢复仅改变顺序；最终 Clara 回到第一位。 |
| 13 / 01:50 | Matinée Horns 名称改为金色。 |
| 14 / 01:57 | 将 Matinée Horns 移至 Soul 列最上方，保留名称、说明、筛选属性和金色标题。 |
| 15 / 02:05 | Taste 胶囊文案居中，其说明为斜体。 |
| 16 / 02:20 | 页脚 Reserve 入口内边距加倍。 |
| 17 / 02:28 | 隐藏整张 Harrison 评价卡；数据保留在 HTML 中。 |
| 18 / 02:35 | First Chorus 与 Second Chorus 整条菜单互换，价格随菜品移动。 |
| 19 / 02:43 | 再单独互换这两条的说明。最终 Second Chorus / $28 下为 Citrus…，First Chorus / $24 下为 Charred…；先前缩小的说明随文本移动到 First Chorus。 |
| 20 / 02:53 | Clara 评价卡文案改为斜体。 |

## 验证

使用 Playwright Chromium 在 1920×1080 和 390×844 下运行了 43 项检查，全部通过。确认手机布局视口保持 390px、页面没有横向溢出、手机菜单处于视口内、所有本地图片加载、各交互和表单验证正常、无 JavaScript 错误、无外部请求。

- 检查记录：[`analysis/verification.json`](analysis/verification.json)
- 桌面整页：[`analysis/desktop-full.png`](analysis/desktop-full.png)
- 手机整页：[`analysis/mobile-full.png`](analysis/mobile-full.png)
- 餐饮展开：[`analysis/desktop-dining.png`](analysis/desktop-dining.png)、[`analysis/mobile-dining.png`](analysis/mobile-dining.png)
- 验证脚本、机器转写和抽帧脚本留在 `analysis/`，便于复核。

## 不足与近似

- 原型的演出行存在横向裁切，许多时间和描述尾部没有完整露出。已保留所有可辨认演出名称和描述主体；不可读尾部与多数逐条时间作了保守补全，无法保证与未显示部分一致。Amira 评价被裁切的词句也作了连贯补全。
- 英文真人评审多用 “this”，部分边界靠光标范围判断；上表明确列出了背景、文字、整条项目及描述等作用范围，便于后续调整。
- 金属圆环、背景轨迹和会员色球使用 CSS 静态近似；未复刻随机粒子和复杂金属动画。档案保留轻微缩放近似视差。
- 使用系统字体，未追求像素级拟合。原型过大的椭圆裁切改成圆角展开容器，以保证正文和手机端内容完整可读。
