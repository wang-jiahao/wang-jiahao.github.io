# The Midnight Note

交付入口：[`site/index.html`](site/index.html)。独立的 HTML / CSS / JavaScript 网站，图片位于 `site/assets/`；不依赖 CDN、构建工具或真实后端。可以直接打开 `index.html`，或在当前任务目录运行：

```powershell
python -m http.server 8765 --bind 127.0.0.1 --directory output/site
```

访问 `http://127.0.0.1:8765`。

## 最终页面

- 保留栏目顺序：Hero、Sensory Pillars、Artist Lineup、Experiences / FAQ、Guest Reviews、Club Records、Performance Archive、Journal / Backstage、Membership、Reserve、页脚。
- 照片全部来自给定素材；`10.jpg` 用于评审指定的纹理。金属圆环、渐变球与背景装饰采用 CSS 静态近似；未使用整页截图、视频或 canvas 代替页面。
- Program 菜单支持点击、键盘、Escape 和外部点击关闭；导航链接滚到对应栏目。
- 感官面板保留三组独立标题、正文、要点和图片；默认 Listen，可切换及收起。
- 四种演出类别、16 个条目、五个筛选可用。Date Night 显示导览演示的六项。
- Fine Dining / Private Lounge 互斥展开，保留两份四项菜单、价格和图片；三个 FAQ 分别显示自己的答案。
- 档案四项支持悬停、点击、键盘聚焦和方向键；标题、图片、标签和正文同步切换。
- Journal、媒体标记和会员申请使用本地说明弹窗。预约保留日期、场次、人数、座位、姓名、邮箱、备注、Chef’s Tasting 以及浏览器必填 / 邮箱验证。
- 预约成功只在当前页面显示所选信息。没有网络提交、邮件、浏览器持久化或个人数据上传。

## 20 条评审的累积处理

时间为 `materials/review.mp4` 近似时间。根据两次机器转写和光标画面判定对象，不根据录屏中仍未变化的原型重置其他改动。

| # | 时间 | 对象与操作 | 最终处理 |
|---|---|---|---|
| 1 | 01–07s | 演出区改左右两列 | 桌面 2×2 类别布局；390px 按阅读顺序单列 |
| 2 | 11–16s | Bebop 与 Modern Jazz 换位 | Modern Jazz 在前，Bebop 在后；整卡移动 |
| 3 | 18–21s | Bebop 改深蓝 | 被第 6 条覆盖 |
| 4 | 27–31s | 页脚 Membership 移至 Visit 顶部 | 被第 5 条移回 |
| 5 | 35–38s | Membership 链接移回 | Visit 恢复 Reserve / Experiences / Membership |
| 6 | 44–47s | Bebop 改金色 | 最终金色主题，保留第 2 条换位 |
| 7 | 53–57s | 页脚 Experiences 改纹理背景 | 仅该链接使用本地 `10.jpg` |
| 8 | 64–65s | 隐藏 Feel 展示卡整体 | 原紫色大卡片隐藏；完整面板通过下方切换入口可达 |
| 9 | 73–77s | 页脚 Experiences 居中 | 链接文字居中，保留纹理背景 |
| 10 | 83–90s | First Chorus 放大加粗；Second Chorus 缩小一级 | 前者标题 21px / 800，后者标题 14px；价格与描述保留 |
| 11 | 94–98s | Clara M. 与 Harrison D. 评论换位 | 被第 12 条再次交换抵消 |
| 12 | 100–106s | 同两条评论再次换位 | 恢复原顺序，不撤销其他修改 |
| 13 | 110–113s | Matinée Horns 改金色 | 仅该演出条目金色强调，仍属于 Bebop |
| 14 | 117–122s | Velvet Vows 移至 Soul 底部 | Golden Hour Organ / Midnight Pocket / Blue Satin Duo / Velvet Vows |
| 15 | 125–134s | Taste 居中，正文斜体 | Taste 卡片标题与说明居中；说明文字斜体 |
| 16 | 141–143s | 页脚 Reserve 的 padding 加倍 | 仅该链接内边距为同列普通链接的两倍 |
| 17 | 148–151s | 隐藏 Harrison D. 评论整体 | Harrison 隐藏；Clara、Amira 和评论栏目保留 |
| 18 | 156–162s | First Chorus 与 Second Chorus 换位 | 被第 19 条再次交换抵消 |
| 19 | 163–170s | 同两道菜再次换位 | 恢复 First / Second / Headliner / Encore；保留第 10 条样式 |
| 20 | 173–176s | Clara M. 评价正文斜体 | 仅该条引用正文斜体，姓名及附属信息不变 |

## 验证

Chromium 的 **1920×1080** 和 **390×844** 视口下，60 项交互与布局检查全部通过；没有 JavaScript 异常、整页横向溢出或站外请求。覆盖菜单、三组感官面板、五个筛选、两份菜单、三条 FAQ、四组档案、键盘操作、弹窗、表单验证与本地确认。

- 结果：[`qa/report.json`](qa/report.json)
- 可复跑检查：[`qa/verify.py`](qa/verify.py)，使用本任务 `.venv` 中的 Playwright；先启动上述静态服务器。
- 桌面全页：[`qa/full-1920.png`](qa/full-1920.png)
- 手机全页：[`qa/full-390.png`](qa/full-390.png)
- `qa/` 另有首页、演出、展开菜单、档案、预约和页脚截图。

## 近似与不足

1. 评审多次只说 “this / these”。对象按光标停留及前后动作解释，上表保留具体作用范围便于复核。尤其第一条按整个演出类别网格的双列布局处理。
2. “隐藏 Feel 整体”与 TASK.md 的“三个感官面板均须可用”同时落实：原大卡片隐藏，通过 `Explore Taste → Explore Feel → Explore Listen` 入口访问完整面板，另支持方向键切换。
3. 原型演出卡片存在横向文字裁切。名称及可见描述已保留，少量描述尾字按语义补齐；未能可靠辨认的逐条演出时间没有编造。首页可见的 Blue Hour Trio 9:45、开门 / 首场时间及预约三场次已保留。第三条评论被裁切的尾句按可见语义补齐。除 Date Night 外，导览未逐项演示的筛选归属按演出类型匹配。
4. 系统字体、图标、静态金属环与装饰有细节差异。餐饮展开容器使用适度圆角，避免原型的大胶囊圆角裁切标题和菜品。档案视差以轻微图片缩放近似。
5. 机器转写保存在 `analysis/`；末尾重复 / 幻觉句未当作额外要求。影片逐帧和裁切图仅作为分析证据，网站不引用这些图像。
