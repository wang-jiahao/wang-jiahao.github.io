# 素材与许可

AMI Meeting Corpus，AMI Consortium / University of Edinburgh / Idiap / TNO，CC BY 4.0。

- 官方项目：https://groups.inf.ed.ac.uk/ami/corpus/
- 自然会议说明：https://groups.inf.ed.ac.uk/ami/corpus/nonscenariomeetings.shtml
- 许可：https://creativecommons.org/licenses/by/4.0/
- 同场原始视频与混音：AMI EN2002d，2005-03-08，真实课程项目组开发会议浏览器，非产品设计角色扮演。

本题取原会1137.00–2209.89秒的连续末段（17分52.89秒），视频重编码为H.264并合入同步headset mix，未重排发言、变速、降噪或合成语音。主机位352×288，不能可靠读清屏幕文字，本题不要求如此。头像来自官方同场近景机位首帧；原声参考来自同场其他时段，A/B/C/D依据官方meetings.xml，未推测真实姓名或职务。

粗转写是faster-whisper small.en实际生成，无人工说话人标签或人工修正。同组上次状态来自EN2002c自然会议的作者中文选录，保留探索与已定状态的区别，不是本轮最终答案。任务只评给定片段；其他时段的事项不要求恢复。
