Place original frozen task files under sync_v7/task/. Browser MP4 previews are transcoded and do not replace original inputs. Requires Python, NumPy, SciPy, OpenCV, FFmpeg.
python grade_sync.py sync_v7 --output CANDIDATE_OUTPUT --result NEW_RESULT.json
Independently execute delivered rebuilding instructions before accepting the two rebuild points. Unknown equivalent representations require audit; do not score API failures as zero.
