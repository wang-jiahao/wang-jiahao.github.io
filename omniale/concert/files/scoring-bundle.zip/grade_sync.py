"""Deterministic visual synchronization / real performance editing rubric, using rendered media.

Offline visual/music labels are frozen before solving. No fresh aesthetic LLM
score is used. Unrecognized equivalent delivery requires audit, not an invented 0.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess
import cv2,numpy as np
from scipy.signal import correlate

ROOT=Path(__file__).resolve().parent
FPS=24;SAMPLE_HZ=4

def read_json(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def probe(p):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(p)]))
def picture(p):
    raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:v:0','-vf','fps=24,scale=64:36:flags=area','-pix_fmt','rgb24','-f','rawvideo','-'])
    return np.frombuffer(raw,dtype=np.uint8).reshape(-1,36*64*3)
def audio(p,rate=8000):
    raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:a:0','-ac','1','-ar',str(rate),'-f','f32le','-'])
    return np.frombuffer(raw,dtype='<f4').copy()
def lerp_gate(x,full,zero):return float(np.clip((zero-abs(x))/(zero-full),0,1))
def utility(gold,camera,t,field):
    rows=gold['camera_labels'][camera]
    # A coarse annotation boundary is not an exact hard cut. Resolve uncertainty
    # in the candidate's favour; all versions/runs use the same rule.
    grace=.5 if field=='quality' else 1.
    candidates=[r for r in rows if r['start']-grace<=t<r['end']+grace]
    return float(max(r[field] for r in candidates)) if candidates else float(rows[-1][field])
def focus_utility(gold,camera,t,target):
    if isinstance(target,list):return max(focus_utility(gold,camera,t,x) for x in target)
    best=max(utility(gold,c,t,target) for c in gold['camera_labels'])
    return utility(gold,camera,t,target)/max(best,.001)

def rendered_samples(version,program):
    private=version/'private';mapping=read_json(private/'source_map.json')['cameras'];sources={};cache=private/'cache';cache.mkdir(exist_ok=True)
    prototypes=[];prototype_cameras=[]
    def small(frames):return frames.reshape(-1,36,64,3).reshape(-1,18,2,32,2,3).mean(axis=(2,4)).reshape(-1,18*32*3).astype(np.float32)
    for c in mapping:
        dest=cache/f'{c}_64x36.npy'
        if dest.exists():sources[c]=np.load(dest,mmap_mode='r')
        else:
            z=picture(version/'task/inputs'/f'CAM_{c}.mp4');np.save(dest,z);sources[c]=z
        indices=np.linspace(0,len(sources[c])-1,32).astype(int);prototypes.extend(small(np.asarray(sources[c][indices])));prototype_cameras.extend([c]*len(indices))
    output=picture(program);low=small(output);p=np.array(prototypes);dist=np.maximum(0,np.sum(low*low,axis=1)[:,None]+np.sum(p*p,axis=1)[None,:]-2*low@p.T)/low.shape[1]
    ids=[prototype_cameras[i] for i in np.argmin(dist,axis=1)];duration=min(len(output)/FPS,read_json(private/'truth.json')['duration']);samples=[]
    for t in np.arange(.125,duration,1/SAMPLE_HZ):
        index=min(len(output)-1,round(t*FPS));c=ids[index];frames=sources[c];center=(t+mapping[c]['source_time_equals_program_time_plus'])*FPS;lo=max(0,int(center-FPS*12));hi=min(len(frames),int(center+FPS*12)+1);offsets=[d for d in [-1,0,1] if 0<=index+d<len(output) and ids[index+d]==c];errs=np.zeros(hi-lo,dtype=np.float32)
        candidates=np.arange(lo,hi)
        for d in offsets:
            z=np.asarray(frames[np.clip(candidates+d,0,len(frames)-1)],dtype=np.float32);frame=output[index+d].astype(np.float32);errs+=np.mean((z-frame)**2,axis=1)/len(offsets)
        j=int(np.argmin(errs));minimum=float(errs[j]);good=np.flatnonzero(errs<=minimum+max(.15,minimum*.05));k=int(good[np.argmin(abs(lo+good-center))])
        samples.append(dict(t=round(float(t),4),camera=c,mse=minimum,source_frame=lo+j,conservative_source_frame=lo+k,av_error=(lo+k-center)/FPS,recognized=minimum<=144.,temporal_frames=len(offsets)))
    return samples

def long_enough_peak(samples,start,end,value,hold=2.):
    subset=[s for s in samples if start<=s['t']<end]
    n=max(1,round(hold*SAMPLE_HZ))
    if not subset:return 0.
    values=[value(s) for s in subset]
    if len(values)<n:return float(np.mean(values))
    return float(max(np.mean(values[i:i+n]) for i in range(len(values)-n+1)))

def score_content(gold,samples):
    details=[];content=0.
    for group in gold['role_groups']:
        peaks=[long_enough_peak(samples,a,b,lambda s:focus_utility(gold,s['camera'],s['t'],group['target'])*lerp_gate(s['av_error']+gold.get('sync_adjustment',0.),.2,1.),hold=group['hold']) for a,b in group['windows']]
        value=float(np.mean(peaks));content+=group['points']*value;details.append(dict(kind='role',fraction=value,window_fractions=peaks,**group))
    contexts=[]
    for event in gold['relationship_windows']:
        wide=long_enough_peak(samples,event['start'],event['end'],lambda s:float(s['camera']=='D'),hold=3.)
        people=min(long_enough_peak(samples,event['start'],event['end'],lambda s,c=c:float(s['camera']==c),hold=2.) for c in 'ABC')
        value=max(wide,people);contexts.append(value);details.append(dict(kind='relationship',id=event['id'],fraction=value))
    components=dict(music_focus=content,handoff_relationship=5*float(np.mean(contexts)),shot_usability=0.)
    segments=[]
    for s in samples:
        if not segments or segments[-1]['camera']!=s['camera']:segments.append(dict(camera=s['camera'],start=max(0,s['t']-.125),end=s['t']+.125))
        else:segments[-1]['end']=s['t']+.125
    flicker=sum(x['end']-x['start'] for x in segments if x['end']-x['start']<1.)/gold['duration'];returns=sum(1 for a,b,c in zip(segments,segments[1:],segments[2:]) if a['camera']==c['camera'] and a['camera']!=b['camera'] and b['end']-b['start']<2.)
    components['cut_continuity']=5*max(0,1-3*flicker-returns/max(5,len(segments)-1));return components,details,segments

def score_audio(gold,master,program,samples):
    original=audio(master);render=audio(program);rate=8000;windows=[]
    for t in np.arange(1,gold['duration']-5,5.):
        a=int(t*rate);target=original[a:a+4*rate];lo=max(0,a-rate);segment=render[lo:min(len(render),a+5*rate)]
        if len(segment)<len(target):windows.append(dict(t=float(t),correlation=0,lag_seconds=99));continue
        c=correlate(segment,target,mode='valid',method='fft');j=int(np.argmax(c));chunk=segment[j:j+len(target)]
        rho=float(np.corrcoef(chunk,target)[0,1]) if np.std(chunk)>1e-8 and np.std(target)>1e-8 else 0.
        lag=(lo+j-a)/rate;windows.append(dict(t=float(t),correlation=rho,lag_seconds=lag))
    similarity=float(np.mean([np.clip((x['correlation']-.85)/.14,0,1)*lerp_gate(x['lag_seconds'],.08,.5) for x in windows]))
    duration_error=len(render)/rate-gold['duration'];continuity=lerp_gate(duration_error,.06,1.)+9*similarity
    # Video source-time error relative to the actual soundtrack time.
    audio_lag=float(np.median([x['lag_seconds'] for x in windows if x['correlation']>.9])) if any(x['correlation']>.9 for x in windows) else 0.
    av=float(np.mean([lerp_gate(s['av_error']+audio_lag,.2,1.) for s in samples]))
    gross_sync_support=float(np.mean([lerp_gate(s['av_error']+audio_lag,.2,1.) for s in samples]))
    return dict(music_integrity=continuity,av_sync=30*av),dict(windows=windows,audio_lag=audio_lag,duration_error=duration_error,
                similarity=similarity,gross_sync_support=gross_sync_support,av_mean_abs=float(np.mean([abs(s['av_error']+audio_lag) for s in samples])))

def score_delivery(out,program,samples,master_path,rebuild_ok=False):
    files=list(out.rglob('*'));names=[p.name.lower() for p in files if p.is_file()]
    edit=next((p for p in files if p.name.lower()=='edit.json'),None);sync=next((p for p in files if p.name.lower()=='sync.json'),None)
    score=0.;notes=[]
    if edit:
        try:
            plan=read_json(edit)
            if isinstance(plan,dict):plan=next((plan[k] for k in ['shots','clips','edits','timeline','segments'] if isinstance(plan.get(k),list)),None)
            if not isinstance(plan,list):raise ValueError('Equivalent EDL schema needs adapter')
            agree=[]
            for s in samples:
                row=next((x for x in plan if float(x.get('start',x.get('program_start',-1)))<=s['t']<float(x.get('end',x.get('program_end',-1)))),None)
                if row:
                    camera=str(row.get('camera',row.get('cam',''))).replace('CAM_','').replace('CAM ','')
                    agree.append(camera==s['camera'])
                else:agree.append(False)
            if np.mean(agree)>=.97:score+=1
            else:notes.append('EDL camera sequence differs from actual video; inspect before final score')
        except (ValueError,UnicodeError,TypeError):notes.append('edit.json needs equivalent-schema audit')
    if sync:
        try:read_json(sync);score+=1
        except (ValueError,UnicodeError):notes.append('sync.json needs format audit')
    wav=next((p for p in files if p.suffix.lower()=='.wav'),None)
    if wav:
        try:
            master=audio(master_path);a=audio(wav);length=min(len(master),len(a))
            if abs(len(master)-len(a))<=800 and length and np.corrcoef(master[:length],a[:length])[0,1]>.99:score+=1
            else:notes.append('Independent WAV differs: audit exact preservation')
        except (subprocess.CalledProcessError,ValueError):notes.append('Independent WAV could not be validated')
    if rebuild_ok:score+=2
    elif any(n.endswith(('.py','.sh','.ps1','.bat')) for n in names):notes.append('Rebuild pending: up to 2 points; execute documented command independently')
    return score,notes

def grade(version,out,rebuild_ok=False):
    gold=read_json(version/'private/truth.json');mp4=out/'program.mp4'
    if not mp4.exists():
        candidates=list(out.glob('*.mp4'))
        if len(candidates)!=1:raise RuntimeError('No unambiguous programme entry; audit delivery before scoring')
        mp4=candidates[0]
    samples=rendered_samples(version,mp4);ac,audit=score_audio(gold,version/'task/inputs/master.wav',mp4,samples);delivery,notes=score_delivery(out,mp4,samples,version/'task/inputs/master.wav',rebuild_ok)
    trials=[]
    for delta in np.linspace(-.04,.04,9):
        g=dict(gold,sync_adjustment=float(delta)+audit['audio_lag']);components,details,segments=score_content(g,samples);support=float(np.mean([lerp_gate(s['av_error']+g['sync_adjustment'],.2,1.) for s in samples]));components.update(ac);components['av_sync']=30*support;components['delivery_rebuild']=delivery
        raw=sum(components.values());caps=dict(music=30+70*audit['similarity'],gross_av_sync=30+70*support);trials.append(dict(delta=float(delta),total=min(raw,*caps.values()),raw_total=raw,validity_caps=caps,components=components,details=details,segments=segments,gross_sync_support=support))
    best=max(trials,key=lambda x:x['total']);unknown=sum(not s['recognized'] for s in samples)/max(1,len(samples));audit=dict(audit,gross_sync_support=best['gross_sync_support'],global_clock_adjustment=best['delta'],clock_uncertainty_seconds=.04)
    return dict(rubric=gold['rubric_version'],**{k:best[k] for k in ['total','raw_total','validity_caps','components','details','segments']},audio_audit=audit,recognition_unknown_fraction=unknown,needs_audit=(unknown>.02) or bool(notes),notes=notes,samples=samples,clock_sensitivity=[{'delta':x['delta'],'total':x['total']} for x in trials])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('version');ap.add_argument('--output',type=Path,required=True);ap.add_argument('--result',type=Path,required=True);ap.add_argument('--rebuild-ok',action='store_true');n=ap.parse_args()
    r=grade(ROOT/n.version,n.output,n.rebuild_ok);n.result.parent.mkdir(parents=True,exist_ok=True);n.result.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:r[k] for k in ['total','components','needs_audit','recognition_unknown_fraction']},ensure_ascii=False))

if __name__=='__main__':main()
