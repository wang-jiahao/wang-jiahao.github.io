"""Rebuild the complete program using only inputs, edit.json, Python and FFmpeg."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import shutil
import subprocess
import tempfile


def run(command):
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode:
        raise RuntimeError('Command failed: ' + repr(command) + '\n' + result.stderr)


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, default=here.parent / 'inputs')
    parser.add_argument('--edit', type=Path, default=here / 'edit.json')
    parser.add_argument('--out', type=Path, default=here)
    parser.add_argument('--workers', type=int, default=2)
    args = parser.parse_args()
    edl = json.loads(args.edit.read_text(encoding='utf-8'))
    segments = edl['segments']
    fps = edl['fps']
    assert fps == 24 and edl['duration'] == 90
    previous = 0
    for s in segments:
        assert s['camera'] in 'ABCD'
        assert s['start_frame'] == previous
        assert s['end_frame'] > previous
        assert abs(s['start'] - s['start_frame']/fps) < 1e-7
        assert abs(s['end'] - s['end_frame']/fps) < 1e-7
        assert abs(s['source_in'] - s['source_in_frame']/fps) < 1e-7
        previous = s['end_frame']
    assert previous == 2160
    args.out.mkdir(parents=True, exist_ok=True)
    # This is a bit-for-bit copy, including the 48 kHz/24-bit mono PCM samples.
    audio_out = args.out / 'final_audio.wav'
    shutil.copyfile(args.inputs / 'master.wav', audio_out)
    with tempfile.TemporaryDirectory(prefix='concert_rebuild_', dir=args.out) as temp:
        temp = Path(temp)

        def render(item):
            index, s = item
            dest = temp / f'shot_{index:03}.mp4'
            count = s['end_frame'] - s['start_frame']
            run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
                 '-ss', f"{s['source_in_frame']/fps:.12f}",
                 '-i', str(args.inputs / f"CAM_{s['camera']}.mp4"),
                 '-map', '0:v:0', '-an', '-frames:v', str(count),
                 '-vf', 'setpts=PTS-STARTPTS', '-r', '24', '-vsync', '1',
                 '-c:v', 'libx264', '-preset', 'slow', '-crf', '18',
                 '-threads', '4', '-pix_fmt', 'yuv420p',
                 '-video_track_timescale', '24000', str(dest)])
            print(f"Rendered {index+1}/{len(segments)}: {s['camera']} {s['start']:.3f}-{s['end']:.3f}", flush=True)
            return dest

        with ThreadPoolExecutor(max_workers=max(1,args.workers)) as executor:
            shots = list(executor.map(render, enumerate(segments)))
        # Filenames are generated locally, so the concat manifest needs no user path escaping.
        manifest = temp / 'shots.txt'
        # Explicit rational shot durations avoid millisecond-rounded MP4 format durations
        # accumulating fractional-frame timestamp errors at cuts in older FFmpeg builds.
        manifest.write_text(''.join(
            f"file '{p.name}'\nduration {(s['end_frame']-s['start_frame'])/fps:.12f}\n"
            for p,s in zip(shots,segments)), encoding='utf-8')
        run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
             '-f', 'concat', '-safe', '0', '-i', manifest.as_posix(),
             '-i', str(audio_out), '-map', '0:v:0', '-map', '1:a:0',
             '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-ac', '1',
             '-t', '90', '-video_track_timescale', '24000',
             '-movflags', '+faststart', str(args.out / 'program.mp4')])
    print('Complete:', args.out / 'program.mp4', flush=True)


if __name__ == '__main__':
    main()
