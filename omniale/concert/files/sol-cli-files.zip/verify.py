"""Verify delivered files against source frame mapping, PCM samples, and format."""
from pathlib import Path
import hashlib
import json
import subprocess
import cv2
import numpy as np
from scipy.signal import correlate, correlation_lags

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent

def probe(path):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames',
        '-show_streams','-show_format','-of','json',str(path)]))

def audio(path):
    return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(path),
        '-map','0:a:0','-f','f32le','-acodec','pcm_f32le','-']),dtype='<f4')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def get_frame(cap,n):
    cap.set(cv2.CAP_PROP_POS_FRAMES,n)
    ok,im=cap.read()
    assert ok,(n,cap.get(cv2.CAP_PROP_FRAME_COUNT))
    return im

def main():
    report={}
    info=probe(HERE/'program.mp4')
    video=next(s for s in info['streams'] if s['codec_type']=='video')
    sound=next(s for s in info['streams'] if s['codec_type']=='audio')
    assert video['codec_name']=='h264' and video['width']==1280 and video['height']==720
    assert video['avg_frame_rate']=='24/1' and int(video['nb_read_frames'])==2160
    assert abs(float(video['duration'])-90)<1e-6
    assert abs(float(info['format']['duration'])-90)<=1/24
    assert sound['codec_name']=='aac' and int(sound['sample_rate'])==48000 and sound['channels']==1
    assert abs(float(sound['duration'])-90)<=1/48000
    report['format']={'duration_seconds':float(info['format']['duration']),
       'video_frames':int(video['nb_read_frames']),'fps':24,'resolution':[1280,720],
       'video_codec':video['codec_name'],'audio_codec':sound['codec_name'],
       'audio_sample_rate':int(sound['sample_rate']),'audio_channels':sound['channels']}
    # Decode the entire deliverable, failing on corrupt frames or timestamp errors.
    decoded=subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(HERE/'program.mp4'),
                            '-f','null','-'],capture_output=True,text=True)
    assert decoded.returncode==0,decoded.stderr
    report['full_decode']='passed'
    source_sha=sha(ROOT/'inputs'/'master.wav');final_sha=sha(HERE/'final_audio.wav')
    assert source_sha==final_sha
    master=audio(ROOT/'inputs'/'master.wav');program=audio(HERE/'program.mp4')
    assert len(master)==4320000
    assert len(program)>=len(master)
    original_decoded_count=len(program);program=program[:len(master)]
    # The lag estimate spans the complete waveform, independently of timestamps.
    cc=correlate(program,master,mode='full',method='fft')
    lags=correlation_lags(len(program),len(master),mode='full')
    mask=np.abs(lags)<=4800;lag=int(lags[mask][np.argmax(cc[mask])])
    assert lag==0
    per_second=[float(np.corrcoef(master[i:i+48000],program[i:i+48000])[0,1]) for i in range(0,len(master),48000)]
    assert min(per_second)>.97
    report['audio']={'wav_matches_master_byte_for_byte':True,'wav_sha256':final_sha,
      'pcm_samples_per_channel':len(master),'aac_decoded_samples_including_packet_padding':original_decoded_count,
      'aac_waveform_lag_samples':lag,'aac_waveform_correlation':float(np.corrcoef(master,program)[0,1]),
      'minimum_one_second_correlation':min(per_second),
      'aac_snr_db':float(10*np.log10(np.sum(master.astype(float)**2)/np.sum((program-master).astype(float)**2)))}
    edl=json.loads((HERE/'edit.json').read_text(encoding='utf-8'))
    sync=json.loads((HERE/'sync.json').read_text(encoding='utf-8'))
    cap=cv2.VideoCapture(str(HERE/'program.mp4'))
    cameras={c:cv2.VideoCapture(str(ROOT/'inputs'/f'CAM_{c}.mp4')) for c in 'ABCD'}
    checks=[];thumbnails=[]
    for shot in edl['segments']:
        camera=shot['camera'];start=shot['start_frame'];count=shot['end_frame']-start
        assert shot['source_in_frame']-start==sync['cameras'][camera]['offset_source_frames']
        for local in sorted(set([0,count//4,count//2,3*count//4,count-1])):
            p=start+local;s=shot['source_in_frame']+local
            output=get_frame(cap,p);original=get_frame(cameras[camera],s)
            mse=float(np.mean((output.astype(np.float32)-original.astype(np.float32))**2))
            psnr=99. if mse==0 else float(10*np.log10(255**2/mse))
            assert psnr>34,(p,camera,s,psnr)
            checks.append({'program_frame':p,'camera':camera,'source_frame':s,'psnr_db':round(psnr,3)})
            if local==count//2:
                thumb=cv2.resize(output,(384,216));cv2.rectangle(thumb,(0,0),(384,29),(0,0,0),-1)
                cv2.putText(thumb,f"{shot['id']:02}  {camera}  {shot['start']:.3f}-{shot['end']:.3f}s",(5,20),0,.48,(255,255,255),1)
                thumbnails.append(thumb)
    cap.release()
    for v in cameras.values():v.release()
    while len(thumbnails)%3:thumbnails.append(np.zeros((216,384,3),np.uint8))
    cv2.imwrite(str(HERE/'qa'/'program_contact_sheet.jpg'),np.vstack([np.hstack(thumbnails[i:i+3]) for i in range(0,len(thumbnails),3)]))
    report['source_frame_checks']={'samples':checks,'minimum_psnr_db':min(c['psnr_db'] for c in checks)}
    report['edit']={'shots':len(edl['segments']),'cuts':len(edl['segments'])-1,
       'minimum_shot_duration':min(s['end']-s['start'] for s in edl['segments']),
       'camera_duration_seconds':{c:sum(s['end']-s['start'] for s in edl['segments'] if s['camera']==c) for c in 'ABCD'},
       'required_stable_examples':{'white_0_30':[5.125,16.25],'white_60_90':[60.25,65.375],
                                   'burgundy_20_50':[27.0416666667,33.1666666667],
                                   'drummer_55_75':[65.375,73.5833333333],
                                   'ensemble_open':[0,5.125],'ensemble_close':[86.7083333333,90]}}
    (HERE/'qa'/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='source_frame_checks'},ensure_ascii=False,indent=2))
    print('Source frame checks:',len(checks),'minimum PSNR:',report['source_frame_checks']['minimum_psnr_db'])

if __name__=='__main__':main()
