"""Independent image-motion synchronization; no metadata timecode or external data."""
from pathlib import Path
import cv2
import numpy as np
from scipy.ndimage import gaussian_filter1d
import json

ROOT = Path(__file__).resolve().parent.parent
QA = ROOT / 'output' / 'qa'
QA.mkdir(exist_ok=True)
# Observed actor regions in the supplied files, in native pixels.
ROIS = {
 'CAM_A': {'A': (100,155,700,545)},
 'CAM_B': {'B': (180,45,620,575)},
 'CAM_C': {'C': (370,0,320,475)},
 'CAM_D': {'B': (260,215,300,425), 'A': (615,315,215,385), 'C': (760,525,280,195)},
 'sync_reference': {'A':(365,75,100,120), 'B':(72,25,110,145), 'C':(353,211,90,140),
                    'DA':(1490,90,125,165), 'DB':(1315,85,190,220), 'DC':(1585,165,240,180)}
}

def extract(name):
    cap = cv2.VideoCapture(str(ROOT/'inputs'/f'{name}.mp4'))
    fps = cap.get(cv2.CAP_PROP_FPS)
    features = {key: [] for key in ROIS[name]}
    prev = {}
    while True:
        ok, frame = cap.read()
        if not ok: break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        for key, (x,y,w,h) in ROIS[name].items():
            roi = cv2.resize(gray[y:y+h,x:x+w], (96,128))
            roi = cv2.GaussianBlur(roi,(3,3),.8)
            if key in prev:
                flow=cv2.calcOpticalFlowFarneback(prev[key],roi,None,.5,3,13,2,5,1.1,0)
                mag=np.linalg.norm(flow,axis=2)
                # Whole-body, top (head), middle (arms), lower (hands/instrument).
                features[key].append([float(np.mean(mag)),float(np.mean(mag[:43])),float(np.mean(mag[43:86])),float(np.mean(mag[86:]))])
            prev[key]=roi
    cap.release()
    data={key:np.array(value) for key,value in features.items()}
    data['times']=(np.arange(len(next(iter(features.values()))))+.5)/fps
    np.savez_compressed(QA/f'motion_{name}.npz',**data)
    print('extracted',name,len(data['times']),flush=True)
    return data

def correlate(src, ref, skey, rkey):
    grid=np.arange(2,88,.04)
    r=np.stack([np.interp(grid,ref['times'],ref[rkey][:,j]) for j in range(4)],axis=1)
    r=np.log1p(r*5)
    r-=gaussian_filter1d(r,15,axis=0)
    scores=[]
    offsets=np.arange(-55,55,.02)
    for offset in offsets:
        valid=(grid+offset>=src['times'][0])&(grid+offset<=src['times'][-1])
        s=np.stack([np.interp(grid+offset,src['times'],src[skey][:,j]) for j in range(4)],axis=1)
        s=np.log1p(s*5); s-=gaussian_filter1d(s,15,axis=0)
        rs=r[valid];ss=s[valid]
        corrs=np.sum(rs*ss,axis=0)/np.sqrt(np.sum(rs**2,axis=0)*np.sum(ss**2,axis=0)+1e-10)
        scores.append(corrs)
    scores=np.array(scores)
    combined=np.mean(np.sort(scores,axis=1)[:,-2:],axis=1)
    order=np.argsort(combined)[::-1]
    peaks=[]
    for ix in order:
        if all(abs(offsets[ix]-p['offset'])>.4 for p in peaks):
            peaks.append({'offset':round(float(offsets[ix]),4),'score':round(float(combined[ix]),4),'channels':np.round(scores[ix],4).tolist()})
            if len(peaks)==8:break
    return peaks

if __name__=='__main__':
    cv2.setNumThreads(2)
    data={}
    for name in ROIS:
        cache=QA/f'motion_{name}.npz'
        data[name]=dict(np.load(cache)) if cache.exists() else extract(name)
    result={}
    for c in 'ABCD':
        for actor in ROIS['CAM_'+c]:
            for rk in ([actor] if c!='D' else [actor,'D'+actor]):
                key=c+'_'+rk
                result[key]=correlate(data['CAM_'+c],data['sync_reference'],actor,rk)
                print(key,json.dumps(result[key][:4]),flush=True)
    (QA/'motion_candidates.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
