"""Make auditable, multi-event witness comparisons from the supplied files."""
from pathlib import Path
import cv2
import numpy as np
import json
from scipy.ndimage import gaussian_filter1d

ROOT=Path(__file__).resolve().parent.parent
QA=ROOT/'output'/'qa'
OFFSETS={'A':3.,'B':29/24,'C':4.,'D':2.5}
EVENTS={'A':[20.58,44.38,83.38], 'B':[22.98,39.78,69.78],
        'C':[6.58,49.98,71.78], 'D':[20.58,39.78,83.38]}
PANELS={'A':(262,0,262,196),'B':(0,0,262,196),
        'C':(262,196,262,196),'D':(1222,0,698,392)}

def frame(cap,t):
    cap.set(cv2.CAP_PROP_POS_MSEC,t*1000)
    ok,im=cap.read()
    assert ok
    return im

for c in 'ABCD':
    source=cv2.VideoCapture(str(ROOT/'inputs'/f'CAM_{c}.mp4'))
    ref=cv2.VideoCapture(str(ROOT/'inputs'/'sync_reference.mp4'))
    rows=[]
    for t in EVENTS[c]:
        rline=[];sline=[]
        for dt in [-.2,0,.2]:
            p=t+dt;srct=round((p+OFFSETS[c])*24)/24
            im=frame(ref,p);x,y,w,h=PANELS[c];im=cv2.resize(im[y:y+h,x:x+w],(384,216))
            cv2.rectangle(im,(0,0),(384,25),(0,0,0),-1)
            cv2.putText(im,f'REF program {p:.3f}s',(5,18),0,.48,(255,255,255),1)
            rline.append(im)
            im=cv2.resize(frame(source,srct),(384,216))
            cv2.rectangle(im,(0,0),(384,25),(0,0,0),-1)
            cv2.putText(im,f'CAM {c} source {srct:.3f}s',(5,18),0,.48,(0,255,255),1)
            sline.append(im)
        rows += [np.hstack(rline),np.hstack(sline)]
    cv2.imwrite(str(QA/f'sync_evidence_{c}.jpg'),np.vstack(rows),[cv2.IMWRITE_JPEG_QUALITY,94])
    source.release();ref.release()

# Independent checks against the right HD witness, across three separated windows.
ref=dict(np.load(QA/'motion_sync_reference.npz'))
checks={}
for c,sk,rk,ch,center in [('A','A','DA',1,3.),('B','B','DB',2,1.2),
                          ('C','C','DC',0,4.),('D','B','DB',1,2.5),('D','A','DA',3,2.5)]:
    src=dict(np.load(QA/f'motion_CAM_{c}.npz'));records=[]
    for lo,hi in [(3,28),(32,57),(61,87)]:
        grid=np.arange(lo,hi,.01)
        r=np.log1p(5*np.interp(grid,ref['times'],ref[rk][:,ch]))
        r-=gaussian_filter1d(r,60)
        offsets=np.arange(center-.2,center+.201,.005);scores=[]
        for off in offsets:
            s=np.log1p(5*np.interp(grid+off,src['times'],src[sk][:,ch]));s-=gaussian_filter1d(s,60)
            scores.append(np.dot(r,s)/np.sqrt(np.dot(r,r)*np.dot(s,s)))
        k=int(np.argmax(scores))
        records.append({'program_window':[lo,hi],'source_minus_program_seconds':round(float(offsets[k]),4),
                        'motion_correlation':round(float(scores[k]),4)})
    checks[c+'_'+rk]=records
(QA/'hd_window_sync.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks,indent=2))
