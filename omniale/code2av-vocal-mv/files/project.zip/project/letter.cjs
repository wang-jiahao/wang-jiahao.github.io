const { W,H,clamp,mix,ease,random,gradient,glow,polygon,line,oval,camera,boat } = require('./draw.cjs');

function inkRows(c, time) {
  const rows = [
    ['My friend,', 42, 88, 1.6], ['I hope the weather', 47, 143, 2.8],
    ['has been kind.', 52, 189, 5.4], ['With love,', 66, 276, 8.4],
  ];
  c.fillStyle='#584746';
  for (const [text,x,y,start] of rows) {
    const progress=clamp((time-start)/1.43);
    if(!progress) continue;
    c.save(); c.beginPath(); c.rect(x-2,y-40,298*progress,58); c.clip();
    c.font='italic 31px Georgia, serif';
    c.fillText(text,x,y);
    c.restore();
  }
  const sign=ease(8.7,10.1,time);
  if(sign>0){
    c.save(); c.beginPath(); c.rect(57,315,224*sign,62); c.clip();
    c.beginPath(); c.moveTo(59,351); c.bezierCurveTo(76,381,108,323,110,325);
    c.bezierCurveTo(117,329,92,364,113,348); c.bezierCurveTo(145,329,132,366,162,347);
    c.bezierCurveTo(181,335,169,365,225,348);
    c.moveTo(83,371); c.quadraticCurveTo(144,353,240,360);
    c.strokeStyle='#594044'; c.lineWidth=1.8; c.stroke(); c.restore();
  }
}

function writingHand(c, x, y, phase, voice, opacity) {
  c.save(); c.translate(x,y); c.rotate(-.325+Math.sin(phase*5)*.035); c.globalAlpha=opacity;
  polygon(c,'#3e272b55',[[13,6],[89,-14],[167,13],[347,122],[308,234],[103,111],[44,59]]);
  c.beginPath(); c.moveTo(275,143); c.lineTo(136,78); c.bezierCurveTo(94,66,48,57,30,45);
  c.bezierCurveTo(7,28,5,16,16,10); c.bezierCurveTo(25,3,38,13,55,20);
  c.bezierCurveTo(44,2,30,-3,38,-16); c.bezierCurveTo(45,-32,61,-18,83,-8);
  c.bezierCurveTo(124,-12,146,3,185,24); c.lineTo(327,96); c.closePath();
  c.fillStyle=gradient(c,34,-5,168,143,'#d89a6c','#a96c54','#71474a'); c.fill();
  line(c,'#7c4c44a0',1.9,[43,14],[64,27],[87,29]);
  line(c,'#f0bc90a6',2,[20,17],[31,18],[48,31]);
  line(c,'#673a3a94',1.7,[102,1],[125,11],[159,41]);
  polygon(c,gradient(c,146,51,250,140,'#9f4940','#512c3a'),[[151,76],[198,18],[310,73],[350,142],[298,210],[214,148]]);
  line(c,'#d58e6294',2,[150,72],[197,19],[203,22],[156,81]);
  line(c,'#392c34',6,[1,1],[91-voice*4,-71]);
  line(c,'#b9714e',2,[6,-3],[90,-71]);
  line(c,'#2c2530',1.8,[-3,6],[6,-4]);
  oval(c,'#ddb07b',31,15,15,8,.38);
  c.restore();
}

function correspondence(c,t,u,p) {
  const fold=ease(10.4,14.4,u);
  c.fillStyle=gradient(c,0,0,W,H,'#31262d','#644035','#a2724f'); c.fillRect(0,0,W,H);
  c.save(); camera(c,640-29*ease(0,13,u),356+10*fold,1.05+.13*ease(0,13,u),-.021+.03*fold);
  const rng=random(541);
  for(let i=0;i<110;i++){
    const x=rng()*1590-160,y=rng()*860-80,len=18+rng()*290;
    line(c,i%3===0?'#e4ac7935':'#371f2858',.45+rng()*1.25,[x,y],[x+len*.5,y-3],[x+len,y-8]);
  }
  for (const y of [58,245,449,664]) {
    line(c,'#493032',4,[-170,y+25],[1430,y-28]);
    line(c,'#a171536e',1.5,[-170,y+27],[1430,y-26]);
  }
  glow(c,557,276,520+36*p.voice,'#f1c18283','#d8954462','#f0c48400');
  oval(c,'#0e142050',968,227,95,61,.19);
  oval(c,'#825335',935,196,83,73,.10);
  oval(c,'#30444a',932,183,79,69,.10);
  oval(c,'#728177',932,178,69,57,.13,true,2);
  oval(c,'#322833',930,177,64,53,.14);
  oval(c,'#52413e',926,177,58,48,.12);
  oval(c,'#746152',922,168,47,35,.19);
  oval(c,'#405457',1011,201,25,15,.32,true,7);
  for (let j=0;j<3;j++) {
    c.beginPath();
    const x=916+j*13+Math.sin(t*1.24+j)*10;
    c.moveTo(x,158); c.bezierCurveTo(x-35,118,x+39,97,x+3,59-j*11);
    c.lineWidth=1.2+j*.48; c.strokeStyle=`rgba(245,218,179,${.13+j*.03})`; c.stroke();
  }
  c.save(); c.translate(1030,386); c.rotate(.30);
  c.fillStyle='#32252d68'; c.fillRect(6,9,280,166);
  c.fillStyle='#c59a6f'; c.fillRect(0,0,280,166);
  polygon(c,'#e1b888',[[0,0],[140,108],[280,0]]);
  line(c,'#936447',1.5,[1,163],[91,82],[140,108],[189,82],[279,163]);
  oval(c,'#a8564b',139,105,17,15,.4); oval(c,'#783d40',141,105,11,9,.4,true,1.3);
  c.restore();
  c.save(); c.translate(421+fold*40,137+fold*103); c.rotate(-.154+fold*.34);
  const shrink=1-.52*fold, paperW=420*shrink, paperH=436*(1-.66*fold);
  c.globalAlpha=1-ease(.68,.97,fold);
  polygon(c,'#2d2228a0',[[10,15],[paperW+13,7],[paperW+17,paperH+18],[5,paperH+23]]);
  polygon(c,gradient(c,0,0,paperW,paperH,'#f5dfad','#eac99b','#c59265'),[[0,1],[paperW,-2],[paperW+5,paperH],[-4,paperH+4]]);
  line(c,'#fff0c088',1,[2,3],[paperW-3,0]);
  line(c,'#ba996d92',1.3,[5,paperH*.55],[paperW-4,paperH*.56]);
  line(c,'#f9deb085',1,[5,paperH*.55+2],[paperW-4,paperH*.56+2]);
  c.save(); c.scale(shrink,1-.66*fold); inkRows(c,u); c.restore();
  if(fold>0){
    polygon(c,'#d4a174',[[0,0],[paperW*.51,paperH*(.13+.64*fold)],[0,paperH*.61]]);
    polygon(c,'#f4d4a1',[[paperW,0],[paperW*.51,paperH*(.13+.64*fold)],[paperW+5,paperH*.63]]);
    line(c,'#98695391',1.7,[0,0],[paperW*.51,paperH*(.13+.64*fold)],[paperW,0]);
  }
  if(u<11.8){
    const row = u<3.0 ? [65,90,1.6] : u<5.02 ? [62,145,2.8] : u<7.8 ? [65,189,5.4] : u<8.7 ? [72,275,8.4] : [79,347,8.7];
    const journey=ease(row[2],row[2]+1.43,u);
    writingHand(c,row[0]+journey*182+Math.sin(u*7)*4,row[1]+Math.cos(u*7)*4,u,p.voice,1-ease(9.7,11.75,u));
  }
  c.restore();
  if(fold>.54){
    c.save(); c.globalAlpha=ease(.54,.95,fold);
    boat(c,560+fold*59,359+fold*23,1.08+fold*.27,t,p.k,true);
    c.restore();
  }
  c.restore();
}

module.exports = { correspondence };
