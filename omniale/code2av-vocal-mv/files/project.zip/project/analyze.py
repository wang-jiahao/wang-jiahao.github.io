"""Measure melody, syllable activity and pulse candidates from the dry stem."""
import json
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy import ndimage, signal
from scipy.fft import irfft, rfft

PROJECT = Path(__file__).resolve().parent
ROOT = PROJECT.parents[1]
WORK = ROOT / '.rainfall-work'
HOP = 0.01
NAMES = 'C C# D Eb E F F# G Ab A Bb B'.split()


def analyze():
    audio, rate = sf.read(ROOT / 'input/vocals.wav', dtype='float32', always_2d=True)
    assert rate == 48000 and len(audio) == 4320000
    y = signal.resample_poly(audio.mean(axis=1), 1, 4)
    y = signal.sosfilt(signal.butter(2, (65, 5300), 'bandpass', fs=12000, output='sos'), y)
    step, width = 120, 720
    pad = np.pad(y, width // 2)
    frames = np.lib.stride_tricks.sliding_window_view(pad, width)[::step]
    mag = abs(rfft(frames * np.hanning(width), 1024))
    db = 20 * np.log10(np.maximum(1e-6, np.sqrt(np.mean(frames ** 2, axis=1))))
    high = 20 * np.log10(np.maximum(1e-6, np.sqrt(np.sum(mag[:, 185:440] ** 2, axis=1)) / 220))
    flux = np.maximum(0, np.diff(np.log1p(mag * 8), axis=0, prepend=0)).mean(axis=1)
    # YIN difference normalized by cumulative lag energy.
    corr = irfft(abs(rfft(frames, 2048)) ** 2)
    sq = np.pad(np.cumsum(frames ** 2, axis=1), ((0, 0), (1, 0)))
    lag = np.arange(190)
    diff = np.maximum(0, sq[:, width-lag] + sq[:, -1:] - sq[:, lag] - 2*corr[:, :190])
    cmnd = (diff[:, 1:] * lag[1:]) / np.maximum(1e-10, np.cumsum(diff[:, 1:], axis=1))
    pitch = np.zeros(len(frames))
    confidence = np.zeros(len(frames))
    for i, row in enumerate(cmnd):
        if db[i] < -48:
            continue
        minima = np.flatnonzero((row[1:-1] < row[:-2]) & (row[1:-1] <= row[2:])) + 1
        minima = minima[(minima > 16) & (row[minima] < 0.24)]
        if not len(minima):
            continue
        j = minima[0]
        a, b, c = row[j-1:j+2]
        delta = 0.5 * (a-c) / max(1e-10, a-2*b+c)
        pitch[i] = 69 + 12*np.log2(12000 / (j+1+delta) / 440)
        confidence[i] = 1-b
    WORK.mkdir(exist_ok=True)
    np.savez_compressed(WORK / 'vocal_features.npz', pitch=pitch, confidence=confidence,
                        db=db, high=high, flux=flux)
    return pitch, db, high, flux


def summarize(pitch, db, high, flux):
    voiced = (pitch > 0) & (db > -41)
    rounded = np.rint(pitch).astype(int)
    hist = np.bincount(rounded[voiced] % 12, minlength=12)
    profiles = {'major': [6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88],
                'minor': [6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17]}
    keys = sorted(((np.corrcoef(hist, np.roll(profile, root))[0, 1], NAMES[root], mode)
                   for mode, profile in profiles.items() for root in range(12)), reverse=True)
    print('Pitch classes:', dict(zip(NAMES, hist.tolist())))
    print('Key candidates:', [(round(score, 3), note, mode) for score, note, mode in keys[:7]])
    print('Tuning cents:', round(float(np.median((pitch-rounded)[voiced])*100), 2))
    envelope = ndimage.gaussian_filter1d(np.clip((db+55)/32, 0, 1), 3)
    onset = ndimage.gaussian_filter1d(np.maximum(0, np.diff(envelope, prepend=0)), 2) + 0.12*flux
    peaks, _ = signal.find_peaks(onset, distance=9, prominence=0.009)
    activity = ndimage.binary_closing((db > -49) | (high > -50), iterations=10)
    spans = np.flatnonzero(np.diff(np.r_[False, activity, False])).reshape(-1, 2)
    for a,b in spans:
        if b-a >= 25:
            print(f'phrase {a*HOP:5.2f}-{b*HOP:5.2f}', 'onsets', ' '.join(f'{x*HOP:.2f}' for x in peaks[(peaks>=a)&(peaks<b)]))
    smooth = ndimage.median_filter(rounded, size=7)
    cuts = np.r_[0, 1+np.flatnonzero(np.diff(smooth)), len(smooth)]
    events = []
    for a,b in zip(cuts[:-1],cuts[1:]):
        midi = int(smooth[a])
        if midi and b-a >= 9 and np.quantile(db[a:b], .75) > -40:
            events.append([round(a*HOP,2),round(b*HOP,2),midi])
    for k in range(0,90,4):
        print(f'{k:02d}s', ' '.join(f'{a:05.2f}:{NAMES[p%12]}{p//12-1}({b-a:.2f})' for a,b,p in events if k <= a < k+4))
    with (WORK / 'note_events.json').open('w', encoding='utf8') as handle:
        json.dump({'notes':events,'pitch_class_frames':dict(zip(NAMES,hist.tolist())),
                   'phrase_candidates':[(a*HOP,b*HOP) for a,b in spans if b-a>=25],
                   'onset_peaks_s':(peaks*HOP).tolist()}, handle)


if __name__ == '__main__':
    summarize(*analyze())
