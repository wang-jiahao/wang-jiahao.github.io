const { W,H,TAU,clamp,mix,ease,mod,random,gradient,glow,polygon,line,oval,camera,
  particles,rain,water,rings,distantLand,traveler,boat } = require('./draw.cjs');

function canalWall(c, left, t, travel) {
  c.save(); if(!left){c.translate(W,0);c.scale(-1,1);}
  const edge=628-(left?0:20), lip=458;
  polygon(c,gradient(c,18,692,edge,lip,'#0d222c','#28464a','#4d5751'),[[-220,748],[-110,204],[edge,lip],[edge,lip+26],[-28,768]]);
  polygon(c,'#526965',[[-130,206],[-120,184],[edge,lip-4],[edge+4,lip],[-32,251]]);
  line(c,'#afac8b77',1.6,[-150,178],[edge,lip-4]);
  for(let j=0;j<16;j++){
    const f=mod((j/16)+travel,1)**2, x=mix(edge,-180,f), y=mix(lip,192,f);
    line(c,'#81948a66',1+f*2,[x,y],[x+8*f,y+20*f],[x-14*f,y+101*f]);
  }
  for(let j=0;j<5;j++){
    const f=mod(j/5+travel,.99)**1.9;
    const x=mix(edge,-95,f),y=mix(lip-5,211,f),size=.11+f*1.16;
    c.save(); c.translate(x,y); c.scale(size,size);
    line(c,'#1d3038',6,[0,2],[0,-132]);
    line(c,'#a6a3866f',1.3,[-2,-3],[-2,-127]);
    polygon(c,'#1c3037',[[-11,-131],[-9,-150],[9,-150],[11,-131]]);
    polygon(c,'#3c4c47',[[-15,-149],[0,-159],[15,-149]]);
    c.fillStyle='#ebc48c'; c.fillRect(-6,-147,12,13);
    const a=Math.sin(t*1.1+j)*.1;
    glow(c,0,-141,41,'#edcb90a0',`rgba(235,191,115,${.25+a})`,'#ebbf7300');
    c.restore();
  }
  c.restore();
}

function crossing(c,t,u,p) {
  const drift=ease(0,15.45,u), travel=(u+1)*.037;
  c.fillStyle=gradient(c,0,0,W,510,'#142633','#294754','#82998d'); c.fillRect(0,0,W,H);
  glow(c,672,324,560,'#e0cd91aa','#7b9a8f66','#86a8a000');
  c.save(); camera(c,646+27*Math.sin(drift*3),369-44*drift,1.06+.14*drift,.005*Math.sin(u*.4));
  distantLand(c,468,'#466260',-u,101,731);
  distantLand(c,469,'#284652',u,49,732);
  water(c,'#98a99b','#102f3d',449,t,p.k,['#819e9a77','#203f51bb','#6b958daa','#b3b4a077','#f5dba17b'],671,1.2);
  canalWall(c,true,t,travel); canalWall(c,false,t,travel+.09);
  const m=ease(0,12.8,u);
  const x=555+126*m+Math.sin(t*.91)*15,y=570-76*m;
  rings(c,t,p.since,[[x,y,125],[574,514,79],[690,584,92],[676,474,45],[590,642,190]],'206,228,203');
  boat(c,x,y,.70-.27*drift,t,p.k);
  c.restore();
  rain(c,t,Math.round(163-66*drift+p.voice*34),.89,.71);
}

function reeds(c,t,side,density,color,seed,v) {
  const r=random(seed);
  c.beginPath();
  for(let i=0;i<density;i++){
    const a=r(), x=side===0 ? -48+a*425 : 951+a*400;
    const y=612+r()*157, h=(22+r()*117)*(y/720)**3;
    const bend=(r()-.39)*55+Math.sin(t*1.8+a*8)*(12+v*7);
    c.moveTo(x,y); c.quadraticCurveTo(x+bend*.28,y-h*.67,x+bend,y-h);
    c.moveTo(x+bend*.42,y-h*.76);c.quadraticCurveTo(x+bend*.54+13,y-h*.88,x+bend*.78+18,y-h*.88);
    c.moveTo(x+bend*.23,y-h*.56);c.quadraticCurveTo(x+bend*.22-15,y-h*.70,x+bend*.13-21,y-h*.72);
  }
  c.lineWidth=1.5; c.strokeStyle=color; c.stroke();
}

function skyBreak(c,t,u,p,horizon,end) {
  const sunX=end?836:902-72*ease(0,18,u), sunY=end?283:308-79*ease(0,18,u);
  c.fillStyle=end?gradient(c,0,0,0,horizon+45,'#557a76','#91a995','#f1c997'):
    gradient(c,0,0,90,horizon+75,'#2e4e63','#71988f','#e9bc89');
  c.fillRect(0,0,W,H);
  glow(c,sunX,sunY,Math.round(414+(end?78:0)+p.voice*32),'#ffe4bcd8','#eac88b73','#f6d4a400');
  const radius=end?68:57+6*ease(0,18,u);
  oval(c,end?'#fce6b0':'#fbe3af',sunX,sunY,radius,radius);
  const rng=random(606);
  for(let i=0;i<16;i++){
    const x=mod(rng()*1760+u*(3+i*.27),1760)-230, y=rng()*286+51, r=62+rng()*256;
    c.save(); c.translate(x,y); c.rotate(-.062+i*.004);
    oval(c,i%3?'#f1d6ae31':'#577c804b',0,0,r,3+rng()*16);
    c.restore();
  }
  for(let j=0;j<6;j++){
    const x=mod(1160-u*22-j*46,1450)-22, y=231-17*j+Math.sin(u*1.13+j)*16;
    const flap=5+Math.sin(u*8-j*2.2)*4.8;
    c.beginPath(); c.moveTo(x-12,y-flap); c.quadraticCurveTo(x-6,y-flap-1,x,y);
    c.quadraticCurveTo(x+5,y-flap-2,x+12,y-flap+1);
    c.lineWidth=1.45; c.strokeStyle='#45595a'; c.stroke();
  }
  return sunX;
}

function openWater(c,t,u,p,end=false) {
  const h=end?400:402, pan=ease(0,end?7.45:18.24,u);
  const sunX=skyBreak(c,t,u,p,h,end);
  c.save(); camera(c,648+(end?-23:73)*pan,357+18*pan,1.01+(end?.061:.10)*pan);
  distantLand(c,h+14,'#6c8980',u*4,106,750);
  distantLand(c,h+21,'#436968',-u*3,65,451);
  water(c,end?'#a4a388':'#7d9992',end?'#365c61':'#274c60',h+4,t,p.k,
    ['#a1a88c91','#294a5888','#d5bd8a67','#50766f9a','#fce2a5b0'],sunX,.7);
  const shore=end ? [[-170,539],[79,557],[153,540],[275,532],[369,546],[402,570],[376,583],[210,631],[-81,690],[-170,745]] :
    [[-170,601],[77,569],[179,548],[285,526],[365,531],[395,550],[326,580],[136,630],[-170,712]];
  polygon(c,end?'#3b5c50':'#365650',shore);
  line(c,'#a0a487b9',2.4,...shore.slice(0,shore.length-1));
  let r=random(957);
  for(let j=0;j<245;j++){
    const x=-102+r()*510,y=553+r()*186, boundary=552+(392-x)*.27;
    if (y>boundary-15 || y<556+(392-x)*.06){
      if (x<356-(y-550)*1.43 || x<70) {
        const d=3+r()*8;
        line(c,j%2?'#a6a57856':'#233c3b76',.9,[x,y],[x+d,y-1],[x+d*1.5,y-2]);
      }
    }
  }
  const x=end?237-197*pan:252+43*ease(0,8,u), y=end?559+47*pan:575-18*ease(0,8,u);
  traveler(c,x,y,end?.85+pan*.06:.98,end?-1:1,t,p.voice,end?.79:.30*(1-ease(3,8,u)),false,.83);
  const bx=end?830+200*pan:466+358*pan, by=end?481-28*pan:547-62*pan;
  rings(c,t,p.since,[[bx,by,125], [672,501,120],[911,527,110],[760,624,166],[532,569,100]],'245,222,161');
  boat(c,bx,by,end?.32-.10*pan:.61-.27*pan,t,p.k,true);
  c.restore();
  reeds(c,t,0,108,'#233f38ac',199,p.voice);
  reeds(c,t,1,103,'#284940bc',201,p.voice);
  if(!end) rain(c,t,Math.round(78*(1-pan)+8),.67,.42,'227,229,190');
}

function farShore(c,t,u,p) {
  const travel=ease(0,7.43,u), horizon=352;
  c.fillStyle=gradient(c,0,0,0,455,'#41665e','#94ab91','#ead8a0');
  c.fillRect(0,0,W,H);
  const sunX=804, sunY=304;
  glow(c,sunX,sunY,482,'#fff2bcc9','#f1d89565','#f1d89500');
  oval(c,'#fff0ba',sunX,sunY,65,65);
  for(let i=0;i<7;i++){
    const x=210+i*162+u*(5+i*.3), y=86+i*30+Math.sin(i*11)*38;
    oval(c,i%3?'#fbdf9e31':'#597f7945',x,y,115+i*11,5+i%3*5,-.032);
  }
  c.save(); camera(c,622-15*travel,357-5*travel,1.04+.055*travel);
  distantLand(c,373,'#799485',u*4,64,86);
  water(c,'#9ba98b','#36574f',horizon+8,t,p.k,
    ['#b1b48b7a','#5b7f729a','#e4ca9168','#315d5e76','#fce8b4b3'],sunX,.39);
  const quay=[[-155,412],[120,459],[461,546],[643,577],[308,745],[-155,810]];
  polygon(c,gradient(c,0,445,300,694,'#6e7760','#43544a','#253e3a'),quay);
  line(c,'#b5ae7eaa',2.4,[-155,413],[120,459],[461,546],[643,577]);
  line(c,'#98a38976',1.5,[628,582],[295,741]);
  const rng=random(492);
  for(let i=0;i<137;i++){
    const x=rng()*748-130, y=rng()*316+423;
    if(y>437+x*.234 && y<827-x*.382) {
      const n=rng()*28+4;
      line(c,i%4===0?'#c2b77d66':'#263e3972',1,[x,y],[x+n*.52,y+3],[x+n,y+3]);
    }
  }
  for(const [x,y,s] of [[553,578,.82],[339,532,.75],[88,473,.53]]) {
    polygon(c,'#385149',[[x-4*s,y-25*s],[x+7*s,y-27*s],[x+7*s,y],[x-4*s,y+2*s]]);
    line(c,'#c0ad81',1,[x-5*s,y-25*s],[x+7*s,y-27*s]);
  }
  const x=365-458*travel, y=561-106*travel;
  traveler(c,x,y,1.43-travel*.31,-1,t,p.voice,.55+.43*travel,false,.47);
  const bx=682+273*travel, by=480-54*travel;
  rings(c,t,p.since,[[bx,by,138],[1030,531,155],[854,606,210]],'244,225,177');
  boat(c,bx,by,.49-.29*travel,t,p.k,true);
  c.restore();
  reeds(c,t,0,107,'#243d37cd',714,p.voice);
  reeds(c,t,1,67,'#324c3e91',79,p.voice);
}

module.exports = { crossing, openWater, farShore };
