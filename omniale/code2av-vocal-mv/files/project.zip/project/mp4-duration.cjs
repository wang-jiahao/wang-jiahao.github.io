const fs = require('node:fs');

function boxes(buffer, begin, end) {
  const children = [];
  for (let offset = begin; offset + 8 <= end;) {
    const tag = buffer.toString('ascii', offset + 4, offset + 8);
    const size = buffer.readUInt32BE(offset);
    const header = size === 1 ? 16 : 8;
    const length = size === 1 ? Number(buffer.readBigUInt64BE(offset + 8)) : size || end - offset;
    if (!Number.isSafeInteger(length) || length < header || offset + length > end) {
      throw new Error(`Invalid MP4 box ${tag} at ${offset}`);
    }
    children.push({ tag, begin: offset + header, end: offset + length });
    offset += length;
  }
  return children;
}

function normalizeMovieDuration(input, output, seconds) {
  const buffer = fs.readFileSync(input);
  const children = ({begin, end}) => boxes(buffer, begin, end);
  const one = (parent, tag) => {
    const box = children(parent).find(child => child.tag === tag);
    if (!box) throw new Error(`MP4 box ${tag} missing`);
    return box;
  };
  const movie = one({begin:0,end:buffer.length}, 'moov');
  const header = one(movie, 'mvhd').begin;
  const wide = buffer[header] === 1;
  const timescale = buffer.readUInt32BE(header + (wide ? 20 : 12));
  const duration = BigInt(timescale * seconds);
  const tracks = children(movie).filter(({tag}) => tag === 'trak');
  if (tracks.length !== 2) throw new Error('Expected video and audio tracks');

  function setDuration(offset, isWide) {
    if (isWide) buffer.writeBigUInt64BE(duration, offset);
    else buffer.writeUInt32BE(Number(duration), offset);
  }

  // Track edits already encode playback duration, including the AAC priming skip.
  for (const track of tracks) {
    const edit = one(one(track, 'edts'), 'elst').begin;
    const editWide = buffer[edit] === 1;
    const entryCount = buffer.readUInt32BE(edit + 4);
    let edited = 0n;
    for (let i = 0; i < entryCount; i++) {
      const offset = edit + 8 + i * (editWide ? 20 : 12);
      edited += editWide ? buffer.readBigUInt64BE(offset) : BigInt(buffer.readUInt32BE(offset));
    }
    if (edited !== duration) throw new Error(`Unexpected track edit duration ${edited}/${timescale}`);
    const trackHeader = one(track, 'tkhd').begin;
    const trackWide = buffer[trackHeader] === 1;
    setDuration(trackHeader + (trackWide ? 28 : 20), trackWide);
  }
  setDuration(header + (wide ? 24 : 16), wide);
  fs.writeFileSync(output, buffer);
}

module.exports = { normalizeMovieDuration };
