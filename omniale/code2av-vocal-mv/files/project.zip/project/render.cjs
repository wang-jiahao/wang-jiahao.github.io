const fs = require('node:fs');
const path = require('node:path');
const { spawn, spawnSync } = require('node:child_process');
const { once } = require('node:events');
const { createCanvas } = require('../../.rainfall-tools/node_modules/@napi-rs/canvas');
const { W,H,clamp,ease,gradient,line,grain } = require('./draw.cjs');
const { floodgate,crookedFrame } = require('./storm.cjs');
const { correspondence } = require('./letter.cjs');
const { crossing,openWater,farShore } = require('./coast.cjs');
const { normalizeMovieDuration } = require('./mp4-duration.cjs');

const root = path.resolve(__dirname,'../..');
const work = path.join(root,'.rainfall-work');
const output = path.join(root,'submission');
const pixels = [1920,1080];
const fps = 30;
const frames = 2700;
const chapters = [floodgate,crookedFrame,correspondence,crossing,openWater,farShore];

function filmType(c,t,u,p,chapter,timeline) {
  c.save();
  if(t<6.68){
    const alpha=ease(.55,1.5,t)*(1-ease(5.72,6.62,t));
    c.globalAlpha=alpha;
    c.textAlign='left';
    c.fillStyle=gradient(c,0,0,705,0,'#102630a6','#1026305a','#10263000');
    c.fillRect(0,140,705,258);
    const rise=(1-ease(.44,1.83,t))*12;
    c.fillStyle='#f4e4c3'; c.font='63px Georgia, serif';
    c.fillText('Watching the',90,254+rise);
    c.font='italic 85px Georgia, serif'; c.fillText('Rain Fall',87,338+rise);
    line(c,'#e7b381',1.2,[91,365+rise],[166,365+rise]);
  } else if (chapter>0 && u<3.55) {
    c.globalAlpha=ease(.14,.63,u)*(1-ease(2.41,3.55,u));
    c.fillStyle=gradient(c,0,0,422,0,'#14232bd0','#14232b47','#14232b00');
    c.fillRect(0,51,422,55);
    line(c,'#e2ac79',1.15,[64,80],[91,80]);
    c.fillStyle='#f1deb9'; c.font='italic 23px Georgia, serif';
    c.fillText(timeline.scenes[chapter].caption,105,87);
  }
  c.restore();
  const cue=timeline.cues.findLast(item => t>=item.start && t<item.end+.13)
    ?? timeline.cues.find(item => t>=item.start-.22 && t<item.start);
  if(!cue) return;
  const alpha=ease(cue.start-.22,cue.start+.02,t)*(1-ease(cue.end-.03,cue.end+.13,t));
  c.save(); c.globalAlpha=alpha;
  c.fillStyle=gradient(c,0,556,0,720,'#0a141b00','#0a141b8e','#09151ce4');
  c.fillRect(0,556,W,164);
  c.font=cue.words.length>10?'34px Georgia, serif':'37px Georgia, serif';
  c.textBaseline='alphabetic';
  const gap=c.measureText(' ').width+2;
  const widths=cue.words.map(([word])=> c.measureText(word).width);
  const total=widths.reduce((a,b)=>a+b,0)+(widths.length-1)*gap;
  if(total>W-120) throw new Error(`Caption too wide at ${t}: ${total}`);
  let x=(W-total)/2;
  for(const [i,[word,start,end]] of cue.words.entries()){
    const on=t>=start && t<end;
    const previous=t>=end;
    c.fillStyle=on?'#fff2cf':previous?'#deded2':'#c7d0cc';
    if(on){
      const progress=clamp((t-start)/Math.min(.31,end-start));
      line(c,'#e9ae83',1.5,[x,681],[x+widths[i]*ease(0,1,progress),681]);
    }
    c.fillText(word,x,670);
    x+=widths[i]+gap;
  }
  c.restore();
}

function draw(context,index,timeline) {
  const t = index / fps;
  const chapter = timeline.scenes.findIndex(({end})=>t<end);
  const heading = timeline.scenes[chapter];
  const u = t - heading.start;
  const lastBeat = timeline.beats.findLastIndex(([beat])=>beat<=t);
  const [at, down] = timeline.beats[Math.max(0,lastBeat)];
  const since = Math.max(0,t-at);
  const p = { voice:timeline.vocal[index],k:Math.exp(-since*8)*(down?1:.57),since };
  context.save();
  context.setTransform(pixels[0]/W,0,0,pixels[1]/H,0,0);
  chapters[chapter](context,t,u,p);
  grain(context);
  filmType(context,t,u,p,chapter,timeline);
  const edit=chapter>0?.31*(1-ease(0,.34,u)):0;
  const cut=chapter<chapters.length-1?.16*ease(heading.end-.13,heading.end,t):0;
  const fade=Math.max(1-ease(0,.52,t),ease(89.33,89.99,t),edit,cut);
  if(fade>.001){
    context.fillStyle=`rgba(13,22,27,${fade})`;
    context.fillRect(0,0,W,H);
  }
  context.restore();
}

function ffmpeg(args, options={}) {
  const command = spawnSync('ffmpeg',['-hide_banner','-loglevel','error','-nostdin','-y',...args],
    {cwd:work,stdio:'inherit',...options});
  if(command.error) throw command.error;
  if (command.status!==0) throw new Error(`ffmpeg exited ${command.status}`);
}

function loadTimeline() {
  return JSON.parse(fs.readFileSync(path.join(work,'timeline.json'),'utf8'));
}

async function chunk(first,last,dest) {
  const canvas = createCanvas(...pixels);
  const context = canvas.getContext('2d');
  const timeline = loadTimeline();
  const proc=spawn('ffmpeg', ['-hide_banner','-loglevel','error','-nostdin','-y', '-f','rawvideo',
    '-pixel_format','rgba','-video_size',pixels.join('x'),'-framerate',`${fps}`,'-i','pipe:0',
    '-an','-vf','scale=in_range=pc:out_range=tv:out_color_matrix=bt709',
    '-c:v','libx264','-preset','veryfast','-crf','17','-pix_fmt','yuv420p',
    '-color_range','tv','-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709',
    '-threads','2','-filter_threads','1','-g','60','-video_track_timescale','30000',
    dest], {cwd:work,stdio:['pipe','inherit','inherit']});
  const complete=once(proc,'close');
  try {
    for(let i=first;i<last;i++){
      draw(context,i,timeline);
      if(!proc.stdin.write(canvas.data())) await once(proc.stdin,'drain');
    }
    proc.stdin.end();
    const [code]=await complete;
    if(code!==0) throw new Error(`Segment ${first}-${last} failed with status ${code}`);
  } catch(error) {
    proc.stdin.destroy(); proc.kill();
    await complete.catch(()=>{});
    throw error;
  }
  console.log(`Rendered ${first}-${last-1}`);
}

async function fullFilm() {
  const jobs = [];
  for(let first=0;first<frames;first+=450){
    const file=`segment-${first}.mp4`;
    jobs.push([first,Math.min(frames,first+450),file]);
  }
  let cursor=0;
  const workers=Array.from({length:Math.min(3,jobs.length)},async()=>{
    while(cursor<jobs.length){
      const [first,last,file]=jobs[cursor++];
      const worker=spawn(process.execPath,[__filename,'chunk',first,last,file],{stdio:'inherit'});
      const [code]=await once(worker,'close');
      if(code!==0) throw new Error(`Renderer exited ${code} at frame ${first}`);
    }
  });
  const result=await Promise.allSettled(workers);
  for(const entry of result) if(entry.status==='rejected') throw entry.reason;
  const list=path.join(work,'segments.txt');
  fs.writeFileSync(list,jobs.map(([, ,file])=>`file '${file}'`).join('\n')+'\n');
  const temp=path.join(work,'finished.mp4');
  ffmpeg(['-f','concat','-safe','1','-i',list,'-i',path.join(output,'mix.wav'),'-map','0:v:0','-map','1:a:0',
    '-c:v','copy','-c:a','aac','-b:a','320k','-ar','48000','-ac','2','-movflags','+faststart',
    '-metadata','title=Watching the Rain Fall',temp]);
  normalizeMovieDuration(temp,path.join(output,'mv.mp4'),frames/fps);
  fs.unlinkSync(temp);
  fs.unlinkSync(list);
  for(const [,,file] of jobs) fs.unlinkSync(path.join(work,file));
}

function stills() {
  const c=createCanvas(...pixels);
  const ctx=c.getContext('2d');
  const timeline=loadTimeline();
  for(const t of [3,8,15.1,26,38.4,45.7,47.9,53.7,62.9,67.6,79.4,86.5,89.6]){
    draw(ctx,Math.round(t*fps),timeline);
    fs.writeFileSync(path.join(work,`still-${t}.png`),c.toBuffer('image/png'));
  }
}

async function main() {
  const [mode,...arg]=process.argv.slice(2);
  if(mode==='chunk') await chunk(Number(arg[0]),Number(arg[1]),arg[2]);
  else if(mode==='stills') stills();
  else if(!mode) await fullFilm();
  else throw new Error(`Unexpected render mode: ${mode}`);
}

main().catch(error=>{console.error(error);process.exitCode=1;});
