"""Author the score, synthesize isolated stems, and master at 48 kHz."""
from concurrent.futures import ThreadPoolExecutor
import json
import math
from pathlib import Path
import re
import struct
import subprocess

import numpy as np
import soundfile as sf
from scipy import ndimage, signal

from analyze import PROJECT, ROOT, WORK, analyze

OUT = PROJECT.parent
FS = 48000
LENGTH = FS * 90
SCORE = json.loads((PROJECT / 'score.json').read_text(encoding='utf8'))
BARS = SCORE['barlines']
# Bass register, then parsimoniously voiced piano/guitar upper structure.
CHORD = {
    'Abadd9': (32, [51, 56, 58, 60, 63]), 'Eb/G': (31, [51, 55, 58, 63]),
    'Db6': (37, [49, 53, 56, 58, 65]), 'Bbm9': (34, [53, 56, 60, 61, 65]),
    'Eb7sus': (39, [49, 53, 56, 58, 63]), 'Dbmaj9': (37, [53, 56, 60, 63, 65]),
    'Ab/Eb': (39, [51, 56, 60, 63, 68]), 'Fm9': (29, [53, 56, 60, 63, 67]),
    'Ab/C': (36, [51, 56, 58, 60, 68]),
}
# GM programs are zero based. Drums use channel 10.
INSTR = {
    'piano': (0, 57, 'Upright piano KW'),
    'guitar': (24, 83, 'FluidR3 nylon guitar'),
    'bass': (33, 64, 'FluidR3 fingered bass'),
    'cello': (42, 53, 'FluidR3 cello'),
    'strings': (49, 70, 'FluidR3 slow string ensemble'),
    'celesta': (8, 77, 'FluidR3 celesta'),
    'drums': (None, 64, 'FluidR3 acoustic percussion'),
}
MIX = {
    'piano': (-24.1, 80, 0.90, 0.082), 'guitar': (-32.7, 132, 0.86, 0.12),
    'bass': (-24.8, 39, 0.0, 0.016), 'cello': (-32.6, 91, 0.70, 0.12),
    'strings': (-29.8, 155, 0.98, 0.17), 'celesta': (-35.5, 170, 0.88, 0.19),
    'drums': (-26.8, 37, 0.77, 0.045),
}


def beat_grid():
    sections = []
    for bar, (start, end) in enumerate(zip(BARS, BARS[1:])):
        count = 5 if bar == SCORE['extra_beat_bar'] else 4
        row = np.linspace(start, end, count + 1)
        for beat in range(1, count):
            row[beat] += SCORE['distinguished_beats'].get(str(sum(len(s)-1 for s in sections) + beat), 0)
        sections.append(row)
    return sections


def write_midi(dest, instrument, notes):
    program, pan, _ = INSTR[instrument]
    channel = 9 if program is None else 0
    events = [(0, 0, b'\xff\x51\x03\x0f\x42\x40'),
              (0, 0, bytes((0xB0 | channel, 10, pan)))]
    if program is not None:
        events.append((0, 0, bytes((0xC0, program))))
    for start, end, pitch, velocity in notes:
        events.extend([(round(start * 1000), 2, bytes((0x90 | channel, pitch, velocity))),
                       (round(end * 1000), 1, bytes((0x80 | channel, pitch, 0)))])
    events.append((90600, 3, b'\xff\x2f\x00'))

    def varlen(n):
        out = [n & 127]
        while n > 127:
            n >>= 7
            out.insert(0, (n & 127) | 128)
        return bytes(out)

    track, previous = bytearray(), 0
    for time, _, message in sorted(events):
        track.extend(varlen(time - previous) + message)
        previous = time
    dest.write_bytes(struct.pack('>4sIHHH4sI', b'MThd', 6, 0, 1, 1000, b'MTrk', len(track)) + track)


def compose(grid):
    rng = np.random.default_rng(2706)
    notes = {name: [] for name in INSTR}
    for bar, chord in enumerate(SCORE['harmony']):
        bass, upper = CHORD[chord]
        b = grid[bar]
        slots = np.arange(len(b))
        verse, pre, hook, coda = 2 <= bar < 10, 10 <= bar < 14, 14 <= bar < 24, bar >= 24
        lift = 0 if bar < 10 else (min(8, (bar-9)*2) if pre else (12 if hook else 3))

        def note(ins, offset, length, pitch, velocity, jitter=0.009):
            start = np.interp(offset, slots, b) + rng.uniform(-jitter, jitter)
            end = np.interp(offset+length, slots, b)
            if offset+length > slots[-1]:
                end += (offset+length-slots[-1]) * (b[-1]-b[-2])
            if start < 89.4:
                notes[ins].append((max(0, start), min(89.87, max(start+0.035, end)),
                                   pitch, int(np.clip(velocity+rng.integers(-3,4), 1,127))))

        if bar != 26:
            note('piano', 0, 2.65, bass+12, 55+lift)
            if hook:
                note('piano', 0.018, 1.42, bass+24, 53+lift)
        patterns = ((0.04,0),(0.51,2),(1.03,3),(1.58,1),(2.03,4),(2.54,2),(3.08,3),(3.55,2))
        if verse and bar % 2:
            patterns = ((0.12,1),(0.63,0),(1.49,2),(2.08,3),(2.74,1),(3.43,2))
        if bar in (0, 1, 9, 13, 23, 24, 25):
            patterns = patterns[:6] if bar not in (23, 25) else patterns[:4]
        if bar == 26:
            patterns = ((0, 2),)
        for j,(offset,index) in enumerate(patterns):
            pitch = upper[index % len(upper)]
            note('piano', offset, 0.89 if not hook else 1.16, pitch,
                 47+lift+(5 if j in (0,3) else 0))
            if hook and offset in (0.04, 2.03) and j != 0:
                note('piano',offset+0.022,1.36,upper[1],49+lift)
        if bar in (0,1,6,9,12,13,15,18,20,22,25):
            for offset, index in ((2.63, 2),(3.25, 3),(3.67, 1)):
                if bar != 25 or offset < 3:
                    note('celesta', offset, .47, upper[index]+12, 44 + lift)
        if (verse and bar >= 3) or pre or hook:
            for j,offset in enumerate((.52,1.49,2.48,3.54) if hook else (.56,1.66,2.62,3.53)):
                for k in range(2 if hook else 1):
                    note('guitar', offset + 0.024*k, .37+(j%2)*.17,
                         upper[(j+k+1)%len(upper)], 51+lift-4*k)
        if (verse and bar >= 6) or pre or hook or bar in (24,25):
            note('bass', 0, 1.7 if hook else 2.85, bass, 69+lift)
            if pre or hook:
                note('bass', 2, 0.9, bass+(12 if bar % 2 else 0), 64+lift)
                if bar % 3 != 0:
                    note('bass', 3.48, 0.41, bass, 54+lift)
        if bar in (4,5,8,9) or (bar >= 10 and bar < 26):
            note('cello', .06 if bar >= 10 else 1.38, 2.76 if bar >= 10 else 2.05,
                 bass+12, 48+lift)
            if bar in (9, 11, 12, 13, 17, 19, 21, 24, 25):
                note('cello', 2.95, 1.08, upper[0], 44+lift)
        if pre or hook or bar in (24,25):
            for k, pitch in enumerate(upper[1:4]):
                note('strings', 0.01+0.084*k, len(b)-1-(0.15+0.072*k), pitch+12, 40+lift+2*k)
        if 5 <= bar < 25:
            if hook:
                for offset in ((0,1.52,2.57) if bar % 2 else (0,1.77,2.48,3.49)):
                    note('drums',offset, .14, 36, (79 if offset==0 else 60)+(3 if bar>=18 else 0))
                for offset in (1.02,3.02):
                    note('drums',offset,.16,38 if bar>=16 else 37,67 if offset>2 else 62)
            elif bar != 24:
                note('drums',0,.15,36, 46 if verse else 59)
                if bar != 13:
                    note('drums',2.05,.17,37, 41 if verse else 50)
            for offset in ((0.5,1,1.5,2,2.5,3,3.5) if hook else (.53,2.57,3.51)):
                if bar < 24:
                    note('drums',offset,.09,42, (52 if hook else 37)+(3 if int(offset)==offset else 0))
            if bar in (13,17,21):
                for j,offset in enumerate((2.5,3.0,3.5,3.75)):
                    note('drums',offset,.15,(45,47,48,38)[j],54+4*j)
            if bar in (14,18,22):
                note('drums',0,.4,49,66+(3 if bar==18 else 0))
    return notes


def render_stem(name, notes):
    sf_dir = ROOT/'input/runtime/audio'
    sf2 = 'UprightPianoKW-20220221.sf2' if name=='piano' else 'FluidR3_GM.sf2'
    midi, wav = (WORK / (name + '.' + kind) for kind in ('mid', 'wav'))
    write_midi(midi, name, notes)
    subprocess.run([str(sf_dir/'fluidsynth.exe'), '-ni', '-R', '0', '-C', '0', '-F',
                    str(wav), '-r', str(FS), '-g', '1.0', '-O', 'float', str(sf_dir/sf2), str(midi)],
                   check=True, stdout=subprocess.DEVNULL)
    data, rate = sf.read(wav, dtype='float32', always_2d=True)
    assert rate == FS and len(data)>=LENGTH
    return name, data[:LENGTH].copy()


def db_gain(db):
    return 10 ** (db/20)


def shelf(x, center, gain, q):
    a = db_gain(gain)
    w = 2*np.pi*center/FS
    d = np.sin(w)/(2*q)
    return signal.lfilter(np.array([1+d*a,-2*np.cos(w),1-d*a]) / (1+d/a),
                          np.array([1+d/a,-2*np.cos(w),1-d/a]) / (1+d/a), x, axis=0).astype('float32')


def filter_audio(x, frequency, kind):
    return signal.sosfilt(signal.butter(2, frequency, btype=kind, fs=FS, output='sos'),
                          x, axis=0).astype('float32')


def levels(x, frame=2400):
    return 20*np.log10(np.maximum(1e-8, np.sqrt(np.mean(x[:len(x)//frame*frame].reshape(-1, frame, 2)**2, axis=(1,2)))))


def balance(x, target):
    lv = levels(x)
    active = lv > max(-83, np.max(lv)-31)
    return x * db_gain(target-np.percentile(lv[active], 61))


def room(audio, seed, decay):
    rng = np.random.default_rng(seed)
    n = round(FS * decay)
    ir = np.zeros((n, 2), dtype=np.float32)
    for ch in (0,1):
        taps = np.r_[np.array([.024,.039,.057,.067,.091,.118])+ch*.006, rng.uniform(.09,decay-.003,115)]
        taps = np.rint(taps*FS).astype(int)
        ir[taps,ch] += rng.choice([-1,1],len(taps))*np.exp(-taps/n*6.6)
    ir = filter_audio(filter_audio(ir, 320, 'highpass'), 5000, 'lowpass')
    ir *= .8 / np.sqrt(np.sum(ir**2,axis=0)).max()
    return signal.oaconvolve(audio*.72+audio[:,::-1]*.28, ir, axes=0)[:len(audio)].astype('float32')


def measure(path):
    result = subprocess.run(['ffmpeg','-hide_banner','-nostats','-i',str(path),'-af',
                             'loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json','-f','null','-'],
                             capture_output=True,text=True,check=True)
    return json.loads(re.findall(r'\{[^{}]+\}',result.stderr)[-1])


def limit(audio, gain):
    oversampled = signal.resample_poly(audio, 4, 1, axis=0)
    peaks = np.max(abs(oversampled).reshape(-1,192,2), axis=(1,2))
    block_db = 20*np.log10(np.maximum(1e-9,peaks)) + gain
    required = np.maximum(0, block_db + 1.68)
    attenuation = np.maximum(np.r_[0,required], np.r_[required,0])
    for i in range(len(attenuation)-2,-1,-1):
        attenuation[i] = max(attenuation[i], attenuation[i+1] - 1.24)
    for i in range(1,len(attenuation)):
        attenuation[i] = max(attenuation[i], attenuation[i-1] - .084)
    sample_db = np.interp(np.arange(len(audio)),np.arange(len(attenuation))*48, gain-attenuation)
    return audio*db_gain(sample_db[:,None])


def master(accomp):
    fade = np.linspace(1, 0, round(FS*.72), dtype='float32')**1.6
    accomp[-len(fade):] *= fade[:,None]
    sf.write(OUT/'accompaniment.wav', limit(accomp,0), FS, 'PCM_24')
    v, rate = sf.read(ROOT/'input/vocals.wav', always_2d=True,dtype='float32')
    assert rate==FS and len(v)==LENGTH
    v = shelf(shelf(filter_audio(v, 72, 'highpass'), 305, -.9, .83), 2480, .64, .89)
    db = levels(v)
    sm = ndimage.gaussian_filter1d(db, 1.7)
    gains = np.clip(-0.39*np.maximum(sm+29, 0) + .18*np.maximum(-29-sm,0)*(sm>-45),-7,2.3)
    env = np.interp(np.arange(len(v)), np.arange(len(gains))*2400+1200, gains).astype('float32')
    v = balance(v*db_gain(env[:,None]), -21.0)
    mix = v + room(v, 725, .89)*.088 + accomp*.83
    mix[-len(fade):] *= np.linspace(1,0,len(fade),dtype='float32')[:,None]**.42
    premaster = WORK/'premaster.wav'
    sf.write(premaster, mix, FS, 'FLOAT')
    initial = measure(premaster)
    gain = -14-float(initial['input_i'])
    for _ in range(4):
        sf.write(OUT/'mix.wav',limit(mix,gain),FS,'PCM_24')
        measured = measure(OUT/'mix.wav')
        delta = -14-float(measured['input_i'])
        if abs(delta)<.07:
            break
        gain += delta
    return {k:float(measured['input_'+k]) for k in ('i','tp','lra')}, gain


def export_timeline(grid, stats, gain):
    lines = [line.strip().split() for line in (ROOT/'input/lyrics.txt').read_text(encoding='utf8').splitlines() if line.strip()]
    assert len(lines)==len(SCORE['lyric_cues'])
    cues = []
    for words, (end, *starts) in zip(lines, SCORE['lyric_cues'], strict=True):
        assert len(words)==len(starts) and all(a<b for a,b in zip(starts, starts[1:]+[end]))
        cues.append({'start':starts[0], 'end':end, 'words':list(zip(words,starts,starts[1:]+[end]))})
    features = np.load(WORK/'vocal_features.npz')
    env = np.clip((ndimage.gaussian_filter1d(features['db'], 4)+55)/34, 0, 1)**1.45
    vocal = np.interp(np.arange(2700)/30, np.arange(len(env))/100, env)
    beats = [(round(float(t),4),i==0) for row in grid for i,t in enumerate(row[:-1]) if t<90]
    sections = SCORE['sections']
    for s in sections:
        s['chords'] = [c for time,c in zip(BARS,SCORE['harmony']) if s['start_s']-.35<=time<s['end_s']]
    bpm = np.concatenate([60/np.diff(row) for row in grid])
    measured_notes = json.loads((WORK/'note_events.json').read_text(encoding='utf8'))
    notes = {'key': SCORE['key'],
             'bpm': {'nominal': round(float(np.median(bpm)), 2), 'local_range': [round(float(bpm.min()),2),round(float(bpm.max()),2)],
                     'meter':'4/4; a five-quarter cadential extension in the pre-chorus arrangement',
                     'method':'Phrase/pulse anchors from dry-vocal transcription; local bar lengths and interior beat nudges. Meter is an inference.'},
             'analysis': {'pitch_class_frames':measured_notes['pitch_class_frames'],
                          'lyric_alignment':'Estimated word boundaries from lyric order, pitch, energy, spectral flux, and breath gaps.',
                          'barlines_s':BARS[:-1]},
             'sections':sections,'instruments':[v[2] for v in INSTR.values()],
             'lyric_cues':cues, 'beat_grid_s':[t for t,_ in beats],
             'mix':{'integrated_lufs':stats['i'],'true_peak_dbtp':stats['tp'],'loudness_range_lu':stats['lra'],
                    'master_gain_db':round(gain,2)}}
    (OUT/'arrangement_notes.json').write_text(json.dumps(notes,indent=2)+'\n',encoding='utf8')
    (WORK/'timeline.json').write_text(json.dumps({'cues':cues,'scenes':SCORE['scenes'],'beats':beats,
                                                'vocal':np.round(vocal,3).tolist()},separators=(',',':')),encoding='utf8')


def main():
    from analyze import summarize

    if not (WORK/'vocal_features.npz').exists() or not (WORK/'note_events.json').exists():
        summarize(*analyze())
    grid = beat_grid()
    with ThreadPoolExecutor(max_workers=4) as pool:
        stems = dict(pool.map(lambda item: render_stem(*item), compose(grid).items()))
    bus = np.zeros((LENGTH,2), dtype='float32')
    send = np.zeros_like(bus)
    for name, (target, hp, width, wet) in MIX.items():
        x = filter_audio(stems.pop(name), hp, 'highpass')
        x = shelf(x, 2200, -2.1 if name!='bass' else -1.3, .72)
        mid = x.mean(axis=1, keepdims=True)
        x = balance(mid+(x-mid)*width, target)
        bus += x
        send += x*wet
    bus += room(send, 557, 1.28)
    stats, gain = master(bus)
    export_timeline(grid, stats, gain)
    print('Master:', stats, 'gain:', round(gain,2))


if __name__=='__main__':
    main()
