"""Verify the packaged streams and compare the AAC packets with a fresh encode."""
import json
import subprocess
from fractions import Fraction

import numpy as np
from scipy import signal
import soundfile as sf

from music import LENGTH, FS, OUT, ROOT, WORK, measure, levels


def run(tool, *args):
    return subprocess.check_output([tool, *map(str, args)], text=True)


def probe(path, *args):
    return json.loads(run('ffprobe', '-v', 'error', *args, '-of', 'json', path))


def wav(name):
    path = OUT / name
    info = sf.info(path)
    assert (info.samplerate, info.channels, info.frames, info.subtype) == (FS, 2, LENGTH, 'PCM_24'), info
    x, _ = sf.read(path, dtype='float32')
    assert np.isfinite(x).all() and abs(x).max() < .999
    loudness = measure(path)
    assert float(loudness['input_tp']) <= -1.0, loudness
    return x, {k:float(loudness[f'input_{k}']) for k in ('i','tp','lra')}


def vocal_alignment(mix):
    dry, _ = sf.read(ROOT/'input'/'vocals.wav', dtype='float32', always_2d=True)
    sos = signal.butter(3, (1100, 3800), 'bandpass', fs=FS, output='sos')
    ref = signal.sosfilt(sos, dry.mean(axis=1))[::6].reshape(-1,4000)
    test = signal.sosfilt(sos, mix.mean(axis=1))[::6].reshape(-1,4000)
    energy = np.linalg.norm(ref, axis=1)
    lags, correlations = [], []
    for a,b in zip(ref[energy>np.quantile(energy,.63)], test[energy>np.quantile(energy,.63)], strict=True):
        corr = signal.correlate(b,a,mode='full',method='fft')
        center = len(a)-1
        small = corr[center-16:center+17]
        lags.append(int(np.argmax(small))-16)
        correlations.append(float(np.max(small)/(np.linalg.norm(a)*np.linalg.norm(b))))
    assert abs(np.median(lags)) <= 1 and np.median(correlations) > .70, (lags, correlations)
    return {'median_offset_ms':float(np.median(lags))*.125,
            'median_correlation':round(float(np.median(correlations)),3)}


def packet_hash(file):
    return run('ffmpeg','-v','error','-i',file,'-map','0:a:0','-c:a','copy',
               '-f','hash','-hash','sha256','-').strip()


def video():
    WORK.mkdir(exist_ok=True)
    movie = OUT/'mv.mp4'
    info = probe(movie, '-show_streams', '-show_format')
    v,a = info['streams']
    assert (v['codec_name'], v['width'], v['height'], v['pix_fmt']) == ('h264',1920,1080,'yuv420p'), v
    assert (v['avg_frame_rate'], v['r_frame_rate'], int(v['nb_frames'])) == ('30/1','30/1',2700), v
    assert (a['codec_name'], a['sample_rate'], a['channels']) == ('aac','48000',2), a
    for stream in (v,a,info['format']):
        assert Fraction(stream['start_time']) == 0 and Fraction(stream['duration']) == 90, stream
    frames = probe(movie,'-select_streams','v:0','-show_frames','-show_entries',
                   'frame=best_effort_timestamp')['frames']
    step = Fraction(1,30) / Fraction(v['time_base'])
    assert [int(f['best_effort_timestamp']) for f in frames] == [i*step for i in range(2700)]
    ref = WORK/'verify-direct.m4a'
    try:
        run('ffmpeg','-v','error','-y','-i',OUT/'mix.wav','-c:a','aac','-b:a','320k','-ar','48000','-ac','2',ref)
        digest = packet_hash(movie)
        assert digest == packet_hash(ref), 'AAC payload does not match a standalone encode of mix.wav'
    finally:
        ref.unlink(missing_ok=True)
    return {'frames':len(frames), 'duration':info['format']['duration'], 'direct_aac_packets':digest}


def main():
    accompaniment, accom_stats = wav('accompaniment.wav')
    mix, mix_stats = wav('mix.wav')
    assert abs(mix_stats['i']+14)<.25, mix_stats
    print('Accompaniment:', accom_stats,
          'intro RMS:', round(float(np.median(levels(accompaniment[:FS*6]))),1),
          'chorus RMS:', round(float(np.median(levels(accompaniment[FS*50:FS*80]))),1),flush=True)
    print('Mix:', mix_stats, flush=True)
    print('Vocal alignment:', vocal_alignment(mix), flush=True)
    print('Video:', video(), flush=True)


if __name__ == '__main__':
    main()
