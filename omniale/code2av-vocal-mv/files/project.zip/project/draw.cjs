const { createCanvas } = require('../../.rainfall-tools/node_modules/@napi-rs/canvas');

const W = 1280;
const H = 720;
const TAU = Math.PI * 2;
const clamp = (x, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, x));
const mix = (a, b, f) => a + (b - a) * f;
const ease = (a, b, t) => {
  const x = clamp((t - a) / (b - a));
  return x * x * (3 - 2 * x);
};
const mod = (a, b) => ((a % b) + b) % b;

function random(seed) {
  let n = seed >>> 0;
  return () => {
    n = (1664525 * n + 1013904223) >>> 0;
    return n / 4294967296;
  };
}

function gradient(c, x0, y0, x1, y1, ...colors) {
  const g = c.createLinearGradient(x0, y0, x1, y1);
  colors.forEach((v, i) => g.addColorStop(i / (colors.length - 1), v));
  return g;
}

function glow(c, x, y, radius, ...colors) {
  const g = c.createRadialGradient(x, y, 0, x, y, radius);
  colors.forEach((v, i) => g.addColorStop(i / (colors.length - 1), v));
  c.fillStyle = g;
  c.fillRect(x - radius, y - radius, radius * 2, radius * 2);
}

function polygon(c, fill, points) {
  c.beginPath();
  c.moveTo(...points[0]);
  for (const p of points.slice(1)) c.lineTo(...p);
  c.closePath();
  c.fillStyle = fill;
  c.fill();
}

function line(c, color, width, ...points) {
  c.beginPath();
  c.moveTo(...points[0]);
  for (const p of points.slice(1)) c.lineTo(...p);
  c.lineWidth = width;
  c.strokeStyle = color;
  c.stroke();
}

function oval(c, fill, x, y, rx, ry, rotation = 0, stroke = false, width = 1) {
  c.beginPath();
  c.ellipse(x, y, Math.max(.1, rx), Math.max(.1, ry), rotation, 0, TAU);
  if (stroke) {
    c.strokeStyle = fill;
    c.lineWidth = width;
    c.stroke();
  } else {
    c.fillStyle = fill;
    c.fill();
  }
}

function camera(c, x, y, zoom, r = 0) {
  c.translate(W / 2, H / 2);
  c.rotate(r);
  c.scale(zoom, zoom);
  c.translate(-x, -y);
}

const rng = random(9450702);
const particles = Array.from({ length: 520 }, () => Array.from({ length: 6 }, () => rng()));
const grainCanvas = createCanvas(360, 360);
const grainCtx = grainCanvas.getContext('2d');
const grainImage = grainCtx.createImageData(360, 360);
for (let i = 0; i < grainImage.data.length; i += 4) {
  const tint = rng() > .52 ? 245 : 10;
  grainImage.data[i] = tint;
  grainImage.data[i + 1] = tint;
  grainImage.data[i + 2] = tint;
  grainImage.data[i + 3] = rng() * 22;
}
grainCtx.putImageData(grainImage, 0, 0);

function rain(c, t, density, strength = 1, slant = 1, tint = '185,222,223') {
  c.lineCap = 'round';
  for (let band = 0; band < 4; band++) {
    c.beginPath();
    for (let i = band; i < density; i += 4) {
      const [a, b, d, e, f] = particles[i];
      const speed = (330 + d * 670) * strength;
      const y = mod(b * 940 + t * speed, 940) - 100;
      const x = mod(a * 1580 - t * speed * .22 * slant + Math.sin(t + e * 20) * 20, 1580) - 150;
      const h = (10 + f * 37) * strength;
      c.moveTo(x, y);
      c.lineTo(x + h * .25 * slant, y - h);
    }
    c.lineWidth = .6 + band * .27;
    c.strokeStyle = `rgba(${tint},${.08 + band * .05})`;
    c.stroke();
  }
  c.lineCap = 'butt';
}

function water(c, upper, lower, horizon, t, pulse, pal, brightX, calm = 1) {
  c.fillStyle = gradient(c, 0, horizon, 0, H + 100, upper, lower);
  c.fillRect(-180, horizon, W + 360, H + 300 - horizon);
  for (let band = 0; band < 5; band++) {
    c.beginPath();
    for (let i = band; i < 410; i += 5) {
      const [a, b, d, e, f] = particles[i];
      const depth = b ** 1.75;
      const y = horizon + depth * (H - horizon + 110) + Math.sin(t * (1 + e) + i) * (1 + 8 * depth) * calm;
      const x = mod(a * 1560 + (9 + depth * 47) * t + Math.sin(i + t) * d * 17, 1560) - 130;
      const len = (4 + 104 * depth) * (.24 + e) * (1 + pulse * .24);
      if ((band === 4) && Math.abs(x - brightX) > 66 + depth * 310 * f) continue;
      c.moveTo(x, y);
      c.bezierCurveTo(x + len * .28, y - (1 + depth * 3), x + len * .66, y + depth * 2, x + len, y);
    }
    c.lineWidth = band === 4 ? 2 : .85 + band * .37;
    c.strokeStyle = pal[band];
    c.stroke();
  }
}

function rings(c, t, beat, positions, hue) {
  c.save();
  for (let i = 0; i < positions.length; i++) {
    const [x,y,size] = positions[i];
    const p = i === 0 ? clamp(beat / .82) : mod(t * (1.16 + i * .14) + i * .41, 1);
    for (let j = 0; j < 2; j++) {
      const r = Math.max(0, p - j * .18);
      if (r > 0) oval(c, `rgba(${hue},${(1-p)**1.15 * .5})`, x, y, size * r, size * r * .23, .025, true, 1.25);
    }
  }
  c.restore();
}

function distantLand(c, start, color, offset, amp, seed) {
  const r = random(seed);
  const points = [[-260, 770], [-260,start]];
  for (let x = -260; x <= 1580; x += 23) {
    const a = x + offset;
    const y = start - amp * (.43 + .24 * Math.sin(a / 113) + .24 * Math.sin(a / 176 + 2) + .10 * Math.sin(a / 27) + .12 * r());
    points.push([x,y]);
  }
  points.push([1580, 770]);
  polygon(c,color,points);
}

function traveler(c, x, y, size, facing, t, voc, walk, umbrella = false, wind = 1) {
  c.save();
  c.translate(x, y);
  c.scale(size * facing, size);
  const step = Math.sin(t * 6.4) * walk;
  const sway = Math.sin(t * 2.7) * 2.8 * wind;
  const bob = Math.abs(step) * -3;
  oval(c, '#00101362', -3, 1, 25, 4);
  line(c, '#181e24', 7, [-10,-35], [-11+step*7,-16], [-13+step*13,-1]);
  line(c, '#2c2b31', 7, [4,-35], [8-step*6,-18], [9-step*14,-2]);
  line(c, '#151c24', 4, [-15+step*13,-1], [-7+step*13,-1]);
  line(c, '#151c24', 4, [7-step*14,-1], [16-step*14,-2]);
  c.translate(0,bob);
  const coat = gradient(c, -23,-105,25,-34,'#662c36','#bc4e42','#7c3036');
  c.beginPath();
  c.moveTo(-13,-91);
  c.bezierCurveTo(-10,-99,8,-100,14,-89);
  c.lineTo(14,-65); c.lineTo(24+sway,-31); c.quadraticCurveTo(2,-29,-24+sway,-35);
  c.bezierCurveTo(-20,-52,-22,-74,-13,-91);
  c.fillStyle = coat; c.fill();
  polygon(c,'#d46f53a0',[[-12,-92],[-4,-95],[-9,-66],[-18+sway,-36],[-23+sway,-36],[-16,-71]]);
  polygon(c,'#551f2dab',[[0,-86],[7,-90],[16,-62],[23+sway,-32],[8+sway,-32],[4,-60]]);
  line(c, '#d28365a5',1,[-10,-60],[-11+sway*.2,-43]);
  line(c, '#301e28bb',1.15,[1,-85],[4,-59],[8+sway,-33]);
  for (let j=0;j<3;j++) oval(c, '#dab283b0', 3 + j, -78 + j*7, 1.05, 1.05);
  const reach = umbrella ? 15 : 4 + step * 7;
  line(c,'#732c36',8,[11,-86],[15,-73],[reach+10,-66-voc*3]);
  line(c,'#d58b6c',4,[reach+8,-66-voc*3],[reach+12,-68-voc*3]);
  const tilt = -.05 + Math.sin(t*1.5)*.06 - voc*.06;
  c.save(); c.translate(0,-99); c.rotate(tilt);
  oval(c,'#231b29',1,-8,14.5,17,.19);
  polygon(c,'#d59b79',[[1,-22],[11,-18],[11,-14],[15,-10],[11,-7],[11,-1],[3,4],[-5,0],[-6,-13]]);
  polygon(c,'#38262a',[[-10,-20],[-5,-25],[7,-25],[13,-21],[12,-17],[1,-16],[-4,-9],[-9,-7]]);
  line(c,'#381f29',1.05,[8,-7],[11,-7-voc*.7]);
  oval(c,'#41262c',8,-13,1.2,.7);
  c.restore();
  c.beginPath(); c.moveTo(-12,-96); c.quadraticCurveTo(3,-92,11,-99);
  c.lineWidth=6; c.strokeStyle='#d4785b'; c.stroke();
  c.beginPath(); c.moveTo(-9,-95); c.quadraticCurveTo(-19,-82+sway,-28-sway,-85+Math.sin(t*5)*4);
  c.lineWidth=4.2; c.strokeStyle='#c46650'; c.stroke();
  if (umbrella) {
    c.save(); c.translate(25,-67-voc*3); c.rotate(.14 + wind*.035*Math.sin(t*1.7));
    line(c,'#c9b99d',1.1,[0,0],[0,-82]);
    c.beginPath(); c.moveTo(-67,-58); c.quadraticCurveTo(-53,-91,0,-91);
    c.quadraticCurveTo(53,-91,67,-58); c.quadraticCurveTo(43,-67,24,-60);
    c.quadraticCurveTo(0,-66,-23,-60); c.quadraticCurveTo(-43,-68,-67,-58);
    c.fillStyle=gradient(c,-35,-89,39,-61,'#8f3e42','#c06751','#542b38'); c.fill();
    c.beginPath(); c.moveTo(-67,-58); c.quadraticCurveTo(-50,-90,0,-91);
    c.quadraticCurveTo(-17,-83,-23,-60); c.moveTo(0,-91); c.quadraticCurveTo(18,-83,24,-60);
    c.lineWidth=1; c.strokeStyle='#e39b77a0'; c.stroke();
    c.restore();
  }
  c.restore();
}

function boat(c, x, y, size, t, p, warm = false) {
  c.save(); c.translate(x,y + Math.sin(t*2.2)*4);
  c.rotate(Math.sin(t*1.93)*.056 + p*.023); c.scale(size,size);
  oval(c,'#0d202c62',0,5,95,8);
  polygon(c,warm?'#f3dfad':'#e9dac1',[[-36,-11],[-5,-75],[49,-10],[12,1]]);
  polygon(c,'#b6a58d',[[-36,-11],[-5,-75],[12,1]]);
  polygon(c,'#fbebcf',[[-77,-23],[-19,-9],[15,-6],[86,-28],[47,7],[-48,12]]);
  polygon(c,'#c6aa83',[[-77,-23],[-19,-9],[15,-6],[-48,12]]);
  polygon(c,'#a9544a',[[-48,12],[47,7],[86,-28],[60,4],[39,12],[-40,17]]);
  line(c,'#fff6d9',1.35,[-77,-23],[-19,-9],[15,-6],[86,-28]);
  line(c,'#a14a43aa',1.0,[-7,-50],[18,-21]);
  line(c,'#a14a4377',1.0,[-11,-44],[7,-23]);
  c.restore();
}

function grain(c) {
  c.fillStyle = c.createPattern(grainCanvas, 'repeat');
  c.fillRect(0,0,W,H);
}

module.exports = { W,H,TAU,clamp,mix,ease,mod,random,gradient,glow,polygon,line,oval,camera,
  particles,rain,water,rings,distantLand,traveler,boat,grain };
