"""Apply a predeclared material ambiguity mask, preserving the raw grade."""
from pathlib import Path
import argparse,json,hashlib

def apply(raw_file,policy_file,out):
    raw_file,policy_file,out=map(Path,[raw_file,policy_file,out])
    d=json.loads(raw_file.read_text(encoding='utf-8'));p=json.loads(policy_file.read_text(encoding='utf-8'))
    excluded=set(p['excluded_items']);groups={}
    for name,original in d['groups'].items():
        rows=[r for r in d['items'] if r['group']==name and r['id'] not in excluded]
        groups[name]=dict(passed=sum(r['passed'] for r in rows),total=len(rows),weight=original['weight'])
    result=dict(raw_score=d['score'],score=round(sum(g['weight']*g['passed']/g['total'] for g in groups.values()),4),groups=groups,policy=p,policy_sha256=hashlib.sha256(policy_file.read_bytes()).hexdigest(),raw_result=str(raw_file.resolve()))
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:result[k] for k in ['raw_score','score','groups']},ensure_ascii=False))

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('raw');a.add_argument('policy');a.add_argument('out');n=a.parse_args();apply(n.raw,n.policy,n.out)
