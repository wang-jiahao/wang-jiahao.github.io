Requirements: Python, Playwright with Microsoft Edge, Pillow. From this extracted folder:
python evaluate.py <candidate-output-folder> <new-result-folder>
python apply_score_policy.py <new-result-folder>/result.json v5/score_policy.json <new-result-folder>/final_score.json
Candidate folder contains site/index.html and local resources. Raw eleven-group diagnostics retained; final_score applies the shared two-group exclusion.
