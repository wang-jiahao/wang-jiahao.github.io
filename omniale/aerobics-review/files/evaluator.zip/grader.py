"""Deterministic partial credit; compare fields, not whole-file equality."""
from pathlib import Path
import json,re,argparse,math
ROOT=Path(__file__).resolve().parent
WEIGHTS={'ledger_code':40,'ledger_value':10,'ledger_video_evidence':10,'request_route':8,'request_claim':8,'request_status':8,'request_actual':12,'request_video_evidence':2,'request_audio_evidence':2}
def code(v):return re.sub(r'[^A-Z0-9]','',str(v).upper())
def number(v,w):
 try:return math.isfinite(float(v)) and abs(float(v)-float(w))<.011
 except (ValueError,TypeError):return False
def time_in(v,start,end):
 try:return math.isfinite(float(v)) and start-.25<=float(v)<=end+.25
 except (ValueError,TypeError):return False
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def grade(candidate,truth):
 vals={k:[] for k in WEIGHTS};diagnostic={'elements':[],'requests':[]}
 els=candidate.get('elements',[]);reqs=candidate.get('requests',[])
 if not isinstance(els,list):els=[]
 if not isinstance(reqs,list):reqs=[]
 def matches(e,ref):
  try:return str(e.get('video','')).strip().upper()==ref['video'] and int(e.get('attempt',-1))==ref['attempt']
  except (ValueError,TypeError,AttributeError):return False
 for e in truth['elements']:
  found=[r for r in els if isinstance(r,dict) and matches(r,e)];r=found[0] if len(found)==1 else {}
  res={'ledger_code':float(code(r.get('FIG_code'))==e['code']),'ledger_value':float(number(r.get('credited_value'),e['value'])),'ledger_video_evidence':float(time_in(r.get('video_evidence_s'),e['start_s'],e['end_s']))}
  for k,v in res.items():vals[k].append(v)
  diagnostic['elements'].append({'id':e['id'],'expected_code':e['code'],'candidate_code':r.get('FIG_code'),'matches_found':len(found),'credit':res})
 for e in truth['requests']:
  found=[r for r in reqs if isinstance(r,dict) and str(r.get('id','')).upper().replace(' ','')==e['id']];r=found[0] if len(found)==1 else {};el=next(x for x in truth['elements'] if matches(x,e))
  res={'request_route':(float(str(r.get('video','')).upper()==e['video'])+float(number(r.get('attempt'),e['attempt'])))/2,
   'request_claim':(float(code(r.get('requested_code'))==e['requested_code'])+float(number(r.get('requested_value'),e['requested_value'])))/2,
   'request_status':float(str(r.get('status','')).strip().lower()==e['status']),
   'request_actual':(float(code(r.get('actual_code'))==e['actual_code'])+float(number(r.get('actual_value'),e['actual_value'])))/2,
   'request_video_evidence':float(time_in(r.get('video_evidence_s'),el['start_s'],el['end_s'])),
   'request_audio_evidence':float(time_in(r.get('audio_evidence_s'),e['audio_start_s'],e['audio_end_s']) or (e.get('withdrawal_audio_start_s') is not None and time_in(r.get('audio_evidence_s'),e['withdrawal_audio_start_s'],truth['audio_duration_s'])))}
  for k,v in res.items():vals[k].append(v)
  diagnostic['requests'].append({'id':e['id'],'expected_status':e['status'],'candidate_status':r.get('status'),'expected_actual_code':e['actual_code'],'candidate_actual_code':r.get('actual_code'),'credit':res})
 components={k:WEIGHTS[k]*sum(v)/len(v) for k,v in vals.items()};total=sum(components.values())
 return dict(score=total,components=components,weights=WEIGHTS,counts={'elements':len(els),'requests':len(reqs)},diagnostic=diagnostic,
  totals_diagnostic={b:{'expected':value,'submitted':candidate.get('totals',{}).get(b),'correct':number(candidate.get('totals',{}).get(b),value)} for b,value in truth['totals'].items()},
  policy='Frozen deterministic field-level partial credit; no post-run manual score changes. Totals and report quality are diagnostic, not extra easy points.')
def perfect(truth):
 return {'elements':[dict(video=e['video'],attempt=e['attempt'],FIG_code=e['code'],credited_value=e['value'],video_evidence_s=(e['start_s']+e['end_s'])/2) for e in truth['elements']],
 'requests':[dict(id=e['id'],video=e['video'],attempt=e['attempt'],requested_code=e['requested_code'],requested_value=e['requested_value'],status=e['status'],actual_code=e['actual_code'],actual_value=e['actual_value'],video_evidence_s=next((x['start_s']+x['end_s'])/2 for x in truth['elements'] if x['video']==e['video'] and x['attempt']==e['attempt']),audio_evidence_s=(e['audio_start_s']+e['audio_end_s'])/2) for e in truth['requests']], 'totals':truth['totals']}
def main():
 p=argparse.ArgumentParser();p.add_argument('--variant',choices=['judge','coach'],required=True);p.add_argument('--candidate',type=Path);p.add_argument('--output',type=Path);p.add_argument('--self-check',action='store_true');n=p.parse_args();truth=read(ROOT/'v1/authoring'/n.variant/'truth.json')
 if n.self_check:
  ref=perfect(truth);assert abs(grade(ref,truth)['score']-100)<1e-8;assert grade({},truth)['score']==0
  for e in ref['elements']:e['FIG_code']=' '.join(e['FIG_code'].lower())
  ref['elements'].reverse();assert abs(grade(ref,truth)['score']-100)<1e-8
  # A missed action must not shift the rest; a wrong code must not erase value credit.
  ref=perfect(truth);ref['elements'].pop(2);s=grade(ref,truth)['score'];assert 95<s<100
  ref=perfect(truth);ref['elements'][0]['FIG_code']='B999';assert abs(grade(ref,truth)['score']-97.5)<1e-8
  print(json.dumps({'variant':n.variant,'reference':100,'empty':0,'case_order_and_spacing_invariant':True,'single_missing_action_score':s}));return
 result=grade(read(n.candidate),truth);text=json.dumps(result,ensure_ascii=False,indent=2)
 if n.output:n.output.write_text(text,encoding='utf-8')
 print(text)
if __name__=='__main__':main()
