from pathlib import Path
import json,argparse
from grader import grade
p=argparse.ArgumentParser();p.add_argument("candidate",type=Path);a=p.parse_args()
truth=json.loads((Path(__file__).parent/"reference.json").read_text(encoding="utf-8"))
print(json.dumps(grade(json.loads(a.candidate.read_text(encoding="utf-8-sig")),truth),ensure_ascii=False,indent=2))
