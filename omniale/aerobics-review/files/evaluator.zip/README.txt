Run: python score.py path/to/review.json
Frozen field-level partial credit. Official demonstration types and same-version values; execution quality deductions are outside scope.
