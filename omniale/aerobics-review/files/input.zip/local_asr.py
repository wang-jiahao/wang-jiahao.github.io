"""General local ASR helper. No authored transcripts or expected answers."""
from pathlib import Path
import argparse,json,subprocess
import numpy as np
from faster_whisper import WhisperModel

def main():
    p=argparse.ArgumentParser();p.add_argument('audio',type=Path);p.add_argument('--model',default='small');p.add_argument('--output',type=Path);n=p.parse_args()
    # FFmpeg decoding avoids a PyAV version mismatch in the host environment.
    raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(n.audio),'-f','f32le','-ac','1','-ar','16000','pipe:1'])
    data=np.frombuffer(raw,np.float32)
    m=WhisperModel(n.model,device='cpu',compute_type='int8',cpu_threads=4)
    segments,info=m.transcribe(data,language='zh',beam_size=5,vad_filter=False)
    result=dict(file=n.audio.name,segments=[dict(start_s=s.start,end_s=s.end,text=s.text) for s in segments])
    text=json.dumps(result,ensure_ascii=False,indent=2)
    if n.output:n.output.write_text(text,encoding='utf-8')
    else:print(text)

if __name__=='__main__':main()
